<?php

function diyara_explain_neighborhood(array $item, array $allResults): array
{
    $services = [
        'Schools' => ['school', 'schools', 'المدارس', '%s is a good place to start if school runs shape your day: %s in the district.', 'إذا كان مشوار المدرسة من أولوياتك، ففي %s خيارات داخل الحي: %s.'],
        'Healthcare' => ['hospital or clinic', 'hospitals and clinics', 'المستشفيات والعيادات', 'For medical visits, %s has %s within its boundaries.', 'إذا تهمك المواعيد الطبية داخل الحي، ففي %s: %s.'],
        'Parks' => ['park', 'parks', 'الحدائق', 'For walks or time outdoors, %s gives you %s to explore.', 'للمشي والطلعات، في %s خيارات داخل الحي: %s.'],
        'Supermarkets' => ['supermarket', 'supermarkets', 'محلات السوبرماركت', 'Grocery trips are a strong point for %s, with %s in the district.', 'مقاضي البيت من الأشياء اللي يخدمك فيها %s: %s داخل الحي.'],
        'Banks' => ['bank', 'banks', 'البنوك', 'If you visit a bank in person, %s has %s within the district.', 'إذا تحتاج تراجع البنك حضوريًا، ففي %s: %s داخل الحي.'],
        'Gas Stations' => ['fuel station', 'fuel stations', 'محطات الوقود', 'For daily drives, %s has %s for refueling within the district.', 'إذا تنقلك بالسيارة، ففي %s: %s داخل الحي.'],
    ];
    $priorities = array_intersect_key($item['service_contributions'] ?? [], $services);
    $priorities = array_filter($priorities, static fn(array $s): bool => $s['weight'] > 0);
    $available = array_filter($priorities, static fn(array $s): bool => $s['count'] > 0);
    uasort($available, static fn(array $a, array $b): int => $b['points'] <=> $a['points']);
    $en = [];
    $ar = [];
    $main = array_key_first($available);
    if ($main !== null) {
        [$one, $many, $label, $purposeEn, $purposeAr] = $services[$main];
        $count = (int) $available[$main]['count'];
        $nameEn = trim((string)($item['name_en'] ?? '')) ?: 'this neighborhood';
        $nameAr = trim((string)($item['name_ar'] ?? '')) ?: 'هذا الحي';
        $en[] = sprintf($purposeEn, $nameEn, $count . ' ' . ($count === 1 ? $one : $many));
        $ar[] = sprintf($purposeAr, $nameAr, $label . ' (' . $count . ')');

        $othersEn = [];
        $othersAr = [];
        foreach (array_slice($available, 1, 1, true) as $service => $value) {
            [$one, $many, $label] = $services[$service];
            $count = (int) $value['count'];
            $othersEn[] = $count . ' ' . ($count === 1 ? $one : $many);
            $othersAr[] = $label . ' (' . $count . ')';
        }
        if ($othersEn) {
            $en[] = 'Other priorities you can cover here: ' . implode(' and ', $othersEn) . '.';
            $ar[] = 'ومن أولوياتك المتوفرة داخل الحي أيضًا: ' . implode('، ', $othersAr) . '.';
        }
    }
    $gaps = array_diff_key($priorities, $available);
    if ($gaps) {
        uasort($gaps, static fn(array $a, array $b): int => $b['weight'] <=> $a['weight']);
        $missingEn = [];
        $missingAr = [];
        foreach (array_keys($gaps) as $service) {
            $missingEn[] = $services[$service][1];
            $missingAr[] = $services[$service][2];
        }
        $en[] = 'Check the surrounding districts for ' . implode(', ', $missingEn) . '. None are listed within this district.';
        $ar[] = 'شوف الأحياء المجاورة إذا تحتاج ' . implode(' أو ', $missingAr) . '، فهذه الخدمات غير مدرجة داخل الحي.';
    }
    if (!$priorities) {
        $en[] = 'Select the services you rely on to see which parts of your routine this district can support.';
        $ar[] = 'حدد الخدمات اللي تستخدمها عادةً، وبيظهر لك مدى ملاءمة الحي لروتينك.';
    }
    return ['en' => $en, 'ar' => $ar];
}
