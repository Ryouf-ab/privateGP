<?php

/** Browse actual listings independently of the personalized housing filter. */
function diyara_listings(PDO $pdo, ?int $neighborhoodId, ?string $propertyId = null): array
{
    if ($neighborhoodId === null && $propertyId === null) {
        return [];
    }
    $condition = $propertyId !== null ? 'p.property_id = ?' : 'p.neighborhood_id = ?';
    $query = $pdo->prepare("
        SELECT p.*, n.name_en, n.name_ar, n.region, n.schools_count,
               n.hospitals_count, n.parks_count, n.supermarkets_count
        FROM properties p
        INNER JOIN neighborhoods n ON n.neighborhood_id = p.neighborhood_id
        WHERE $condition
        ORDER BY p.price IS NULL, p.price, p.property_id
    ");
    $query->execute([$propertyId ?? $neighborhoodId]);
    return $query->fetchAll(PDO::FETCH_ASSOC);
}

/** Literal comparisons to saved preferences, shared by cards and details. */
function diyara_housing_fit(array $property, array $prefs): array
{
    $facts = [];
    $budget = (float) ($prefs['budget'] ?? 0);
    $price = $property['price'] ?? null;
    if ($budget > 0 && is_numeric($price) && (float) $price > 0) {
        $difference = (float) $price - $budget;
        $facts['Budget'] = [
            'quiet' => $difference <= 0,
            'text' => $difference == 0 ? 'At your budget' :
                number_format(abs($difference)) . ' SAR ' . ($difference > 0 ? 'over' : 'below') . ' budget',
        ];
    }

    foreach ([
        ['Area', 'area_m2', 'preferred_size', ' m²', 'smaller', 'larger'],
        ['Bedrooms', 'bedrooms', 'bedrooms', '', 'fewer', 'more'],
    ] as [$label, $key, $preference, $unit, $less, $more]) {
        $target = (float) ($prefs[$preference] ?? 0);
        $value = $property[$key] ?? null;
        if ($target <= 0 || !is_numeric($value) || (float) $value <= 0) {
            continue;
        }
        $difference = (float) $value - $target;
        $facts[$label] = [
            'quiet' => $difference >= 0,
            'text' => $difference == 0 ? 'Matches your preference' :
                number_format(abs($difference), fmod(abs($difference), 1) ? 1 : 0) . $unit . ' ' . ($difference < 0 ? $less : $more),
        ];
    }

    $aliases = ['فيلا' => 'villa', 'شقة' => 'apartment', 'دور' => 'floor', 'أرض' => 'land'];
    $wanted = strtolower(trim((string) ($prefs['property_type'] ?? '')));
    $actual = strtolower(trim((string) ($property['property_type'] ?? '')));
    $wanted = $aliases[$wanted] ?? $wanted;
    $actual = $aliases[$actual] ?? $actual;
    if ($wanted !== '' && $actual !== '' && $wanted !== $actual
        && !($wanted === 'both' && in_array($actual, ['villa', 'apartment'], true))) {
        $facts['Type'] = ['quiet' => false, 'text' => 'Different from your preferred type'];
    }

    return $facts;
}

require_once __DIR__ . '/includes/bilingual-explanation.php';

function diyara_outside_saved_criteria(array $property, array $prefs): bool
{
    return $prefs !== [] && !isset($property['match_score']);
}

function diyara_housing_summary(array $property, array $prefs): array
{
    $price = (float) ($property['price'] ?? 0);
    $budget = (float) ($prefs['budget'] ?? 0);
    $area = (float) ($property['area_m2'] ?? 0);
    $targetArea = (float) ($prefs['preferred_size'] ?? 0);
    $rooms = (int) ($property['bedrooms'] ?? 0);
    $wantedRooms = (int) ($prefs['bedrooms'] ?? 0);
    $strengths = [];
    $tradeoffs = [];
    $budgetFit = null;

    if ($price > 0 && $budget > 0) {
        $difference = number_format(abs($price - $budget));
        if ($price > $budget) {
            $tradeoffs[] = ["It exceeds your budget by {$difference} SAR.", "السعر أعلى من ميزانيتك بـ {$difference} ريال."];
        } elseif ($price < $budget) {
            $share = $price / $budget;
            if ($share < 0.5) {
                $budgetFit = ['The asking price uses less than half of your saved budget.', 'السعر أقل من نصف الميزانية اللي حددتها.'];
            } else {
                $budgetFit = ["The asking price is {$difference} SAR below your limit.", "السعر أقل من سقف ميزانيتك بـ {$difference} ريال."];
            }
        } else {
            $budgetFit = ['The asking price is exactly at your budget limit.', 'السعر يساوي الحد الأعلى لميزانيتك.'];
        }
    }
    if ($rooms > 0 && $wantedRooms > 0) {
        $count = abs($rooms - $wantedRooms);
        if ($rooms < $wantedRooms) {
            $unit = $count === 1 ? 'bedroom' : 'bedrooms';
            $tradeoffs[] = ["It has {$count} fewer {$unit} than you’re looking for ({$rooms} instead of {$wantedRooms}).", "فيه {$rooms} غرف نوم، وأنت تبي {$wantedRooms}."];
        } elseif ($rooms > $wantedRooms) {
            $strengths[] = ["With {$rooms} bedrooms, you’d have more room than the {$wantedRooms} you asked for.", "فيه {$rooms} غرف نوم، أكثر من العدد اللي طلبته ({$wantedRooms})."];
        } else {
            $strengths[] = ["The {$rooms}-bedroom layout meets your room requirement.", "عدد غرف النوم يطابق طلبك ({$rooms})."];
        }
    }
    if ($area > 0 && $targetArea > 0) {
        $difference = abs($area - $targetArea);
        $text = number_format($difference, fmod($difference, 1) ? 2 : 0);
        if ($area < $targetArea) {
            $tradeoffs[] = ["It’s {$text} m² smaller than your target.", "مساحته أقل من اللي حددتها بـ {$text} م²."];
        } elseif ($area > $targetArea) {
            $strengths[] = ["It gives you {$text} m² more than your target area.", "مساحته أكبر من اللي حددتها بـ {$text} م²."];
        } else {
            $strengths[] = ['The floor area matches what you requested.', 'المساحة تطابق اللي حددتها.'];
        }
    }
    if (isset(diyara_housing_fit($property, $prefs)['Type'])) {
        $tradeoffs[] = ['The property type differs from the one you selected.', 'نوع العقار مختلف عن النوع اللي اخترته.'];
    }

    if (diyara_outside_saved_criteria($property, $prefs)) {
        if ($price <= 0 && $budget > 0) {
            $tradeoffs[] = ['The price is unavailable, so it cannot be checked against your budget.', 'سعر العقار غير متاح للتحقق من توافقه مع ميزانيتك.'];
        }
        if (trim((string) ($property['property_type'] ?? '')) === '' && !empty($prefs['property_type'])) {
            $tradeoffs[] = ['The property type is unavailable.', 'نوع العقار غير متاح.'];
        }
        $notes = array_merge([
            ['This property does not meet your saved criteria.', 'هذا العقار لا يطابق معاييرك المحفوظة.'],
        ], $tradeoffs);
        return ['en' => array_column($notes, 0), 'ar' => array_column($notes, 1)];
    }

    $notes = $tradeoffs;
    if ($strengths) {
        $notes[] = $strengths[0];
    }
    if ($budgetFit !== null && count($notes) < 2) {
        $notes[] = $budgetFit;
    }
    if (!$notes) {
        $notes[] = [
            'Set a budget, target area or bedroom count to see how this listing fits your plans.',
            'حدد الميزانية أو المساحة أو عدد غرف النوم عشان تعرف مدى ملاءمة العقار لك.',
        ];
    }
    return ['en' => array_column($notes, 0), 'ar' => array_column($notes, 1)];
}
