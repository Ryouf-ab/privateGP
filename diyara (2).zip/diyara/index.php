


<?php

require 'db.php';

$page_title = 'Home';
$active = 'home';

/* ==========================================
   PROPERTY SORTING
========================================== */

$sort = $_GET['sort'] ?? 'name_az';

$allowedSorts = [

    'name_az' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) ASC
    ",

    'name_za' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) DESC
    ",

    'price_low' => "
        p.price IS NULL ASC,
        p.price ASC
    ",

    'price_high' => "
        p.price IS NULL ASC,
        p.price DESC
    "

];

if (!array_key_exists($sort, $allowedSorts)) {
    $sort = 'name_az';
}


/* ==========================================
   HELPER FUNCTIONS
========================================== */

function home_escape($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function home_price($value)
{
    if ($value === null || $value === '') {
        return 'Price unavailable';
    }

    return number_format((float) $value) . ' SAR';
}


/* ==========================================
   GET ALL AVAILABLE PROPERTIES
========================================== */

$properties = [];
$errorMessage = '';

try {

    $sql = "
        SELECT
            p.property_id,
            p.property_type,
            p.price,
            p.area_m2,
            p.bedrooms,
            p.bathrooms,
            n.name_en,
            n.name_ar

        FROM properties p

        INNER JOIN neighborhoods n
            ON n.neighborhood_id = p.neighborhood_id

        ORDER BY
            " . $allowedSorts[$sort] . ",
            p.property_id ASC
    ";

    $stmt = $pdo->query($sql);

    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    error_log(
        'DIYARA home properties: ' . $e->getMessage()
    );

    $errorMessage = 'Properties are temporarily unavailable.';

}

// Agent-uploaded listing photographs take precedence over type-matched visuals.
require_once __DIR__ . '/property_images_lib.php';
require_once __DIR__ . '/property_fallback_photos.php';
$homePhotoUses = [];
$homeListingPhotos = property_images_for($pdo, array_column($properties, 'property_id'));


/* ==========================================
   HEADER
========================================== */

require 'includes/header.php';

?>

<!-- LOAD HOME STYLES -->
<link rel="stylesheet" href="recommendations-extra.css?v=74">
<link rel="stylesheet" href="diyara.css?v=74">
<link rel="stylesheet" href="assets/css/home-premium.css?v=<?= @filemtime(__DIR__ . '/assets/css/home-premium.css') ?: time() ?>">


<!-- ==========================================
     HERO SECTION
========================================== -->

<section class="hero dy-home-hero">

    <div class="container dy-home-hero-inner">

        <div class="dy-home-copy">

            <h1 lang="ar" dir="rtl">ديارا <span class="dy-home-tagline">| لكل طبعٍ حيّ</span></h1>

            <p>
                Discover Riyadh neighborhoods for your daily life, and homes that fit how you want to live.
            </p>

            <div class="dy-home-actions">
                <a class="dy-home-primary" href="<?php echo !empty($logged_in) ? 'recommendations.php' : 'register.html'; ?>">Explore your matches <span aria-hidden="true">↗</span></a>
                <a class="dy-home-secondary" href="#home-properties">Discover properties <span aria-hidden="true">↓</span></a>
            </div>

        </div>

        <div class="dy-home-visual">
            <div class="dy-hero-weave" aria-hidden="true"></div>
            <div class="dy-hero-halo" aria-hidden="true"></div>
            <figure class="dy-home-main-photo">
                <img src="assets/riyadh-evening-hd.webp" alt="Riyadh skyline at dusk beyond a palm-lined promenade" fetchpriority="high" decoding="async">
            </figure>
            <div class="dy-hero-inset" aria-hidden="true"><img src="assets/home-limestone.webp" alt="" decoding="async"></div>
            <span class="dy-hero-diamond" aria-hidden="true"></span>
        </div>

    </div>

</section>


<!-- Two clear paths into the two independent recommendation experiences. -->
<section class="dy-home-journeys" aria-labelledby="dyJourneysTitle">
    <div class="container">
        <div class="dy-home-journeys-heading">
            <div><h2 id="dyJourneysTitle">Explore Diyara</h2></div>
        </div>
        <div class="dy-home-journeys-grid">
            <a class="dy-home-journey" href="<?= !empty($logged_in) ? 'recommendations.php' : 'register.html' ?>">
                <img src="assets/property-hero-hd.webp" alt="Contemporary architecture with landscaped outdoor living" loading="lazy" decoding="async">
                <span class="dy-home-journey-overlay"><strong>Discover properties</strong><span>Match homes to your budget, space and housing needs.</span><span class="dy-home-journey-arrow" aria-hidden="true">↗</span></span>
            </a>
            <a class="dy-home-journey" href="<?= !empty($logged_in) ? 'neighborhood-recommendations.php' : 'register.html' ?>">
                <img src="assets/district-hero-hd.webp" alt="Riyadh urban neighborhood with landscaped pedestrian streets" loading="lazy" decoding="async">
                <span class="dy-home-journey-overlay"><strong>Explore neighborhoods</strong><span>See how local services match your priorities.</span><span class="dy-home-journey-arrow" aria-hidden="true">↗</span></span>
            </a>
        </div>
    </div>
</section>


<!-- ==========================================
     ALL PROPERTIES SHOWCASE
========================================== -->

<section
    class="home-properties"
    id="home-properties"
>

    <div class="container">

        <!-- HEADING -->

        <div class="home-properties-heading">

            <div>

                <span class="rec-eyebrow">
                    EXPLORE DIYARA
                </span>

                <h2>Explore Our Properties</h2>

                <p>
                    Discover properties available across Riyadh.
                    Find a place that feels like home.
                </p>

            </div>

        </div>


        <!-- SORTING -->

        <form
            method="GET"
            action="index.php"
            class="home-sort"
        >

            <label for="property-sort">
                Sort properties by
            </label>


            <select
                id="property-sort"
                name="sort"
                onchange="this.form.submit()"
            >

                <option
                    value="name_az"
                    <?php echo $sort === 'name_az' ? 'selected' : ''; ?>
                >
                    Alphabetical: A–Z
                </option>


                <option
                    value="name_za"
                    <?php echo $sort === 'name_za' ? 'selected' : ''; ?>
                >
                    Alphabetical: Z–A
                </option>


                <option
                    value="price_low"
                    <?php echo $sort === 'price_low' ? 'selected' : ''; ?>
                >
                    Price: Lowest to Highest
                </option>


                <option
                    value="price_high"
                    <?php echo $sort === 'price_high' ? 'selected' : ''; ?>
                >
                    Price: Highest to Lowest
                </option>

            </select>

        </form>


        <!-- PROPERTIES -->

        <?php if ($errorMessage !== ''): ?>

            <div class="empty">

                <?php echo home_escape($errorMessage); ?>

            </div>


        <?php elseif (empty($properties)): ?>

            <div class="empty">

                No properties are currently available.

            </div>


        <?php else: ?>


            <!-- HORIZONTAL CAROUSEL -->

            <div class="home-properties-track">

                <?php foreach ($properties as $property): ?>

                    <?php

                    $type = (string) $property['property_type'];

                    $isVilla =
                        stripos($type, 'villa') !== false ||
                        strpos($type, 'فيلا') !== false;

                    $imageType = $isVilla
                        ? 'villa'
                        : 'apartment';

                    $uploadedForThisHome = $homeListingPhotos[(string) $property['property_id']] ?? [];
                    $hasRealPhoto = !empty($uploadedForThisHome[0]['url']);
                    $homePhoto = $hasRealPhoto
                        ? $uploadedForThisHome[0]['url']
                        : diyara_property_photo((string) $property['property_id'], $type, 'all', $homePhotoUses) . '?v=20261120e';

                    $neighborhood =
                        $property['name_en']
                        ?: $property['name_ar']
                        ?: 'Riyadh';

                    ?>


                    <article class="home-property-card">


                        <!-- PROPERTY IMAGE -->

                        <div class="home-property-image rec-property-image dy-home-property-photo">
                            <img src="<?= home_escape($homePhoto) ?>"
                                 alt="<?= $hasRealPhoto ? 'Photo of this property' : '' ?>"
                                 loading="lazy" decoding="async">
                        </div>


                        <!-- PROPERTY INFORMATION -->

                        <div class="home-property-content">


                            <div class="home-property-title">

                                <h3>
                                    <?php echo home_escape($type); ?>
                                </h3>

                                <strong>
                                    <?php echo home_price($property['price']); ?>
                                </strong>

                            </div>


                            <p class="home-property-neighborhood">

                                <span>Location:</span>

                                <?php echo home_escape($neighborhood); ?>

                                <?php if (!empty($property['name_ar'])): ?>

                                    · <?php echo home_escape($property['name_ar']); ?>

                                <?php endif; ?>

                            </p>


                            <!-- PROPERTY DETAILS -->

                            <div class="home-property-details">


                                <span>

                                    <?php

                                    echo $property['area_m2'] !== null
                                        ? number_format((float) $property['area_m2']) . ' m²'
                                        : 'Area unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bedrooms'] !== null
                                        ? (int) $property['bedrooms'] . ' Bedrooms'
                                        : 'Bedrooms unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bathrooms'] !== null
                                        ? (int) $property['bathrooms'] . ' Bathrooms'
                                        : 'Bathrooms unavailable';

                                    ?>

                                </span>

                            </div>


                            <small class="home-property-id">

                                Property #
                                <?php echo home_escape($property['property_id']); ?>

                            </small>


                        </div>

                    </article>


                <?php endforeach; ?>

            </div>


            <p class="home-scroll-hint">

                Scroll horizontally to explore more properties →

            </p>


        <?php endif; ?>


    </div>

</section>


<!-- ==========================================
     FOOTER
========================================== -->

<?php require 'includes/footer.php'; ?>
