<?php
/** Diyara Sprint 2 — standalone neighborhood recommendations, powered by wsm.php. */
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/wsm.php';
require_once __DIR__ . '/neighborhood-photos.php';
require_once __DIR__ . '/explanation-slot.php'; // Person 3: place for Person 4's explanation
$userId = (int) ($_SESSION['user_id'] ?? 0);
if ($userId < 1) { header('Location: login.html'); exit; }
function nr_escape($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
$results = [];
$error = '';
try { $results = get_wsm_neighborhoods($pdo, $userId); }
catch (Throwable $e) { error_log('Diyara neighborhood WSM: ' . $e->getMessage()); $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to load neighborhood recommendations right now.'; }
$page_title = 'Neighborhood Recommendations';
$active = 'recommendations';
require __DIR__ . '/includes/header.php';
?>
<link rel="stylesheet" href="explanation-slot.css?v=<?= @filemtime(__DIR__ . '/explanation-slot.css') ?: time() ?>">
<link rel="stylesheet" href="assets/css/neighborhood-graduation.css?v=<?= @filemtime(__DIR__ . '/assets/css/neighborhood-graduation.css') ?: time() ?>">
<link rel="stylesheet" href="assets/css/discovery.css?v=7">
<section class="nr-wrap">
  <nav class="nr-tabs" aria-label="Recommendation types">
    <a href="recommendations.php">Property Recommendations</a>
    <a href="neighborhood-recommendations.php" aria-current="page">Neighborhood Recommendations</a>
  </nav>
  <div class="nr-hero discovery-hero"><div class="nr-copy">
    <h1>Find your neighborhood</h1>
    <p>Explore Riyadh by the services you use most.</p>
    <a href="lifestyle-preferences.php">Adjust my priorities &rarr;</a>
  </div><div class="dy-najdi-scene" aria-hidden="true"><span class="dy-najdi-window"></span></div></div>
  <?php if ($error !== ''): ?>
    <div class="nr-empty"><strong>Recommendations unavailable</strong><p><?= nr_escape($error) ?></p><a class="nr-btn" href="lifestyle-preferences.php">Open Lifestyle Preferences</a></div>
  <?php elseif (!$results): ?>
    <div class="nr-empty">No neighborhoods are available right now. Please try again soon.</div>
  <?php else: ?>
    <div class="nr-heading">
      <h2 class="nr-section-title">Your neighborhood shortlist</h2>
      <span class="nr-count" id="nrCount" aria-live="polite"><?= count($results) ?> neighborhoods</span>
    </div>
    <details class="nr-ranking-guide">
      <summary>About your neighborhood recommendations</summary>
      <p>The Neighborhood Service Suitability Score reflects how well the available services match your service importance ratings.</p>
      <p>Top, Moderate, and Lower Recommendations are the upper, middle, and lower thirds of the ranked list. Any extra places go to the top tier first, then the middle tier.</p>
      <p>Service Suitability describes the score itself. High starts at 70%, Medium starts at 40%, and Low is below 40%.</p>
    </details>
    <div class="nr-toolbar">
      <input class="nr-search" id="nrSearch" type="search" placeholder="Search for a neighborhood..." aria-label="Search neighborhoods">
      <a class="nr-compare-open" id="nrCompareOpen" href="compare.php" aria-label="Compare neighborhoods">Compare neighborhoods <span id="nrCompareCount">(0/2)</span></a>
    </div>
    <div class="nr-selection-bar" id="nrSelectionBar" hidden aria-live="polite"><strong>Compare selected neighborhoods <span id="nrBarCount">(0/2)</span></strong><span id="nrSelectedNames">Choose two neighborhoods</span><form id="nrCompareForm" action="compare.php" method="get" style="display:inline-flex;margin:0"><input type="hidden" name="a" id="nrFormA" value=""><input type="hidden" name="b" id="nrFormB" value=""><button type="submit" id="nrBarGo" disabled>Compare Now →</button></form></div>
    <div class="nr-grid" id="nrGrid">
    <?php foreach ($results as $item):
      $name = trim((string)($item['name_en'] ?? '')) ?: (string)($item['name_ar'] ?? 'Neighborhood');
      $score = (float)$item['suitability_score'];
      $level = (string)$item['suitability_level'];
      $tier = (string)$item['recommendation_tier'];
    ?>
      <article class="nr-card" data-search="<?= nr_escape(mb_strtolower($name . ' ' . ($item['name_ar'] ?? ''), 'UTF-8')) ?>">
        <div class="nr-card-art">
          <img src="<?= nr_escape(diyara_neighborhood_photo((int) $item['neighborhood_id'])) ?>" alt="" loading="lazy" decoding="async">
          <span class="nr-level">Rank <?= (int)$item['rank'] ?> · <?= nr_escape($tier) ?> Recommendation</span>
          <span class="nr-card-region"><?= nr_escape($item['region'] ?: 'Riyadh') ?></span>
        </div>
        <div class="nr-body"><label class="nr-compare-select"><input type="checkbox" class="nr-compare-check" value="<?= (int)$item['neighborhood_id'] ?>"> Compare</label><h3 class="nr-name"><?= nr_escape($name) ?></h3>
        <?php if (!empty($item['name_ar'])): ?><div class="nr-ar" lang="ar" dir="rtl"><?= nr_escape($item['name_ar']) ?></div><?php endif; ?>
        <div class="nr-score-row"><span class="nr-score-label">Neighborhood Service Suitability Score</span><div class="nr-score"><span class="nr-level nr-level-<?= nr_escape(strtolower($level)) ?>"><?= nr_escape($level) ?></span> <?= number_format($score, 2) ?><small>%</small></div></div>
        <div class="nr-track" aria-hidden="true"><div class="nr-fill" style="width:<?= min(100,max(0,$score)) ?>%"></div></div>
        <?= nr_render_explanation($item, $results) ?>
        <a class="nr-properties-link" href="recommendations.php?neighborhood_id=<?= (int)$item['neighborhood_id'] ?>">Explore homes &rarr;</a></div>
      </article>
    <?php endforeach; ?>
    </div>
    <p class="nr-empty" id="nrNoResults" hidden>No neighborhoods match your search.</p>


  <?php endif; ?>
</section>
<script>
(function () {
  'use strict';
  const checks = Array.from(document.querySelectorAll('.nr-compare-check'));
  const topLink = document.getElementById('nrCompareOpen');
  const form = document.getElementById('nrCompareForm');
  const submit = document.getElementById('nrBarGo');
  const formA = document.getElementById('nrFormA');
  const formB = document.getElementById('nrFormB');
  const countTop = document.getElementById('nrCompareCount');
  const countBottom = document.getElementById('nrBarCount');
  const names = document.getElementById('nrSelectedNames');
  const chosen = () => checks.filter(c => c.checked);
  function update() {
    const selected = chosen();
    const valid = selected.length === 2 && selected[0].value !== selected[1].value;
    if (countTop) countTop.textContent = '(' + selected.length + '/2)';
    if (countBottom) countBottom.textContent = '(' + selected.length + '/2)';
    document.getElementById('nrSelectionBar').hidden = selected.length === 0;
    if (names) names.textContent = selected.map(c => c.closest('.nr-card')?.querySelector('.nr-name')?.textContent.trim() || c.value).join(' · ') || 'Choose two neighborhoods';
    if (formA) formA.value = valid ? selected[0].value : '';
    if (formB) formB.value = valid ? selected[1].value : '';
    if (submit) submit.disabled = !valid;
    if (topLink) {
      topLink.href = valid ? 'compare.php?a=' + encodeURIComponent(selected[0].value) + '&b=' + encodeURIComponent(selected[1].value) : '#nrSelectionBar';
      topLink.setAttribute('aria-disabled', String(!valid));
    }
  }
  checks.forEach(c => c.addEventListener('change', () => {
    if (chosen().length > 2) { c.checked = false; alert('Choose only two neighborhoods.'); }
    update();
  }));
  form?.addEventListener('submit', e => {
    update();
    if (chosen().length !== 2 || !formA.value || !formB.value) { e.preventDefault(); alert('Select two different neighborhoods.'); }
  });
  topLink?.addEventListener('click', e => { if (chosen().length !== 2) { e.preventDefault(); alert('Select two different neighborhoods.'); } });
  const search = document.getElementById('nrSearch');
  const cards = Array.from(document.querySelectorAll('.nr-card'));
  const count = document.getElementById('nrCount');
  search?.addEventListener('input', () => {
    const term = search.value.toLocaleLowerCase().trim();
    let shown = 0;
    cards.forEach(card => { const visible = (card.dataset.search || '').includes(term); card.hidden = !visible; card.style.display = visible ? '' : 'none'; if (visible) shown++; });
    if (count) count.textContent = shown + ' of ' + cards.length + ' neighborhoods';
    document.getElementById('nrNoResults').hidden = shown !== 0;
  });
  update();
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
