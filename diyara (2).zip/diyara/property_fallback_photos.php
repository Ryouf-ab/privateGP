<?php
/**
 * Visual fallbacks only. Agent-uploaded listing photos always take priority.
 * No housing, recommendation, WSM or database logic lives in this file.
 */
function diyara_property_photo_pool(string $type, string $scene = 'all'): array
{
    $type = strtolower(trim($type));
    $categories = ['villa' => 'villa', 'فيلا' => 'villa', 'apartment' => 'apartment', 'شقة' => 'apartment'];
    $category = $categories[$type] ?? null;
    if ($category === null) {
        return ['assets/property-no-photo.webp'];
    }

    $exteriors = [];
    for ($index = 1; $index <= 4; $index++) {
        $exteriors[] = "assets/luxe-{$category}-{$index}.webp";
    }
    $interiors = [
        "assets/luxe-{$category}-room-1.webp",
        "assets/luxe-{$category}-room-2.webp",
        "assets/collection-{$category}-interior-2.webp",
        "assets/collection-{$category}-interior-3.webp",
    ];

    if ($scene === 'exterior') return $exteriors;
    if ($scene === 'interior') return $interiors;
    return array_merge($exteriors, $interiors);
}

function diyara_property_photo(string $id, string $type, string $scene = 'all', ?array &$used = null): string
{
    $photos = diyara_property_photo_pool($type, $scene);
    $hash = (int) sprintf('%u', crc32($id));
    $offset = $hash % count($photos);
    if ($used === null) {
        return $photos[$offset];
    }

    // Spread repeats out within each type, even when adjacent IDs hash alike.
    $fewestUses = min(array_map(static fn(string $photo): int => $used[$photo] ?? 0, $photos));
    for ($i = 0; $i < count($photos); $i++) {
        $photo = $photos[($offset + $i) % count($photos)];
        if (($used[$photo] ?? 0) === $fewestUses) {
            $used[$photo] = $fewestUses + 1;
            return $photo;
        }
    }

    return $photos[$offset];
}

function diyara_property_gallery(string $id, string $type): array
{
    // Different scenes and angles for each listing; strictly matching its type.
    return array_values(array_unique([
        diyara_property_photo($id, $type, 'exterior'),
        diyara_property_photo($id . '-interior', $type, 'interior'),
    ]));
}
