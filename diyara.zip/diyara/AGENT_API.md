# Agent Property API (Person 1 -> Person 3)

All endpoints return JSON: `{ "ok": true, ... }` or `{ "ok": false, "error": "...", "errors": { "field": "message" } }`.
Only a logged-in **real estate agent** can use them (401 = not logged in, 403 = not an agent, 405 = wrong HTTP method).
Put this at the top of every agent page (dashboard, add, edit): `require 'agent_page_guard.php';`

| Endpoint | Method | Send | Returns |
|---|---|---|---|
| `agent-csrf.php` | GET | - | `{ok, csrf}` |
| `agent-lookups.php` | GET | - | `{ok, property_types:[{value,label,residential}], neighborhoods:[{neighborhood_id,name_ar,name_en}]}` (fill the dropdowns) |
| `agent-properties.php` | GET | - | `{ok, count, properties:[...]}` the agent's own listings (dashboard table) |
| `agent-property-get.php` | GET | `?property_id=A123456789` | `{ok, property}` (fill the Edit form) |
| `agent-property-add.php` | POST | fields below + `csrf` | 201 `{ok, message, property}` / 422 `{errors}` |
| `agent-property-edit.php` | POST | `property_id` + fields below + `csrf` | 200 `{ok, message, property}` / 404 / 422 |
| `agent-property-delete.php` | POST | `property_id`, `confirm=1`, `csrf` | 200 `{ok, message}` / 400 not confirmed / 404 |

## Form fields (names must match exactly)
| Field | Rule |
|---|---|
| `property_type` | `شقة` `فيلا` `دور` `أرض` `عمارة` `استراحة` (English names such as Apartment / Villa also accepted) |
| `neighborhood_id` | id of an existing neighborhood (from `agent-lookups.php`) |
| `bedrooms`, `bathrooms` | whole number 0-30. Required and at least 1 for شقة / فيلا / دور. Optional (0) for the other types |
| `area_m2` | number 20 - 100,000 |
| `price` | number (SAR) 1,000 - 5,000,000,000. Commas are accepted |
| `csrf` | token from `agent-csrf.php`, or print `agent_csrf_token()` in a hidden input. Can also be sent in the `X-CSRF-Token` header |
| `property_id` | edit/delete only. Never sent on add: the server creates it (`A` + 9 digits) |

`property` object: `property_id, neighborhood_id, neighborhood_name_ar, neighborhood_name_en, property_type, property_type_en, bedrooms, bathrooms, area_m2, price, created_at, updated_at`.

## Example (fetch)
```js
const { csrf } = await (await fetch('agent-csrf.php')).json();
const res = await fetch('agent-property-add.php', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ property_type: 'شقة', neighborhood_id: 1, bedrooms: 3, bathrooms: 2, area_m2: 150, price: 850000, csrf })
});
const data = await res.json();
if (!data.ok && data.errors) { /* show data.errors.price, data.errors.area_m2 ... under each input */ }
```
A normal HTML form post (urlencoded) works too.

## Rules the backend enforces
- An agent sees, edits and deletes **only his own** listings. Anyone else's listing (or an original dataset listing) answers 404.
- Listings added by agents are stored in the same `properties` table, so they appear in Recommendations automatically.
- Deleting an agent account deletes that agent's listings.
- Do not re-import `data/diyara_data.sql` after agents added properties (it runs `DELETE FROM properties`).
