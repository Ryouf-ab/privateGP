# Diyara: قاعدة المشروع المشتركة

## التشغيل
1. حطي المجلد كامل داخل `htdocs/diyara` (MAMP) وشغّلي MAMP.
2. أنشئي القاعدة `diyara_db` (جدول `users` موجود في رسالة القروب).
3. افتحي: http://localhost:8888/diyara/index.php
4. عدّلي كلمة مرور MySQL في `db.php` لو مختلفة عندك.

## كيف تسوين صفحة جديدة
انسخي `profile.php` وغيّري محتواه. الهيكل دايماً:
```php
<?php
require 'auth_check.php';   // فقط إذا الصفحة تتطلب تسجيل دخول
require 'db.php';           // لو تحتاجين القاعدة ($pdo)
$page_title = 'اسم الصفحة';
$active = 'profile';        // home | recommendations | profile
require 'includes/header.php';
?>
<section class="page"><div class="container">
   ... محتواك هنا ...
</div></section>
<?php require 'includes/footer.php'; ?>
```

## قواعد التنسيق (عشان الموقع يطلع واحد)
- كل الألوان والخطوط من `:root` في `assets/css/style.css`. لا تكتبين ألوان داخل صفحتك.
- الأزرار: `.btn` أو `.btn-secondary`. الكروت: `.card`. الشبكة: `.grid .grid-2/.grid-3`.
- الفورم: `.field` (label + input) والرسالة `.msg .error/.success`.
- لما ما يكون فيه بيانات: `.empty`.
- الـ SQL دايماً prepared statements مثل `register.php`.
- صورة الواجهة الرئيسية: حطيها في `assets/img/hero.png`.

## مين تشتغل على وش
| الملف | المسؤولة |
|---|---|
| login / register / logout / auth_check | Person 1 |
| profile.php + فورم التفضيلات | Person 2 |
| منطق الفلترة (ملف PHP منفصل مثل `filter.php`) | Person 3 |
| recommendations.php + ربط الداتا | Person 4 |

لو تعدلين على `style.css` أو `includes/`: قولي للقروب قبل.
