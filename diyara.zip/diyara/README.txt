Diyara recommendation UI update — Oct 28 2026

1. BACK UP your existing PHP/CSS files.
2. Copy recommendations.php, property-details.php, recommendations-extra.css, recommendations-ui.js to C:\MAMP\htdocs\diyara\
3. Copy/merge the assets directory into C:\MAMP\htdocs\diyara\assets\
4. Copy housing-preferences.php ONLY IF it matches the same page version in your project; this file is based on the previous Diyara ZIP. If newer, edit its $property_types list to include Both instead.
5. To enable the newly requested Both option, replace filter.php with the provided version; the ONLY change is adding a both alias for apartment+villa. All weights (40/30/30), eligibility rules, and ordering logic remain identical. The housing_preferences property_type VARCHAR(50) column supports the value Both with no SQL migration.
6. Clear browser cache Ctrl+Shift+R, ensure MAMP Apache and MySQL are running.
7. property-details.php MUST sit directly beside recommendations.php. The old version incorrectly treated alphanumeric listing IDs as integers; this version uses their actual string IDs. No new tables needed.
8. Why neighborhood appears uses matching counts and filters, NOT a fabricated neighborhood suitability score. Property explanations use real property and preference fields. AI pictures are explicitly illustrative and not photos of specific listings.

Requires existing db.php, auth_check.php, includes/header.php, includes/footer.php and original theme styles. Test locally in MAMP. Detailed comparison remains future-sprint only.
