<?php
// GET -> {"ok":true,"csrf":"..."}  (token for fetch-based forms; plain forms can print agent_csrf_token() instead)
require __DIR__ . '/agent_lib.php';
agent_require($pdo, 'GET');
json_out(200, ['ok' => true, 'csrf' => agent_csrf_token()]);
