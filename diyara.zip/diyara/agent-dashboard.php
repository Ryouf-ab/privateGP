<?php
/**
 * Diyara Sprint 2 - Person 3 (Part A): Agent Dashboard.
 * Shows the logged-in real estate agent's own listings and lets them add, edit and delete.
 * Data comes from Person 1's backend (see AGENT_API.md):
 *   agent-properties.php (list), agent-property-delete.php (delete), agent-csrf.php (token).
 */
require 'agent_page_guard.php';   // only a logged-in real estate agent gets past this line
require 'db.php';
require_once 'agent_lib.php';     // for agent_csrf_token()

$agentName = '';
$stmt = $pdo->prepare('SELECT name FROM users WHERE user_id = ?');
$stmt->execute([$_SESSION['user_id']]);
$agentName = (string) $stmt->fetchColumn();

$flash = [
    'added'   => 'Property added. It now appears in your listings and in Recommendations.',
    'updated' => 'Changes saved.',
][$_GET['saved'] ?? ''] ?? '';

$page_title = 'Agent Dashboard';
$active = 'agent';
require 'includes/header.php';
?>
<link rel="stylesheet" href="agent.css?v=<?= @filemtime(__DIR__ . '/agent.css') ?: time() ?>">

<section class="ag-wrap" data-csrf="<?= htmlspecialchars(agent_csrf_token(), ENT_QUOTES, 'UTF-8') ?>">

    <div class="ag-hero">
        <div class="ag-hero-copy">
            <span class="ag-eyebrow">REAL ESTATE AGENT</span>
            <h1>My Listings</h1>
            <p>Welcome<?= $agentName !== '' ? ', ' . htmlspecialchars($agentName, ENT_QUOTES, 'UTF-8') : '' ?>. Manage the properties you list on Diyara. Every listing you add is shown to home seekers whose preferences match it.</p>
        </div>
        <a class="ag-btn ag-btn-light" href="agent-property-form.php">+ Add property</a>
    </div>

    <?php if ($flash !== ''): ?>
        <div class="ag-msg ag-msg-success" role="status"><?= htmlspecialchars($flash, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <div class="ag-msg" id="agMsg" role="status" hidden></div>

    <div class="ag-stats" id="agStats" hidden>
        <div class="ag-stat"><span>Listings</span><strong id="agStatCount">0</strong></div>
        <div class="ag-stat"><span>Neighborhoods</span><strong id="agStatHoods">0</strong></div>
        <div class="ag-stat"><span>Average price</span><strong id="agStatAvg">-</strong></div>
    </div>

    <div class="ag-panel">
        <div class="ag-panel-head">
            <h2>Your properties</h2>
            <input type="search" id="agSearch" class="ag-search" placeholder="Search by neighborhood, type or ID" aria-label="Search your listings" hidden>
        </div>

        <div class="ag-state" id="agLoading">Loading your listings…</div>

        <div class="ag-state ag-empty" id="agEmpty" hidden>
            <strong>You have no listings yet</strong>
            <p>Add your first property and it will appear here.</p>
            <a class="ag-btn" href="agent-property-form.php">+ Add property</a>
        </div>

        <div class="ag-state ag-error" id="agError" hidden></div>

        <div class="ag-table-wrap" id="agTableWrap" hidden>
            <table class="ag-table">
                <thead>
                    <tr>
                        <th>Property</th>
                        <th>Neighborhood</th>
                        <th class="ag-num">Area</th>
                        <th class="ag-num">Rooms</th>
                        <th class="ag-num">Price</th>
                        <th>Last change</th>
                        <th><span class="ag-sr">Actions</span></th>
                    </tr>
                </thead>
                <tbody id="agRows"></tbody>
            </table>
            <p class="ag-state" id="agNoMatch" hidden>No listing matches your search.</p>
        </div>
    </div>
</section>

<!-- Delete confirmation -->
<div class="ag-modal" id="agModal" hidden>
    <div class="ag-modal-box" role="alertdialog" aria-modal="true" aria-labelledby="agModalTitle" aria-describedby="agModalText">
        <h2 id="agModalTitle">Delete this property?</h2>
        <p id="agModalText"></p>
        <p class="ag-modal-warn">This cannot be undone. The listing will also disappear from home seekers' recommendations.</p>
        <div class="ag-modal-err" id="agModalErr" hidden></div>
        <div class="ag-modal-actions">
            <button type="button" class="ag-btn ag-btn-ghost" id="agCancel">Cancel</button>
            <button type="button" class="ag-btn ag-btn-danger" id="agConfirm">Delete property</button>
        </div>
    </div>
</div>

<script>
(() => {
    const wrap = document.querySelector('.ag-wrap');
    const csrf = wrap.dataset.csrf;
    const $ = id => document.getElementById(id);
    const rows = $('agRows'), search = $('agSearch');
    let listings = [], pending = null;

    const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
    const num = n => Number(n).toLocaleString('en-US', {maximumFractionDigits: 0});
    const date = s => s ? new Date(s.replace(' ', 'T')).toLocaleDateString('en-GB', {day: 'numeric', month: 'short', year: 'numeric'}) : '-';
    const show = (id, on) => { $(id).hidden = !on; };

    function flash(text, ok) {
        const m = $('agMsg');
        m.textContent = text;
        m.className = 'ag-msg ' + (ok ? 'ag-msg-success' : 'ag-msg-error');
        m.hidden = false;
    }

    function render() {
        show('agLoading', false);
        const has = listings.length > 0;
        show('agEmpty', !has); show('agTableWrap', has); show('agStats', has); search.hidden = !has;

        $('agStatCount').textContent = listings.length;
        $('agStatHoods').textContent = new Set(listings.map(p => p.neighborhood_id)).size;
        $('agStatAvg').textContent = has ? num(listings.reduce((s, p) => s + p.price, 0) / listings.length) + ' SAR' : '-';

        const q = search.value.trim().toLowerCase();
        let shown = 0;
        rows.innerHTML = listings.map(p => {
            const hay = [p.property_id, p.property_type, p.property_type_en, p.neighborhood_name_ar, p.neighborhood_name_en].join(' ').toLowerCase();
            const visible = !q || hay.includes(q);
            if (visible) shown++;
            const rooms = (p.bedrooms || p.bathrooms) ? `${p.bedrooms} bd · ${p.bathrooms} ba` : '-';
            return `<tr${visible ? '' : ' hidden'}>
                <td><strong>${esc(p.property_type_en)}</strong> <span class="ag-ar" dir="rtl">${esc(p.property_type)}</span><small>${esc(p.property_id)}</small></td>
                <td><span dir="rtl">${esc(p.neighborhood_name_ar)}</span><small>${esc(p.neighborhood_name_en)}</small></td>
                <td class="ag-num" data-label="Area">${num(p.area_m2)} m²</td>
                <td class="ag-num" data-label="Rooms">${rooms}</td>
                <td class="ag-num" data-label="Price"><span><strong>${num(p.price)}</strong> SAR</span></td>
                <td data-label="Last change">${date(p.updated_at || p.created_at)}</td>
                <td class="ag-actions">
                    <a class="ag-link" href="agent-property-form.php?id=${encodeURIComponent(p.property_id)}">Edit</a>
                    <button type="button" class="ag-link ag-link-danger" data-delete="${esc(p.property_id)}">Delete</button>
                </td>
            </tr>`;
        }).join('');
        show('agNoMatch', has && shown === 0);
    }

    async function load() {
        try {
            const res = await fetch('agent-properties.php', {headers: {'Accept': 'application/json'}});
            const data = await res.json();
            if (!data.ok) throw new Error(data.error || 'Could not load your listings.');
            listings = data.properties;
            render();
        } catch (e) {
            show('agLoading', false);
            $('agError').textContent = e.message || 'Could not load your listings. Please reload the page.';
            show('agError', true);
        }
    }

    function openModal(id) {
        const p = listings.find(x => x.property_id === id);
        if (!p) return;
        pending = p;
        $('agModalText').innerHTML = `<strong>${esc(p.property_type_en)}</strong> in <bdi>${esc(p.neighborhood_name_en || p.neighborhood_name_ar)}</bdi>, ${num(p.area_m2)} m², ${num(p.price)} SAR <small>(ID ${esc(p.property_id)})</small>`;
        show('agModalErr', false);
        $('agConfirm').disabled = false;
        $('agConfirm').textContent = 'Delete property';
        show('agModal', true);
        $('agCancel').focus();
    }
    function closeModal() { show('agModal', false); pending = null; }

    async function confirmDelete() {
        if (!pending) return;
        const btn = $('agConfirm');
        btn.disabled = true; btn.textContent = 'Deleting…';
        try {
            const res = await fetch('agent-property-delete.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                body: JSON.stringify({property_id: pending.property_id, confirm: 1, csrf})
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.error || 'Could not delete the property.');
            listings = listings.filter(p => p.property_id !== pending.property_id);
            closeModal();
            render();
            flash('Property deleted.', true);
        } catch (e) {
            $('agModalErr').textContent = e.message;
            show('agModalErr', true);
            btn.disabled = false; btn.textContent = 'Delete property';
        }
    }

    rows.addEventListener('click', e => {
        const b = e.target.closest('[data-delete]');
        if (b) openModal(b.dataset.delete);
    });
    search.addEventListener('input', render);
    $('agCancel').addEventListener('click', closeModal);
    $('agConfirm').addEventListener('click', confirmDelete);
    $('agModal').addEventListener('click', e => { if (e.target.id === 'agModal') closeModal(); });
    document.addEventListener('keydown', e => { if (e.key === 'Escape' && !$('agModal').hidden) closeModal(); });

    load();
})();
</script>

<?php require 'includes/footer.php'; ?>
