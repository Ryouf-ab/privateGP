<?php
// GET -> property types and neighborhoods, for the Add / Edit Property dropdowns.
require __DIR__ . '/agent_lib.php';
try {
    agent_require($pdo, 'GET');
    $types = [];
    foreach (AGENT_PROPERTY_TYPES as $value => $label) {
        $types[] = ['value' => $value, 'label' => $label, 'residential' => in_array($value, AGENT_RESIDENTIAL_TYPES, true)];
    }
    $rows = $pdo->query('SELECT neighborhood_id, name_ar, name_en FROM neighborhoods ORDER BY name_ar')->fetchAll(PDO::FETCH_ASSOC);
    $neighborhoods = array_map(static fn($r) => [
        'neighborhood_id' => (int) $r['neighborhood_id'],
        'name_ar' => $r['name_ar'],
        'name_en' => $r['name_en'],
    ], $rows);
    json_out(200, ['ok' => true, 'property_types' => $types, 'neighborhoods' => $neighborhoods]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
