<?php
// GET -> all listings owned by the logged-in agent (newest first).
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'GET');
    $stmt = $pdo->prepare(AGENT_PROPERTY_SELECT . ' WHERE p.agent_id = ? ORDER BY p.created_at DESC, p.property_id');
    $stmt->execute([$agentId]);
    $list = array_map('agent_format_property', $stmt->fetchAll(PDO::FETCH_ASSOC));
    $photos = property_images_for($pdo, array_column($list, 'property_id'));
    foreach ($list as &$item) {
        $item['images'] = $photos[$item['property_id']] ?? [];
        $item['cover'] = $item['images'][0]['url'] ?? null;
    }
    unset($item);
    json_out(200, ['ok' => true, 'count' => count($list), 'properties' => $list]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
