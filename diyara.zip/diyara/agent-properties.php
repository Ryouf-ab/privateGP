<?php
// GET -> all listings owned by the logged-in agent (newest first).
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'GET');
    $stmt = $pdo->prepare(AGENT_PROPERTY_SELECT . ' WHERE p.agent_id = ? ORDER BY p.created_at DESC, p.property_id');
    $stmt->execute([$agentId]);
    $list = array_map('agent_format_property', $stmt->fetchAll(PDO::FETCH_ASSOC));
    json_out(200, ['ok' => true, 'count' => count($list), 'properties' => $list]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
