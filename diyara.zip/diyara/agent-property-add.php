<?php
// POST: property_type, neighborhood_id, bedrooms, bathrooms, area_m2, price, csrf
// -> 201 {"ok":true,"property":{...}}  or 422 {"ok":false,"errors":{field:message}}
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'POST');
    $in = agent_input();
    agent_check_csrf($in);

    [$data, $errors] = agent_validate($pdo, $in);
    if ($errors) {
        json_error(422, 'Please check the highlighted fields.', $errors);
    }

    $id = agent_new_property_id($pdo);
    $stmt = $pdo->prepare('INSERT INTO properties
        (property_id, neighborhood_id, agent_id, property_type, bedrooms, bathrooms, area_m2, price)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([
        $id, $data['neighborhood_id'], $agentId, $data['property_type'],
        $data['bedrooms'], $data['bathrooms'], $data['area_m2'], $data['price'],
    ]);

    json_out(201, [
        'ok' => true,
        'message' => 'Property added successfully.',
        'property' => agent_get_own_property($pdo, $agentId, $id),
    ]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
