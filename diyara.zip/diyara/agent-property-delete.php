<?php
// POST: property_id, confirm=1 (the confirmation step), csrf. Only the owner agent can delete.
// -> 200 {"ok":true} | 400 not confirmed | 404 not yours / not found
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'POST');
    $in = agent_input();
    agent_check_csrf($in);

    $confirm = $in['confirm'] ?? '';
    if (!($confirm === true || $confirm === 1 || $confirm === '1' || $confirm === 'true' || $confirm === 'on')) {
        json_error(400, 'Please confirm the deletion.');
    }

    $id = trim((string) ($in['property_id'] ?? ''));
    if ($id === '' || !agent_get_own_property($pdo, $agentId, $id)) {
        json_error(404, 'Property not found.');
    }

    $stmt = $pdo->prepare('DELETE FROM properties WHERE property_id = ? AND agent_id = ?');
    $stmt->execute([$id, $agentId]);

    json_out(200, ['ok' => true, 'message' => 'Property deleted.', 'property_id' => $id]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
