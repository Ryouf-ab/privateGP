<?php
// POST: property_id + the same fields as add + csrf. Only the owner agent can edit.
// -> 200 {"ok":true,"property":{...}}  | 404 (not yours / not found) | 422 validation errors
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'POST');
    $in = agent_input();
    agent_check_csrf($in);

    $id = trim((string) ($in['property_id'] ?? ''));
    if ($id === '' || !agent_get_own_property($pdo, $agentId, $id)) {
        json_error(404, 'Property not found.');
    }

    [$data, $errors] = agent_validate($pdo, $in);
    if ($errors) {
        json_error(422, 'Please check the highlighted fields.', $errors);
    }

    /* agent_id is in the WHERE clause too, so even a bug above can never touch someone else's listing */
    $stmt = $pdo->prepare('UPDATE properties
        SET neighborhood_id = ?, property_type = ?, bedrooms = ?, bathrooms = ?, area_m2 = ?, price = ?,
            updated_at = CURRENT_TIMESTAMP
        WHERE property_id = ? AND agent_id = ?');
    $stmt->execute([
        $data['neighborhood_id'], $data['property_type'], $data['bedrooms'], $data['bathrooms'],
        $data['area_m2'], $data['price'], $id, $agentId,
    ]);

    json_out(200, [
        'ok' => true,
        'message' => 'Property updated successfully.',
        'property' => agent_get_own_property($pdo, $agentId, $id),
    ]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
