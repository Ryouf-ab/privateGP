<?php
/**
 * Diyara Sprint 2 - Person 3 (Part A): Add Property / Edit Property form.
 *   agent-property-form.php           -> Add a new listing
 *   agent-property-form.php?id=A123.. -> Edit one of your listings
 * Saves through Person 1's backend (see AGENT_API.md):
 *   agent-lookups.php, agent-property-get.php, agent-property-add.php, agent-property-edit.php.
 * The backend re-checks every rule; the checks here only give faster feedback.
 */
require 'agent_page_guard.php';
require 'db.php';
require_once 'agent_lib.php';

$editId = trim((string) ($_GET['id'] ?? ''));
$isEdit = $editId !== '';

$page_title = $isEdit ? 'Edit Property' : 'Add Property';
$active = 'agent';
require 'includes/header.php';
$h = static fn($v) => htmlspecialchars((string) $v, ENT_QUOTES, 'UTF-8');
?>
<link rel="stylesheet" href="agent.css?v=<?= @filemtime(__DIR__ . '/agent.css') ?: time() ?>">

<section class="ag-wrap ag-form-page">
    <a class="ag-back" href="agent-dashboard.php">&larr; Back to My Listings</a>

    <div class="ag-panel ag-form-panel">
        <span class="ag-eyebrow ag-eyebrow-dark"><?= $isEdit ? 'EDIT LISTING' : 'NEW LISTING' ?></span>
        <h1><?= $isEdit ? 'Edit property' : 'Add a property' ?></h1>
        <p class="ag-lead"><?= $isEdit
            ? 'Update the details of this listing. Changes show in Recommendations right away.'
            : 'Fill in the details below. Home seekers whose budget and preferences match will see this listing.' ?></p>

        <div class="ag-state" id="agLoading">Loading…</div>
        <div class="ag-msg ag-msg-error" id="agFormMsg" role="alert" hidden></div>

        <form id="agForm" novalidate hidden
              data-edit-id="<?= $h($editId) ?>"
              data-csrf="<?= $h(agent_csrf_token()) ?>">

            <?php if ($isEdit): ?>
                <p class="ag-id">Listing ID <strong><?= $h($editId) ?></strong></p>
            <?php endif; ?>

            <div class="ag-grid">
                <div class="ag-field">
                    <label for="property_type">Property type</label>
                    <select id="property_type" name="property_type" required>
                        <option value="">Choose a type</option>
                    </select>
                    <small class="ag-err" data-for="property_type"></small>
                </div>

                <div class="ag-field">
                    <label for="neighborhood_id">Neighborhood</label>
                    <select id="neighborhood_id" name="neighborhood_id" required>
                        <option value="">Choose a neighborhood</option>
                    </select>
                    <small class="ag-err" data-for="neighborhood_id"></small>
                </div>

                <div class="ag-field">
                    <label for="area_m2">Area (m²)</label>
                    <input id="area_m2" name="area_m2" inputmode="decimal" placeholder="e.g. 180" required>
                    <small class="ag-hint">Between 20 and 100,000 m²</small>
                    <small class="ag-err" data-for="area_m2"></small>
                </div>

                <div class="ag-field">
                    <label for="price">Price (SAR)</label>
                    <input id="price" name="price" inputmode="decimal" placeholder="e.g. 950,000" required>
                    <small class="ag-hint">Between 1,000 and 5,000,000,000 SAR</small>
                    <small class="ag-err" data-for="price"></small>
                </div>

                <div class="ag-field">
                    <label for="bedrooms">Bedrooms <span class="ag-opt" data-opt>(optional)</span></label>
                    <input id="bedrooms" name="bedrooms" type="number" min="0" max="30" step="1" inputmode="numeric">
                    <small class="ag-err" data-for="bedrooms"></small>
                </div>

                <div class="ag-field">
                    <label for="bathrooms">Bathrooms <span class="ag-opt" data-opt>(optional)</span></label>
                    <input id="bathrooms" name="bathrooms" type="number" min="0" max="30" step="1" inputmode="numeric">
                    <small class="ag-err" data-for="bathrooms"></small>
                </div>
            </div>

            <p class="ag-hint ag-rooms-note" id="agRoomsNote">Apartments, villas and floors need at least 1 bedroom and 1 bathroom.</p>

            <div class="ag-photos">
                <label for="agPhotoInput">Photos <span class="ag-opt">(optional, up to 5)</span></label>
                <p class="ag-hint">JPG, PNG or WebP. The first photo is the main photo shown to home seekers.</p>
                <div class="ag-photo-grid" id="agPhotoGrid"></div>
                <input type="file" id="agPhotoInput" accept="image/jpeg,image/png,image/webp" multiple hidden>
                <button type="button" class="ag-btn ag-btn-ghost" id="agPhotoPick">+ Add photos</button>
                <small class="ag-err" id="agPhotoErr"></small>
            </div>

            <div class="ag-form-actions">
                <a class="ag-btn ag-btn-ghost" href="agent-dashboard.php">Cancel</a>
                <button type="submit" class="ag-btn" id="agSave"><?= $isEdit ? 'Save changes' : 'Add property' ?></button>
            </div>
        </form>
    </div>
</section>

<script>
(() => {
    const form = document.getElementById('agForm');
    let editId = form.dataset.editId;   // becomes the new id if photos fail after a first save
    const csrf = form.dataset.csrf;
    const msg = document.getElementById('agFormMsg');
    const loading = document.getElementById('agLoading');
    const typeSel = form.property_type, hoodSel = form.neighborhood_id;
    let residential = new Set();

    const getJSON = async url => {
        const res = await fetch(url, {headers: {'Accept': 'application/json'}});
        const data = await res.json();
        if (!data.ok) throw Object.assign(new Error(data.error || 'Something went wrong.'), {status: res.status});
        return data;
    };
    const addOption = (sel, value, label) => sel.add(new Option(label, value));

    function showError(text) { msg.textContent = text; msg.hidden = false; }
    function setFieldError(name, text) {
        const el = form.querySelector(`.ag-err[data-for="${name}"]`);
        if (el) el.textContent = text || '';
        form[name]?.classList.toggle('ag-invalid', !!text);
        if (text) form[name]?.setAttribute('aria-invalid', 'true'); else form[name]?.removeAttribute('aria-invalid');
    }
    function clearErrors() { ['property_type','neighborhood_id','area_m2','price','bedrooms','bathrooms'].forEach(n => setFieldError(n, '')); msg.hidden = true; }

    function updateRooms() {
        const need = residential.has(typeSel.value);
        form.querySelectorAll('[data-opt]').forEach(s => s.hidden = need);
        form.bedrooms.required = form.bathrooms.required = need;
        form.bedrooms.min = form.bathrooms.min = need ? 1 : 0;
        document.getElementById('agRoomsNote').hidden = !need;
    }

    /* Same rules as agent_validate() in agent_lib.php */
    function validate() {
        const errs = {};
        const v = n => form[n].value.trim();
        const numOk = s => /^\d+(\.\d{1,2})?$/.test(s.replace(/[,\s]/g, ''));
        const toNum = s => Number(s.replace(/[,\s]/g, ''));
        if (!v('property_type')) errs.property_type = 'Choose a property type.';
        if (!v('neighborhood_id')) errs.neighborhood_id = 'Choose a neighborhood.';
        if (!numOk(v('area_m2'))) errs.area_m2 = 'Enter the area in square meters (numbers only).';
        else if (toNum(v('area_m2')) < 20 || toNum(v('area_m2')) > 100000) errs.area_m2 = 'Area must be between 20 and 100,000 m².';
        if (!numOk(v('price'))) errs.price = 'Enter the price in SAR (numbers only).';
        else if (toNum(v('price')) < 1000 || toNum(v('price')) > 5000000000) errs.price = 'Price must be between 1,000 and 5,000,000,000 SAR.';
        const need = residential.has(v('property_type'));
        for (const [n, label] of [['bedrooms', 'Bedrooms'], ['bathrooms', 'Bathrooms']]) {
            const s = v(n);
            if (s === '') { if (need) errs[n] = `${label} is required.`; continue; }
            if (!/^\d+$/.test(s) || +s > 30) errs[n] = `${label} must be a whole number from 0 to 30.`;
            else if (need && +s < 1) errs[n] = `${label} must be at least 1 for this property type.`;
        }
        return errs;
    }

    /* ---------- photos ---------- */
    const MAX_PHOTOS = 5;
    const grid = document.getElementById('agPhotoGrid');
    const picker = document.getElementById('agPhotoInput');
    const photoErr = document.getElementById('agPhotoErr');
    let saved = [];      // photos already on the server: {image_id, url}
    let queued = [];     // newly chosen photos: {blob, url}

    const total = () => saved.length + queued.length;
    function drawPhotos() {
        grid.innerHTML = '';
        saved.forEach(img => grid.append(tile(img.url, 'Remove photo', () => removeSaved(img))));
        queued.forEach(q => grid.append(tile(q.url, 'Remove photo', () => { URL.revokeObjectURL(q.url); queued = queued.filter(x => x !== q); drawPhotos(); })));
        document.getElementById('agPhotoPick').hidden = total() >= MAX_PHOTOS;
    }
    function tile(src, label, onRemove) {
        const d = document.createElement('div');
        d.className = 'ag-photo';
        const i = document.createElement('img');
        i.src = src; i.alt = 'Property photo';
        const b = document.createElement('button');
        b.type = 'button'; b.className = 'ag-photo-x'; b.setAttribute('aria-label', label); b.textContent = '×';
        b.addEventListener('click', onRemove);
        d.append(i, b);
        return d;
    }
    async function removeSaved(img) {
        photoErr.textContent = '';
        try {
            const res = await fetch('agent-property-image-delete.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                body: JSON.stringify({csrf, property_id: editId, image_id: img.image_id})
            });
            const data = await res.json();
            if (!data.ok) throw new Error(data.error);
            saved = data.images;
            drawPhotos();
        } catch (e) { photoErr.textContent = e.message || 'Could not remove the photo.'; }
    }
    /* Shrinks the photo in the browser (max 1600 px, JPEG) so uploads are small and fast */
    function shrink(file) {
        return new Promise((resolve, reject) => {
            const url = URL.createObjectURL(file);
            const img = new Image();
            img.onload = () => {
                const scale = Math.min(1, 1600 / Math.max(img.width, img.height));
                const c = document.createElement('canvas');
                c.width = Math.round(img.width * scale); c.height = Math.round(img.height * scale);
                const ctx = c.getContext('2d');
                ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, c.width, c.height);
                ctx.drawImage(img, 0, 0, c.width, c.height);
                URL.revokeObjectURL(url);
                c.toBlob(b => b ? resolve(b) : reject(new Error('x')), 'image/jpeg', 0.85);
            };
            img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('x')); };
            img.src = url;
        });
    }
    document.getElementById('agPhotoPick').addEventListener('click', () => picker.click());
    picker.addEventListener('change', async () => {
        photoErr.textContent = '';
        const room = MAX_PHOTOS - total();
        const chosen = [...picker.files];
        picker.value = '';
        if (chosen.length > room) photoErr.textContent = `You can add ${room} more photo${room === 1 ? '' : 's'} (maximum ${MAX_PHOTOS}).`;
        for (const f of chosen.slice(0, Math.max(room, 0))) {
            if (!/^image\/(jpeg|png|webp)$/.test(f.type)) { photoErr.textContent = `${f.name}: use a JPG, PNG or WebP photo.`; continue; }
            try {
                const blob = await shrink(f);
                queued.push({blob, url: URL.createObjectURL(blob)});
            } catch (e) { photoErr.textContent = `${f.name}: could not read this photo.`; }
        }
        drawPhotos();
    });
    async function uploadQueued(id) {
        const fd = new FormData();
        fd.append('csrf', csrf);
        fd.append('property_id', id);
        queued.forEach((q, i) => fd.append('images[]', q.blob, `photo${i + 1}.jpg`));
        const res = await fetch('agent-property-image-upload.php', {method: 'POST', body: fd, headers: {'Accept': 'application/json'}});
        let data;
        try { data = await res.json(); } catch (e) { throw new Error('The photos could not be uploaded.'); }
        if (!data.ok) throw new Error(data.error || 'The photos could not be uploaded.');
        return data;
    }

    async function init() {
        try {
            const lookups = await getJSON('agent-lookups.php');
            lookups.property_types.forEach(t => {
                addOption(typeSel, t.value, `${t.label} · ${t.value}`);
                if (t.residential) residential.add(t.value);
            });
            lookups.neighborhoods.forEach(n => addOption(hoodSel, n.neighborhood_id, n.name_en ? `${n.name_ar} · ${n.name_en}` : n.name_ar));

            if (editId) {
                const {property: p} = await getJSON('agent-property-get.php?property_id=' + encodeURIComponent(editId));
                typeSel.value = p.property_type;
                hoodSel.value = p.neighborhood_id;
                form.area_m2.value = +p.area_m2;
                form.price.value = Number(p.price).toLocaleString('en-US', {maximumFractionDigits: 2});
                if (p.bedrooms || residential.has(p.property_type)) form.bedrooms.value = p.bedrooms;
                if (p.bathrooms || residential.has(p.property_type)) form.bathrooms.value = p.bathrooms;
                saved = p.images || [];
            }
            drawPhotos();
            updateRooms();
            loading.hidden = true;
            form.hidden = false;
        } catch (e) {
            loading.hidden = true;
            showError(e.status === 404
                ? 'This listing was not found, or it is not one of your listings.'
                : (e.message || 'Could not load the form. Please reload the page.'));
        }
    }

    typeSel.addEventListener('change', () => { updateRooms(); setFieldError('bedrooms', ''); setFieldError('bathrooms', ''); });
    form.addEventListener('input', e => { if (e.target.name) setFieldError(e.target.name, ''); });

    form.addEventListener('submit', async e => {
        e.preventDefault();
        clearErrors();
        const errs = validate();
        if (Object.keys(errs).length) {
            Object.entries(errs).forEach(([n, t]) => setFieldError(n, t));
            form.querySelector('.ag-invalid')?.focus();
            return;
        }
        const body = {csrf};
        ['property_type','neighborhood_id','area_m2','price','bedrooms','bathrooms'].forEach(n => body[n] = form[n].value.trim());
        if (editId) body.property_id = editId;

        const btn = document.getElementById('agSave');
        const label = btn.textContent;
        btn.disabled = true; btn.textContent = 'Saving…';
        try {
            const res = await fetch(editId ? 'agent-property-edit.php' : 'agent-property-add.php', {
                method: 'POST',
                headers: {'Content-Type': 'application/json', 'Accept': 'application/json'},
                body: JSON.stringify(body)
            });
            const data = await res.json();
            if (data.ok) {
                const wasEdit = !!editId;
                if (queued.length) {
                    const newId = wasEdit ? editId : data.property.property_id;
                    btn.textContent = 'Uploading photos…';
                    try {
                        await uploadQueued(newId);
                    } catch (upErr) {
                        /* the listing itself is saved: stay here so the agent can retry the photos */
                        editId = newId;
                        body.property_id = newId;
                        try {
                            const fresh = await getJSON('agent-property-get.php?property_id=' + encodeURIComponent(newId));
                            saved = fresh.property.images || [];
                        } catch (e2) {}
                        queued.forEach(q => URL.revokeObjectURL(q.url));
                        queued = [];
                        drawPhotos();
                        showError('The property was saved, but the photos were not: ' + upErr.message + ' You can add them again and press Save.');
                        btn.disabled = false; btn.textContent = 'Save changes';
                        return;
                    }
                }
                location.href = 'agent-dashboard.php?saved=' + (wasEdit ? 'updated' : 'added');
                return;
            }
            if (data.errors) Object.entries(data.errors).forEach(([n, t]) => setFieldError(n, t));
            showError(data.error || 'Could not save the property.');
        } catch (err) {
            showError('Could not reach the server. Please try again.');
        }
        btn.disabled = false; btn.textContent = label;
    });

    init();
})();
</script>

<?php require 'includes/footer.php'; ?>
