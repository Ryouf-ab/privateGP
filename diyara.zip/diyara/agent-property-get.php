<?php
// GET ?property_id=A123456789 -> one listing, only if it belongs to the logged-in agent (used to fill the Edit form).
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'GET');
    $id = trim((string) ($_GET['property_id'] ?? ''));
    $property = $id === '' ? null : agent_get_own_property($pdo, $agentId, $id);
    if (!$property) {
        json_error(404, 'Property not found.');
    }
    json_out(200, ['ok' => true, 'property' => $property]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
