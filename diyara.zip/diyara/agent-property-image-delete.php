<?php
// POST: property_id, image_id, csrf. Only the owner agent can remove a photo.
// -> 200 {"ok":true,"images":[...]} | 404 not yours / not found
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'POST');
    $in = agent_input();
    agent_check_csrf($in);

    $id = trim((string) ($in['property_id'] ?? ''));
    $imageId = (int) ($in['image_id'] ?? 0);
    if ($id === '' || $imageId < 1 || !agent_get_own_property($pdo, $agentId, $id)) {
        json_error(404, 'Photo not found.');
    }
    $stmt = $pdo->prepare('SELECT file_name FROM property_images WHERE image_id = ? AND property_id = ?');
    $stmt->execute([$imageId, $id]);
    $file = $stmt->fetchColumn();
    if ($file === false) {
        json_error(404, 'Photo not found.');
    }
    $pdo->prepare('DELETE FROM property_images WHERE image_id = ? AND property_id = ?')->execute([$imageId, $id]);
    @unlink(property_images_dir() . '/' . basename((string) $file));

    json_out(200, ['ok' => true, 'images' => property_images_for($pdo, [$id])[$id] ?? []]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Please try again.');
}
