<?php
// POST (multipart/form-data): property_id, csrf, images[]  -> adds photos to one of the agent's own listings.
// Allowed: JPG, PNG, WebP (checked by content, not by file name), max 3 MB each, max 5 per listing.
// -> 200 {"ok":true,"images":[...],"errors":[...]} | 404 not yours | 413 too big | 422 nothing saved
require __DIR__ . '/agent_lib.php';
try {
    $agentId = agent_require($pdo, 'POST');

    /* A body bigger than post_max_size arrives empty: say so instead of a confusing CSRF error */
    if (empty($_POST) && empty($_FILES) && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        json_error(413, 'The photos are too big. Please choose smaller photos.');
    }
    $in = $_POST;
    agent_check_csrf($in);

    $id = trim((string) ($in['property_id'] ?? ''));
    if ($id === '' || !agent_get_own_property($pdo, $agentId, $id)) {
        json_error(404, 'Property not found.');
    }

    /* Normalise $_FILES['images'] (one or many) into a list */
    $files = [];
    if (!empty($_FILES['images'])) {
        $f = $_FILES['images'];
        if (is_array($f['name'])) {
            foreach ($f['name'] as $i => $name) {
                $files[] = ['name' => $name, 'tmp_name' => $f['tmp_name'][$i], 'error' => $f['error'][$i], 'size' => $f['size'][$i]];
            }
        } else {
            $files[] = $f;
        }
    }
    if (!$files) {
        json_error(422, 'Please choose at least one photo.');
    }

    $count = $pdo->prepare('SELECT COUNT(*) FROM property_images WHERE property_id = ?');
    $count->execute([$id]);
    $have = (int) $count->fetchColumn();

    $dir = property_images_dir();
    $types = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $insert = $pdo->prepare('INSERT INTO property_images (property_id, file_name, sort_order) VALUES (?, ?, ?)');
    $errors = [];
    $saved = 0;

    foreach ($files as $file) {
        $label = (string) $file['name'];
        if ($have + $saved >= PROPERTY_IMAGE_MAX) {
            $errors[] = "$label: a listing can have at most " . PROPERTY_IMAGE_MAX . ' photos.';
            continue;
        }
        if ($file['error'] === UPLOAD_ERR_INI_SIZE || $file['error'] === UPLOAD_ERR_FORM_SIZE) {
            $errors[] = "$label: the photo is too big.";
            continue;
        }
        if ($file['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($file['tmp_name'])) {
            $errors[] = "$label: the upload failed.";
            continue;
        }
        if ($file['size'] > 3 * 1024 * 1024) {
            $errors[] = "$label: the photo must be 3 MB or smaller.";
            continue;
        }
        $mime = $finfo->file($file['tmp_name']);
        $info = @getimagesize($file['tmp_name']);
        if (!isset($types[$mime]) || !$info || $info[0] < 100 || $info[1] < 100 || $info[0] > 10000 || $info[1] > 10000) {
            $errors[] = "$label: use a JPG, PNG or WebP photo.";
            continue;
        }
        $name = bin2hex(random_bytes(12)) . '.' . $types[$mime];   // our own name, the original name is never used
        if (!move_uploaded_file($file['tmp_name'], $dir . '/' . $name)) {
            $errors[] = "$label: could not save the photo.";
            continue;
        }
        @chmod($dir . '/' . $name, 0644);
        $insert->execute([$id, $name, $have + $saved]);
        $saved++;
    }

    $images = property_images_for($pdo, [$id])[$id] ?? [];
    if ($saved === 0) {
        json_error(422, $errors ? implode(' ', $errors) : 'No photo was saved.');
    }
    json_out(200, ['ok' => true, 'saved' => $saved, 'images' => $images, 'errors' => $errors]);
} catch (PDOException $e) {
    json_error(500, 'Server error. Did you import sprint2_images.sql?');
}
