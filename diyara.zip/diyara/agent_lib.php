<?php
/**
 * Diyara Sprint 2 - Person 1: shared helpers for the agent property backend.
 * Every agent-*.php endpoint includes this file.
 *
 * All endpoints answer JSON: {"ok": true, ...} or {"ok": false, "error": "...", "errors": {field: message}}
 */
require_once __DIR__ . '/db.php';

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

/* Canonical property types (same Arabic values the dataset and filter.php use) */
const AGENT_PROPERTY_TYPES = [
    'شقة'    => 'Apartment',
    'فيلا'   => 'Villa',
    'دور'    => 'Floor',
    'أرض'    => 'Land',
    'عمارة'  => 'Building',
    'استراحة' => 'Rest house',
];
/* Types that must have at least 1 bedroom and 1 bathroom */
const AGENT_RESIDENTIAL_TYPES = ['شقة', 'فيلا', 'دور'];

/* ---------- output ---------- */

function json_out(int $code, array $payload): void
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store, no-cache, must-revalidate');
    header('Pragma: no-cache');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function json_error(int $code, string $message, array $fieldErrors = []): void
{
    $out = ['ok' => false, 'error' => $message];
    if ($fieldErrors) {
        $out['errors'] = $fieldErrors;
    }
    json_out($code, $out);
}

/* ---------- authentication + role-based access ---------- */

/**
 * Call first in every agent endpoint.
 * 405 wrong HTTP method, 401 not logged in, 403 logged in but not a real estate agent.
 * The role is re-read from the database, so a deleted or changed account loses access immediately.
 */
function agent_require(PDO $pdo, string $method = 'GET'): int
{
    if ($_SERVER['REQUEST_METHOD'] !== $method) {
        header('Allow: ' . $method);
        json_error(405, 'Method not allowed.');
    }
    if (empty($_SESSION['user_id'])) {
        json_error(401, 'Please log in first.');
    }
    $stmt = $pdo->prepare('SELECT role FROM users WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $role = $stmt->fetchColumn();
    if ($role === false) {
        json_error(401, 'Please log in first.');
    }
    if ($role !== 'agent') {
        json_error(403, 'This action is only available to real estate agents.');
    }
    $_SESSION['role'] = $role;
    return (int) $_SESSION['user_id'];
}

/* ---------- CSRF ---------- */

function agent_csrf_token(): string
{
    if (empty($_SESSION['agent_csrf'])) {
        $_SESSION['agent_csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['agent_csrf'];
}

function agent_check_csrf(array $input): void
{
    $sent = (string) ($input['csrf'] ?? ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? ''));
    if ($sent === '' || !hash_equals(agent_csrf_token(), $sent)) {
        json_error(403, 'Invalid or missing security token. Reload the page and try again.');
    }
}

/* ---------- input ---------- */

/** Accepts a JSON body or a normal form post. */
function agent_input(): array
{
    $raw = file_get_contents('php://input');
    if ($raw !== false && $raw !== '') {
        $json = json_decode($raw, true);
        if (is_array($json)) {
            return $json;
        }
    }
    return $_POST;
}

/* ---------- validation ---------- */

function agent_normalize_type(string $value): ?string
{
    $v = mb_strtolower(trim($value), 'UTF-8');
    $v = preg_replace('/\s+/u', ' ', $v);
    $aliases = [
        'apartment' => 'شقة', 'flat' => 'شقة',
        'villa' => 'فيلا',
        'floor' => 'دور',
        'land' => 'أرض', 'أرض سكنية' => 'أرض',
        'building' => 'عمارة', 'عمارة سكنية' => 'عمارة',
        'rest house' => 'استراحة', 'rest_house' => 'استراحة', 'resthouse' => 'استراحة',
    ];
    if (isset(AGENT_PROPERTY_TYPES[$v])) {
        return $v;
    }
    return $aliases[$v] ?? null;
}

function agent_parse_int($value): ?int
{
    $s = trim((string) $value);
    return ($s !== '' && ctype_digit($s) && strlen($s) <= 9) ? (int) $s : null;
}

function agent_parse_number($value): ?float
{
    $s = str_replace([',', ' '], '', trim((string) $value));
    return preg_match('/^\d+(\.\d{1,2})?$/', $s) ? (float) $s : null;
}

/**
 * Server-side validation for add and edit.
 * Returns [cleanData, errors]. errors is empty when everything is valid.
 */
function agent_validate(PDO $pdo, array $in): array
{
    $errors = [];
    $clean = [];

    /* property type */
    $type = agent_normalize_type((string) ($in['property_type'] ?? ''));
    if ($type === null) {
        $errors['property_type'] = 'Choose a valid property type (' . implode(', ', array_keys(AGENT_PROPERTY_TYPES)) . ').';
    } else {
        $clean['property_type'] = $type;
    }

    /* neighborhood must exist */
    $nid = agent_parse_int($in['neighborhood_id'] ?? '');
    if ($nid === null || $nid < 1) {
        $errors['neighborhood_id'] = 'Choose a neighborhood.';
    } else {
        $stmt = $pdo->prepare('SELECT 1 FROM neighborhoods WHERE neighborhood_id = ?');
        $stmt->execute([$nid]);
        if (!$stmt->fetchColumn()) {
            $errors['neighborhood_id'] = 'This neighborhood does not exist.';
        } else {
            $clean['neighborhood_id'] = $nid;
        }
    }

    /* bedrooms / bathrooms */
    $residential = $type !== null && in_array($type, AGENT_RESIDENTIAL_TYPES, true);
    foreach (['bedrooms' => 'Bedrooms', 'bathrooms' => 'Bathrooms'] as $field => $label) {
        $raw = $in[$field] ?? '';
        if (trim((string) $raw) === '') {
            if ($residential) {
                $errors[$field] = "$label is required.";
            } else {
                $clean[$field] = 0;
            }
            continue;
        }
        $n = agent_parse_int($raw);
        if ($n === null || $n > 30) {
            $errors[$field] = "$label must be a whole number from 0 to 30.";
        } elseif ($residential && $n < 1) {
            $errors[$field] = "$label must be at least 1 for this property type.";
        } else {
            $clean[$field] = $n;
        }
    }

    /* area */
    $area = agent_parse_number($in['area_m2'] ?? '');
    if ($area === null) {
        $errors['area_m2'] = 'Enter the area in square meters (numbers only).';
    } elseif ($area < 20 || $area > 100000) {
        $errors['area_m2'] = 'Area must be between 20 and 100,000 m².';
    } else {
        $clean['area_m2'] = $area;
    }

    /* price */
    $price = agent_parse_number($in['price'] ?? '');
    if ($price === null) {
        $errors['price'] = 'Enter the price in SAR (numbers only).';
    } elseif ($price < 1000 || $price > 5000000000) {
        $errors['price'] = 'Price must be between 1,000 and 5,000,000,000 SAR.';
    } else {
        $clean['price'] = $price;
    }

    return [$clean, $errors];
}

/* ---------- ownership ---------- */

const AGENT_PROPERTY_SELECT = '
    SELECT p.property_id, p.neighborhood_id, n.name_ar AS neighborhood_name_ar, n.name_en AS neighborhood_name_en,
           p.property_type, p.bedrooms, p.bathrooms, p.area_m2, p.price, p.created_at, p.updated_at
    FROM properties p
    LEFT JOIN neighborhoods n ON n.neighborhood_id = p.neighborhood_id';

/** Returns the property only if it belongs to this agent. Otherwise null (also when it does not exist). */
function agent_get_own_property(PDO $pdo, int $agentId, string $propertyId): ?array
{
    $stmt = $pdo->prepare(AGENT_PROPERTY_SELECT . ' WHERE p.property_id = ? AND p.agent_id = ?');
    $stmt->execute([$propertyId, $agentId]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return $row ? agent_format_property($row) : null;
}

function agent_format_property(array $row): array
{
    return [
        'property_id' => (string) $row['property_id'],
        'neighborhood_id' => (int) $row['neighborhood_id'],
        'neighborhood_name_ar' => $row['neighborhood_name_ar'],
        'neighborhood_name_en' => $row['neighborhood_name_en'],
        'property_type' => $row['property_type'],
        'property_type_en' => AGENT_PROPERTY_TYPES[$row['property_type']] ?? $row['property_type'],
        'bedrooms' => (int) $row['bedrooms'],
        'bathrooms' => (int) $row['bathrooms'],
        'area_m2' => (float) $row['area_m2'],
        'price' => (float) $row['price'],
        'created_at' => $row['created_at'],
        'updated_at' => $row['updated_at'],
    ];
}

/** New listing id in the same style as the dataset: one letter + 9 digits, e.g. A123456789. */
function agent_new_property_id(PDO $pdo): string
{
    $stmt = $pdo->prepare('SELECT 1 FROM properties WHERE property_id = ?');
    for ($i = 0; $i < 10; $i++) {
        $id = 'A' . str_pad((string) random_int(0, 999999999), 9, '0', STR_PAD_LEFT);
        $stmt->execute([$id]);
        if (!$stmt->fetchColumn()) {
            return $id;
        }
    }
    json_error(500, 'Could not create a listing id. Please try again.');
}
