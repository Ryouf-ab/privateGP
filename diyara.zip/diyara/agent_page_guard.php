<?php
/**
 * Guard for agent PAGES (HTML). Put this at the top of agent-dashboard.php and the add/edit property pages:
 *
 *   require 'agent_page_guard.php';   // stops the page unless a real estate agent is logged in
 *   require 'db.php';
 *
 * Not logged in        -> login page
 * Logged in, not agent -> "Access denied" page (HTTP 403)
 * Also prevents the browser from caching the page (Back button after logout).
 */
require_once __DIR__ . '/db.php';
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');

if (empty($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}
$__stmt = $pdo->prepare('SELECT role FROM users WHERE user_id = ?');
$__stmt->execute([$_SESSION['user_id']]);
$__role = $__stmt->fetchColumn();
if ($__role === false) {
    header('Location: logout.php');
    exit;
}
if ($__role !== 'agent') {
    http_response_code(403);
    $page_title = 'Access denied';
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1.0">'
       . '<title>Access denied | Diyara</title><link rel="stylesheet" href="diyara.css?v=72"></head><body>'
       . '<main style="max-width:520px;margin:15vh auto;padding:0 20px;text-align:center;font-family:\'DM Sans\',sans-serif">'
       . '<h1>Access denied</h1><p>This page is only available to real estate agents.</p>'
       . '<p><a href="index.php">Back to Home</a></p></main></body></html>';
    exit;
}
$_SESSION['role'] = $__role;
unset($__stmt, $__role);
