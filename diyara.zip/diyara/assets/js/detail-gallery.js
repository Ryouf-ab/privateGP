/* A progressive-enhancement image viewer; normal image links work without JS. */
'use strict';
document.addEventListener('DOMContentLoaded', () => {
  const gallery = document.querySelector('.dy-detail-photo-gallery');
  const dialog = document.getElementById('dyPhotoDialog');
  const dialogImage = document.getElementById('dyPhotoDialogImage');
  const caption = document.getElementById('dyPhotoDialogCaption');
  if (!gallery || !dialog || !dialogImage || !caption || typeof dialog.showModal !== 'function') return;

  gallery.querySelectorAll('.dy-detail-photo').forEach(link => {
    link.addEventListener('click', event => {
      event.preventDefault();
      dialogImage.src = link.href;
      dialogImage.alt = link.querySelector('img')?.alt || 'Illustrative property photograph';
      caption.textContent = `${link.dataset.photoTitle || 'Riyadh home'} · Illustrative image`;
      dialog.showModal();
    });
  });

  dialog.querySelector('.dy-photo-close')?.addEventListener('click', () => dialog.close());
  dialog.addEventListener('click', event => { if (event.target === dialog) dialog.close(); });
  dialog.addEventListener('close', () => { dialogImage.removeAttribute('src'); });
});
