/* Diyara recommendations: client-side exploration only.
   The existing filter.php and wsm.php continue to determine eligibility and scores. */
'use strict';
document.addEventListener('DOMContentLoaded', () => {
  const $ = id => document.getElementById(id);

  function propertyDiscovery() {
    const grid = $('pr-grid');
    if (!grid) return;
    const cards = [...grid.querySelectorAll('.pr-card')];
    const inputs = ['pr-search','pr-sort','dy-neighborhood','dy-type','dy-min-price','dy-max-price','dy-min-area','dy-min-beds','dy-match'];
    const box = id => $(id);
    const number = value => Number(value) || 0;
    const selected = () => [...grid.querySelectorAll('.pr-compare-check:checked')];
    const price = card => number(card.dataset.price);
    const aliases = {villa:['villa','فيلا'],apartment:['apartment','شقة']};
    const savedKey = 'diyara-property-compare';
    const favoritesKey = 'diyara-saved-property-ids';
    let favorites = [];
    try {
      const restored = JSON.parse(localStorage.getItem(favoritesKey) || '[]');
      if (Array.isArray(restored)) favorites = restored.filter(x => typeof x === 'string').slice(0,500);
    } catch (_) { /* storage disabled */ }
    function renderFavorites() {
      grid.querySelectorAll('.pr-favorite').forEach(button => {
        const saved = favorites.includes(button.dataset.propertyId);
        button.setAttribute('aria-pressed', String(saved));
        button.setAttribute('aria-label', saved ? 'Remove this saved property' : 'Save this property');
        button.innerHTML = saved ? '♥ <span>Saved</span>' : '♡ <span>Save</span>';
      });
    }

    function refresh() {
      const query = (box('pr-search')?.value ?? '').toLocaleLowerCase().trim();
      const type = box('dy-type').value;
      const neighborhood = box('dy-neighborhood').value;
      const minPrice = number(box('dy-min-price').value);
      const maxPrice = number(box('dy-max-price').value);
      const minArea = number(box('dy-min-area').value);
      const minBeds = number(box('dy-min-beds').value);
      const minMatch = number(box('dy-match').value);
      const savedOnly = !!box('dy-saved-only')?.checked;
      box('dy-match-value').textContent = `${minMatch}%`;
      const order = box('pr-sort').value;
      const sorters = {
        match:(a,b)=>number(b.dataset.match)-number(a.dataset.match),
        'price-asc':(a,b)=>price(a)-price(b),
        'price-desc':(a,b)=>price(b)-price(a),
        'area-desc':(a,b)=>number(b.dataset.area)-number(a.dataset.area),
        'area-asc':(a,b)=>number(a.dataset.area)-number(b.dataset.area),
        'beds-desc':(a,b)=>number(b.dataset.beds)-number(a.dataset.beds)
      };
      const sorted = [...cards].sort((a,b)=>(sorters[order] ?? sorters.match)(a,b) || cards.indexOf(a)-cards.indexOf(b));
      let shown = 0;
      for (const card of sorted) {
        grid.appendChild(card);
        const cardType = card.dataset.type || '';
        const typeMatches = !type || (type === 'both'
          ? [...aliases.villa,...aliases.apartment].some(t => cardType.includes(t))
          : (aliases[type] ?? []).some(t => cardType.includes(t)));
        const visible = (card.dataset.search ?? '').includes(query)
          && (!neighborhood || card.dataset.neighborhood === neighborhood)
          && typeMatches
          && (!minPrice || price(card) >= minPrice)
          && (!maxPrice || price(card) <= maxPrice)
          && (!minArea || number(card.dataset.area) >= minArea)
          && (!minBeds || number(card.dataset.beds) >= minBeds)
          && (!savedOnly || favorites.includes(card.querySelector('.pr-favorite')?.dataset.propertyId))
          && number(card.dataset.match) >= minMatch;
        card.hidden = !visible;
        if (visible) shown++;
      }
      if (box('pr-count')) box('pr-count').textContent = `${shown} of ${cards.length} matching properties`;
      if (box('pr-no-results')) box('pr-no-results').hidden = shown !== 0;
    }

    grid.querySelectorAll('.pr-favorite').forEach(button => button.addEventListener('click', () => {
      const id = button.dataset.propertyId;
      if (!id) return;
      favorites = favorites.includes(id) ? favorites.filter(x => x !== id) : [...favorites,id];
      try { localStorage.setItem(favoritesKey, JSON.stringify(favorites)); } catch (_) { /* storage disabled */ }
      renderFavorites();
      refresh();
    }));

    function saveSelection(ids) {
      try { sessionStorage.setItem(savedKey, JSON.stringify(ids)); } catch (_) { /* browsing restrictions */ }
    }
    function updateComparison() {
      const chosen = selected();
      const ready = chosen.length === 2 && chosen[0].value !== chosen[1].value;
      const compare = box('pr-compare-button');
      const clear = box('pr-compare-clear');
      if (compare) { compare.disabled = !ready; compare.textContent = `Compare Properties (${chosen.length}/2)`; }
      if (clear) clear.disabled = chosen.length === 0;
      const names = chosen.map(input => {
        const card = input.closest('.pr-card');
        return [card?.querySelector('h3')?.textContent.trim(),card?.querySelector('.pr-location')?.textContent.replace('Location:','').trim()].filter(Boolean).join(' · ');
      });
      if (box('pr-compare-names')) box('pr-compare-names').textContent = names.join('  vs  ') || 'Choose two homes from the cards above.';
      saveSelection(chosen.map(input => input.value));
    }
    try {
      const previous = JSON.parse(sessionStorage.getItem(savedKey) || '[]');
      if (Array.isArray(previous)) grid.querySelectorAll('.pr-compare-check').forEach(input => { input.checked = previous.slice(0,2).includes(input.value); });
    } catch (_) { /* no stored comparison */ }
    grid.querySelectorAll('.pr-compare-check').forEach(input => input.addEventListener('change', () => {
      if (selected().length > 2) { input.checked = false; input.setAttribute('aria-invalid','true'); }
      else input.removeAttribute('aria-invalid');
      updateComparison();
    }));
    box('pr-compare-clear')?.addEventListener('click', () => {
      grid.querySelectorAll('.pr-compare-check').forEach(input => { input.checked = false; input.removeAttribute('aria-invalid'); });
      updateComparison();
    });
    box('pr-compare-button')?.addEventListener('click', () => {
      const chosen = selected();
      if (chosen.length === 2 && chosen[0].value !== chosen[1].value) {
        const params = new URLSearchParams({a:chosen[0].value,b:chosen[1].value});
        window.location.assign(`property-compare.php?${params.toString()}`);
      }
    });
    inputs.forEach(id => $(id)?.addEventListener(['pr-sort','dy-neighborhood','dy-type'].includes(id) ? 'change' : 'input', refresh));
    box('dy-saved-only')?.addEventListener('change', refresh);
    function reset() {
      ['pr-search','dy-neighborhood','dy-type','dy-min-price','dy-max-price','dy-min-area','dy-min-beds'].forEach(id => { if ($(id)) $(id).value = ''; });
      if (box('dy-match')) box('dy-match').value = '0';
      if (box('dy-saved-only')) box('dy-saved-only').checked = false;
      if (box('pr-sort')) box('pr-sort').value = 'match';
      refresh();
    }
    box('dy-reset')?.addEventListener('click', reset);
    box('dy-empty-reset')?.addEventListener('click', reset);
    renderFavorites();
    refresh();
    updateComparison();
  }

  function neighborhoodDiscovery() {
    const grid = $('nrGrid');
    if (!grid) return;
    const cards = [...grid.querySelectorAll('.nr-card')];
    const checks = [...grid.querySelectorAll('.nr-compare-check')];
    const selected = () => checks.filter(input => input.checked);
    const key = 'diyara-neighborhood-compare';
    function save(ids) { try { sessionStorage.setItem(key, JSON.stringify(ids)); } catch (_) {} }
    function updateComparison() {
      const chosen = selected();
      const ready = chosen.length === 2 && chosen[0].value !== chosen[1].value;
      const names = chosen.map(c => c.closest('.nr-card')?.querySelector('.nr-name')?.textContent.trim() || c.value);
      if ($('nrBarCount')) $('nrBarCount').textContent = `(${chosen.length}/2)`;
      if ($('nrSelectedNames')) $('nrSelectedNames').textContent = names.join('  vs  ') || 'Choose two neighborhoods';
      if ($('nrFormA')) $('nrFormA').value = ready ? chosen[0].value : '';
      if ($('nrFormB')) $('nrFormB').value = ready ? chosen[1].value : '';
      if ($('nrBarGo')) $('nrBarGo').disabled = !ready;
      if ($('nrClear')) $('nrClear').disabled = chosen.length === 0;
      save(chosen.map(c => c.value));
    }
    try {
      const saved = JSON.parse(sessionStorage.getItem(key) || '[]');
      if (Array.isArray(saved)) checks.forEach(c => { c.checked = saved.slice(0,2).includes(c.value); });
    } catch (_) {}
    checks.forEach(input => input.addEventListener('change', () => {
      if (selected().length > 2) { input.checked = false; input.setAttribute('aria-invalid','true'); }
      else input.removeAttribute('aria-invalid');
      updateComparison();
    }));
    $('nrClear')?.addEventListener('click', () => {
      checks.forEach(c => { c.checked = false; c.removeAttribute('aria-invalid'); });
      updateComparison();
    });
    $('nrCompareForm')?.addEventListener('submit', event => {
      updateComparison();
      if (selected().length !== 2 || !$('nrFormA').value || !$('nrFormB').value) event.preventDefault();
    });
    function refresh() {
      const query = ($('nrSearch')?.value ?? '').toLocaleLowerCase().trim();
      const region = $('nrRegion')?.value ?? '';
      const level = $('nrLevel')?.value ?? '';
      const order = $('nrSort')?.value ?? 'score';
      const sorted = [...cards].sort((a,b) => {
        if (order === 'name') return (a.dataset.name ?? '').localeCompare(b.dataset.name ?? '',undefined,{sensitivity:'base'});
        const diff = Number(b.dataset.score) - Number(a.dataset.score);
        return order === 'score-low' ? -diff : diff;
      });
      let shown = 0;
      for (const card of sorted) {
        grid.appendChild(card);
        const visible = (card.dataset.search ?? '').includes(query)
          && (!region || card.dataset.region === region)
          && (!level || card.dataset.level === level);
        card.hidden = !visible;
        if (visible) shown++;
      }
      if ($('nrCount')) $('nrCount').textContent = `${shown} of ${cards.length} neighborhoods`;
      if ($('nrNoResults')) $('nrNoResults').hidden = shown !== 0;
    }
    ['nrSearch','nrRegion','nrLevel','nrSort'].forEach(id => $(id)?.addEventListener(id === 'nrSearch' ? 'input' : 'change', refresh));
    $('nrReset')?.addEventListener('click', () => {
      ['nrSearch','nrRegion','nrLevel'].forEach(id => { if ($(id)) $(id).value = ''; });
      if ($('nrSort')) $('nrSort').value = 'score';
      refresh();
    });
    refresh();
    updateComparison();
  }

  propertyDiscovery();
  neighborhoodDiscovery();
});
