// Filter visible listings.
document.querySelectorAll('[data-listing-view]').forEach(view => {
    const grid = view.querySelector('[data-listing-grid]');
    if (!grid) return;
    const cards = Array.from(grid.children);
    const filters = view.querySelectorAll('[data-filter], [data-min], [data-max]');
    const neighborhoods = view.querySelectorAll('[name="neighborhood_filter[]"]');
    const search = view.querySelector('[data-listing-search]');
    const sort = view.querySelector('[data-listing-sort]');
    const count = view.querySelector('[data-listing-count]');
    const empty = view.querySelector('[data-listing-empty]');

  const searchKey = value => value.toLowerCase().normalize('NFD').replace(/\p{M}|ـ/gu, '').replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
    // Apply current filters.
    function update() {
        const chosen = new Set(Array.from(neighborhoods).filter(input => input.checked).map(input => input.value));
        const caption = view.querySelector("[data-area-caption]");
        if (caption) caption.textContent = chosen.size ? chosen.size + " selected" : "All neighborhoods";
        const term = searchKey(search?.value ?? '');
        let visible = 0;
        for (const card of cards) {
            const meetsFilters = Array.from(filters).every(input => {
                if (input.value === '') return true;
                if (input.dataset.filter) return card.dataset[input.dataset.filter] === input.value;
                const field = input.dataset.min ?? input.dataset.max;
                if (!card.dataset[field]) return false;
                const value = Number(card.dataset[field]);
                return input.dataset.min ? value >= Number(input.value) : value <= Number(input.value);
            });
            card.hidden = !(meetsFilters && (!chosen.size || chosen.has(card.dataset.neighborhood))
                && (!term || searchKey(card.dataset.search ?? '').includes(term)));
            if (!card.hidden) visible++;
        }
        if (count) count.textContent = visible + ' properties';
        if (empty) empty.hidden = visible !== 0;
    }

    // Keep server ordering for match.
    function applySort() {
        const key = sort?.value;
        const ranked = [...cards];
        if (['price-asc', 'price-desc', 'price_low', 'price_high'].includes(key)) {
            ranked.sort((a, b) => {
                const first = Number(a.dataset.price);
                const second = Number(b.dataset.price);
                if (!first || !second) return Number(Boolean(second)) - Number(Boolean(first));
                return key === 'price-asc' || key === 'price_low' ? first - second : second - first;
            });
        } else if (key === 'name_az' || key === 'name_za') {
            const order = key === 'name_az' ? 1 : -1;
            ranked.sort((a, b) => order * (a.dataset.name ?? '').localeCompare(b.dataset.name ?? '', 'en'));
        } else if (key === 'area-desc') {
            ranked.sort((a, b) => Number(b.dataset.area) - Number(a.dataset.area));
        }
        grid.append(...ranked);
    }

    [...filters, ...neighborhoods, ...(search ? [search] : [])].forEach(input => input.addEventListener('input', update));
    sort?.addEventListener('change', applySort);
    view.querySelector('[data-reset-listings]')?.addEventListener('click', () => {
        filters.forEach(input => { input.value = ''; });
        neighborhoods.forEach(input => { input.checked = false; });
        if (search) search.value = '';
        update();
    });
});
