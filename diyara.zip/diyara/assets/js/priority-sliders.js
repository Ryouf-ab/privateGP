'use strict';
document.addEventListener('DOMContentLoaded', () => {
  const labels = ['Not required', 'Very low priority', 'Low priority', 'Moderate priority', 'High priority', 'Essential to me'];
  document.querySelectorAll('.service-priority-slider').forEach(slider => {
    const card = slider.closest('.service-priority-card');
    const output = card?.querySelector('.service-priority-value');
    const description = card?.querySelector('.service-priority-description');
    const refresh = () => {
      const value = Number(slider.value);
      slider.style.setProperty('--slider-progress', `${value * 20}%`);
      if (card?.dataset) card.dataset.priorityActive = value > 0 ? 'true' : 'false';
      if (output) output.textContent = `${value}/5`;
      if (description) description.textContent = labels[value] ?? labels[0];
      slider.setAttribute('aria-valuetext', `${value} out of 5. ${labels[value] ?? labels[0]}`);
    };
    slider.addEventListener('input', refresh);
    refresh();
  });
});

// Update the visible summary. This does not change PHP field names or saved weights.
document.addEventListener('DOMContentLoaded', () => {
  if (typeof document.querySelector !== 'function') return;
  const sliders = [...document.querySelectorAll('.service-priority-slider')];
  const summary = document.querySelector('.service-priority-summary');
  if (!summary || !sliders.length) return;
  const refresh = () => {
    const active = sliders.filter(slider => Number(slider.value) > 0).length;
    summary.textContent = active
      ? `${active} of ${sliders.length} services prioritized. Recommendations use your selected priorities.`
      : 'Choose at least one service above 0 to get personalized recommendations.';
    summary.style.borderLeftColor = active ? '#985e76' : '#b64d47';
  };
  sliders.forEach(slider => slider.addEventListener('input', refresh));
  refresh();
});
