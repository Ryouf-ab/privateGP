(() => {
    const root = document.documentElement;
    const key = 'diyara-theme';
    try {
        if (localStorage.getItem(key) === 'dark') root.dataset.theme = 'dark';
    } catch {}

    document.addEventListener('DOMContentLoaded', () => {
        const nav = document.querySelector('.site-topbar .topbar-nav');
        if (!nav) return;
        const button = document.createElement('button');
        button.type = 'button';
        button.className = 'dy-theme-toggle';
        button.setAttribute('aria-label', 'Dark mode');
        const icon = document.createElement('span');
        icon.setAttribute('aria-hidden', 'true');
        button.appendChild(icon);
        const label = document.createElement('span');
        label.textContent = 'Dark mode';
        button.appendChild(label);

        function update() {
            const dark = root.dataset.theme === 'dark';
            button.setAttribute('aria-pressed', String(dark));
            icon.textContent = dark ? '☀' : '☾';
            button.title = dark ? 'Switch to light mode' : 'Switch to dark mode';
        }

        button.addEventListener('click', () => {
            const next = root.dataset.theme === 'dark' ? 'light' : 'dark';
            root.dataset.theme = next;
            try { localStorage.setItem(key, next); } catch {}
            update();
        });
        update();
        nav.appendChild(button);
    });
})();
