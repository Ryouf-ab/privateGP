<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
if (!isset($_SESSION['user_id'])) {
    header('Location: login.html');
    exit;
}
// Prevent showing cached pages after logout (Back button)
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Pragma: no-cache');
