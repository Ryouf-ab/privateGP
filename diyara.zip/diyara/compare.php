<?php
/**
 * DIYARA - Detailed neighborhood comparison (Sprint 2)
 *
 * Compares two neighborhoods side by side using the neighborhoods table:
 * services inside each neighborhood, real-estate prices, and what makes
 * each one stand out compared with the rest of Riyadh.
 *
 * Open it as: compare.php?a=<neighborhood_id>&b=<neighborhood_id>
 * (the recommendations page sends the two neighborhoods ticked in "Compare").
 */
require 'auth_check.php';
require 'db.php';

$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header('Location: login.html');
    exit;
}

function cmp_e($value)
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

function cmp_name(array $n): string
{
    return (string) ($n['name_en'] ?: $n['name_ar']);
}

/*
 * Every row of the comparison table.
 * better: 'high' = the bigger number wins, 'low' = the smaller number wins (prices).
 * service: the lifestyle "required service" this row belongs to, so rows the
 * user marked as important can be highlighted.
 */
$groups = [
    'Education' => [
        ['schools_count',     'Schools (all stages)', 'high', 'Schools'],
        ['schools_primary',   'Primary schools',      'high', 'Schools'],
        ['schools_middle',    'Middle schools',       'high', 'Schools'],
        ['schools_secondary', 'Secondary schools',    'high', 'Schools'],
    ],
    'Healthcare' => [
        ['hospitals_count',  'Hospitals',  'high', 'Healthcare'],
        ['clinics_count',    'Clinics',    'high', 'Healthcare'],
        ['pharmacies_count', 'Pharmacies', 'high', 'Healthcare'],
    ],
    'Daily life' => [
        ['supermarkets_count',     'Supermarkets',     'high', 'Supermarkets'],
        ['shopping_centers_count', 'Shopping centers', 'high', null],
        ['banks_count',            'Banks',            'high', 'Banks'],
        ['fuel_stations_count',    'Gas stations',     'high', 'Gas Stations'],
    ],
    'Lifestyle' => [
        ['parks_count', 'Parks', 'high', 'Parks'],
        ['gyms_count',  'Gyms',  'high', null],
    ],
    'Transport' => [
        ['metro_stations_count', 'Metro stations', 'high', null],
    ],
    'Prices' => [
        ['median_price_m2',        'Median price per m² (MOJ deals)', 'low',  null],
        ['median_apartment_price', 'Median apartment price',          'low',  null],
        ['median_villa_price',     'Median villa price',              'low',  null],
        ['median_floor_price',     'Median floor price',              'low',  null],
        ['listings_count',         'Listings on Diyara',              'high', null],
        ['deals_count',            'Recorded MOJ deals',              'high', null],
    ],
];
$priceColumns = ['median_price_m2', 'median_apartment_price', 'median_villa_price', 'median_floor_price'];

/* Short labels used in the "What stands out" lists. */
$highlightLabels = [
    'schools_count'          => 'schools',
    'hospitals_count'        => 'hospitals',
    'clinics_count'          => 'clinics',
    'pharmacies_count'       => 'pharmacies',
    'supermarkets_count'     => 'supermarkets',
    'shopping_centers_count' => 'shopping centers',
    'parks_count'            => 'parks',
    'gyms_count'             => 'gyms',
    'metro_stations_count'   => 'metro stations',
];

$idA = filter_input(INPUT_GET, 'a', FILTER_VALIDATE_INT) ?: null;
$idB = filter_input(INPUT_GET, 'b', FILTER_VALIDATE_INT) ?: null;

$all = [];
$a = null;
$b = null;
$importantServices = [];
$errorMessage = '';

try {
    $all = $pdo->query('SELECT * FROM neighborhoods ORDER BY COALESCE(name_en, name_ar)')
        ->fetchAll(PDO::FETCH_ASSOC);

    foreach ($all as $row) {
        if ((int) $row['neighborhood_id'] === $idA) { $a = $row; }
        if ((int) $row['neighborhood_id'] === $idB) { $b = $row; }
    }

    /*
     * Services the user marked as required in the lifestyle questionnaire.
     * Works with the Sprint 1 format (["Schools","Parks"]) and with the
     * Sprint 2 rating format ({"Schools":5,"Parks":2}); ratings of 4-5 count
     * as important.
     */
    $stmt = $pdo->prepare('SELECT required_services FROM lifestyle_preferences WHERE user_id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $raw = $stmt->fetchColumn();
    $decoded = $raw ? json_decode($raw, true) : null;
    if (is_array($decoded)) {
        if (array_is_list($decoded)) {
            $importantServices = array_map('strval', $decoded);
        } else {
            foreach ($decoded as $service => $rating) {
                if ((int) $rating >= 4) { $importantServices[] = (string) $service; }
            }
        }
    }
} catch (Throwable $e) {
    error_log('DIYARA compare error: ' . $e->getMessage());
    if (!$all) {
        $errorMessage = 'We could not load neighborhood data. Please check your database configuration and try again.';
    }
}

/* Share of Riyadh neighborhoods that have a smaller value (0-100). */
function cmp_percentile(array $all, string $column, $value): ?int
{
    if ($value === null) { return null; }
    $values = [];
    foreach ($all as $row) {
        if ($row[$column] !== null) { $values[] = (float) $row[$column]; }
    }
    if (count($values) < 2) { return null; }
    $below = 0;
    foreach ($values as $v) {
        if ($v < (float) $value) { $below++; }
    }
    return (int) round($below / count($values) * 100);
}

/* Builds "What stands out" and "Good to know" lists for one neighborhood. */
function cmp_profile(array $n, array $other, array $all, array $labels): array
{
    $strengths = [];
    $gaps = [];
    $name = cmp_name($other);

    foreach ($labels as $column => $label) {
        $value = (int) ($n[$column] ?? 0);
        $otherValue = (int) ($other[$column] ?? 0);
        $pct = cmp_percentile($all, $column, $value);
        if ($value > 0 && $pct !== null && $pct >= 75) {
            $strengths[] = ['score' => $pct, 'text' => "More {$label} ({$value}) than {$pct}% of Riyadh neighborhoods."];
        } elseif ($value > 0 && $otherValue === 0) {
            $strengths[] = ['score' => 50, 'text' => "Has {$label} ({$value}); {$name} has none."];
        }
        if ($value === 0 && in_array($column, ['hospitals_count', 'parks_count', 'metro_stations_count', 'schools_count', 'supermarkets_count'], true)) {
            $gaps[] = "No {$label} recorded inside the neighborhood.";
        }
    }

    if ($n['median_price_m2'] !== null) {
        $pct = cmp_percentile($all, 'median_price_m2', $n['median_price_m2']);
        if ($pct !== null && $pct <= 30) {
            $strengths[] = ['score' => 100 - $pct, 'text' => 'Price per m² is lower than ' . (100 - $pct) . '% of Riyadh neighborhoods.'];
        } elseif ($pct !== null && $pct >= 75) {
            $gaps[] = "Price per m² is higher than {$pct}% of Riyadh neighborhoods.";
        }
    } else {
        $gaps[] = 'No recorded MOJ deals, so the price per m² is not available.';
    }

    if ($n['median_price_m2'] !== null && $other['median_price_m2'] !== null
        && (float) $n['median_price_m2'] < (float) $other['median_price_m2']) {
        $diff = round((1 - (float) $n['median_price_m2'] / (float) $other['median_price_m2']) * 100);
        $strengths[] = ['score' => 60, 'text' => "About {$diff}% cheaper per m² than {$name}."];
    }

    if ((int) $n['listings_count'] === 0) {
        $gaps[] = 'No property listings on Diyara yet.';
    }

    usort($strengths, static fn($x, $y) => $y['score'] <=> $x['score']);
    return [
        'strengths' => array_slice(array_column($strengths, 'text'), 0, 4),
        'gaps' => array_slice($gaps, 0, 4),
    ];
}

/* 'a', 'b', 'tie' or null when the row cannot be compared. */
function cmp_winner($va, $vb, string $better): ?string
{
    if ($va === null || $vb === null) { return null; }
    $va = (float) $va;
    $vb = (float) $vb;
    if ($va == $vb) { return 'tie'; }
    if ($better === 'low') { return $va < $vb ? 'a' : 'b'; }
    return $va > $vb ? 'a' : 'b';
}

function cmp_value($value, string $column, array $priceColumns): string
{
    if ($value === null || $value === '') { return 'Not available'; }
    if (in_array($column, $priceColumns, true)) {
        return number_format((float) $value) . ' SAR';
    }
    return number_format((float) $value);
}

$ready = $a && $b && $idA !== $idB;
$rows = [];
$serviceWins = ['a' => 0, 'b' => 0, 'total' => 0];
if ($ready) {
    foreach ($groups as $group => $items) {
        foreach ($items as [$column, $label, $better, $service]) {
            $winner = cmp_winner($a[$column], $b[$column], $better);
            if ($group !== 'Prices' && $winner !== null) {
                $serviceWins['total']++;
                if ($winner === 'a' || $winner === 'b') { $serviceWins[$winner]++; }
            }
            $rows[$group][] = [
                'column' => $column,
                'label' => $label,
                'winner' => $winner,
                'important' => $service !== null && in_array($service, $importantServices, true),
            ];
        }
    }
    $profileA = cmp_profile($a, $b, $all, $highlightLabels);
    $profileB = cmp_profile($b, $a, $all, $highlightLabels);
}

$page_title = 'Compare Neighborhoods';
$active = 'recommendations';
require 'includes/header.php';
?>
<link rel="stylesheet" href="recommendations-extra.css">
<link rel="stylesheet" href="compare.css">
<section class="page page-shared cmp-page">
    <div class="container">
        <a class="rec-detail-link" href="recommendations.php">← Back to Recommendations</a>
        <div class="rec-hero cmp-hero">
            <span class="rec-eyebrow">DETAILED COMPARISON</span>
            <h1>Compare Neighborhoods</h1>
            <p>See the services, prices and strengths of two Riyadh neighborhoods side by side.</p>
        </div>

        <?php if ($errorMessage !== ''): ?>
            <div class="empty"><p><?php echo cmp_e($errorMessage); ?></p></div>
        <?php else: ?>
            <form class="cmp-picker" method="get" action="compare.php">
                <?php foreach (['a' => $idA, 'b' => $idB] as $key => $selectedId): ?>
                    <label class="rec-field">Neighborhood <?php echo $key === 'a' ? '1' : '2'; ?>
                        <select name="<?php echo $key; ?>" required>
                            <option value="">Choose a neighborhood…</option>
                            <?php foreach ($all as $n): ?>
                                <option value="<?php echo (int) $n['neighborhood_id']; ?>"<?php echo (int) $n['neighborhood_id'] === $selectedId ? ' selected' : ''; ?>>
                                    <?php echo cmp_e(cmp_name($n)); ?><?php if ($n['name_en']): ?> · <?php echo cmp_e($n['name_ar']); ?><?php endif; ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </label>
                <?php endforeach; ?>
                <button class="btn" type="submit">Compare</button>
            </form>

            <?php if (!$ready): ?>
                <div class="empty">
                    <p>
                        <?php if ($idA && $idB && $idA === $idB): ?>
                            Please choose two different neighborhoods.
                        <?php elseif (($idA && !$a) || ($idB && !$b)): ?>
                            One of the selected neighborhoods was not found. Please choose again.
                        <?php else: ?>
                            Choose two neighborhoods above, or tick Compare on two neighborhoods in your recommendations.
                        <?php endif; ?>
                    </p>
                </div>
            <?php else: ?>
                <div class="cmp-heads">
                    <?php foreach (['a' => [$a, $profileA], 'b' => [$b, $profileB]] as $key => [$n, $profile]): ?>
                        <article class="rec-neighborhood cmp-head cmp-head-<?php echo $key; ?>">
                            <span class="rec-eyebrow">NEIGHBORHOOD <?php echo $key === 'a' ? '1' : '2'; ?></span>
                            <h2><?php echo cmp_e(cmp_name($n)); ?></h2>
                            <p class="rec-subtitle"><?php echo cmp_e($n['name_ar']); ?><?php if (!empty($n['region'])): ?> · <?php echo cmp_e($n['region']); ?><?php endif; ?></p>
                            <div class="cmp-stats">
                                <span>Services ahead <strong><?php echo $serviceWins[$key]; ?>/<?php echo $serviceWins['total']; ?></strong></span>
                                <span>Price per m² <strong><?php echo $n['median_price_m2'] !== null ? number_format((float) $n['median_price_m2']) . ' SAR' : 'N/A'; ?></strong></span>
                                <span>Listings <strong><?php echo (int) $n['listings_count']; ?></strong></span>
                            </div>
                            <h3>What stands out</h3>
                            <?php if ($profile['strengths']): ?>
                                <ul class="cmp-list cmp-good"><?php foreach ($profile['strengths'] as $text): ?><li><?php echo cmp_e($text); ?></li><?php endforeach; ?></ul>
                            <?php else: ?>
                                <p class="cmp-none">No service is clearly above the Riyadh average.</p>
                            <?php endif; ?>
                            <?php if ($profile['gaps']): ?>
                                <h3>Good to know</h3>
                                <ul class="cmp-list cmp-gap"><?php foreach ($profile['gaps'] as $text): ?><li><?php echo cmp_e($text); ?></li><?php endforeach; ?></ul>
                            <?php endif; ?>
                        </article>
                    <?php endforeach; ?>
                </div>

                <div class="rec-neighborhood cmp-table-card">
                    <div class="cmp-table-top">
                        <h2>Side by side</h2>
                        <p class="cmp-legend"><span class="cmp-dot"></span> better value<?php if ($importantServices): ?> · <span class="cmp-star">★</span> a service you marked as required<?php endif; ?></p>
                    </div>
                    <div class="rec-compare-scroll">
                        <table class="cmp-table">
                            <thead>
                                <tr>
                                    <th scope="col">Feature</th>
                                    <th scope="col"><?php echo cmp_e(cmp_name($a)); ?></th>
                                    <th scope="col"><?php echo cmp_e(cmp_name($b)); ?></th>
                                </tr>
                            </thead>
                            <?php foreach ($rows as $group => $items): ?>
                                <tbody>
                                    <tr class="cmp-group"><th colspan="3" scope="colgroup"><?php echo cmp_e($group); ?></th></tr>
                                    <?php foreach ($items as $row): ?>
                                        <tr<?php echo $row['important'] ? ' class="cmp-important"' : ''; ?>>
                                            <th scope="row"><?php echo $row['important'] ? '<span class="cmp-star" title="You marked this service as required">★</span> ' : ''; ?><?php echo cmp_e($row['label']); ?></th>
                                            <td class="<?php echo $row['winner'] === 'a' ? 'cmp-win' : ''; ?>"><?php echo cmp_value($a[$row['column']], $row['column'], $priceColumns); ?></td>
                                            <td class="<?php echo $row['winner'] === 'b' ? 'cmp-win' : ''; ?>"><?php echo cmp_value($b[$row['column']], $row['column'], $priceColumns); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            <?php endforeach; ?>
                        </table>
                    </div>
                    <p class="rec-explain-note"></p>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</section>
<?php require 'includes/footer.php'; ?>
