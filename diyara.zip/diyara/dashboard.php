<?php
// Kept so login.php's redirect keeps working. Home page is index.php.
header('Location: index.php');
exit;
