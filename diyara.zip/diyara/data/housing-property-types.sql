-- Widen older preference columns for multiple selected values.
ALTER TABLE housing_preferences MODIFY COLUMN property_type VARCHAR(64);
