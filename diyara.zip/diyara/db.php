<?php
// MAMP on the project's testing machine uses MySQL 8889 (Apache is 8888).
// Team members running MySQL on a different port can set DIYARA_DB_PORT.
$diyaraDbPort = getenv('DIYARA_DB_PORT') ?: '8889';
$pdo = new PDO(
    'mysql:host=127.0.0.1;port=' . $diyaraDbPort . ';dbname=diyara_db;charset=utf8mb4',
    'root',
    'root',
    [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
);
