<?php

require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];

$message = '';
$error = '';


/* =========================================================
GET USER
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        name,
        email
    FROM users
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$user =
    $stmt->fetch(PDO::FETCH_ASSOC);


if (!$user) {

    header('Location: logout.php');
    exit;
}


$form_name =
    $user['name'];

$form_email =
    $user['email'];


/* =========================================================
UPDATE PROFILE
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $form_name =
        trim($_POST['name'] ?? '');

    $form_email =
        trim($_POST['email'] ?? '');


    if ($form_name === '') {

        $error =
            'Please enter your full name.';

    } elseif (
        strlen($form_name) < 2
    ) {

        $error =
            'Full name must contain at least 2 characters.';

    } elseif (
        strlen($form_name) > 100
    ) {

        $error =
            'Full name must not exceed 100 characters.';

    } elseif ($form_email === '') {

        $error =
            'Please enter your email address.';

    } elseif (
        !filter_var(
            $form_email,
            FILTER_VALIDATE_EMAIL
        )
    ) {

        $error =
            'Please enter a valid email address.';

    } elseif (
        strlen($form_email) > 150
    ) {

        $error =
            'Email address is too long.';

    } else {


        /* =================================================
        CHECK EMAIL UNIQUENESS
        ================================================= */

        $stmt = $pdo->prepare("
            SELECT user_id
            FROM users
            WHERE email = ?
            AND user_id != ?
        ");

        $stmt->execute([
            $form_email,
            $user_id
        ]);

        $existing_user =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if ($existing_user) {

            $error =
                'This email address is already in use.';

        } else {


            /* =============================================
            UPDATE USER
            ============================================= */

            $stmt = $pdo->prepare("
                UPDATE users

                SET
                    name = ?,
                    email = ?

                WHERE user_id = ?
            ");

            $stmt->execute([
                $form_name,
                $form_email,
                $user_id
            ]);


            /*
            Update the session name because
            Person 1's navbar/session also uses it.
            */

            $_SESSION['name'] =
                $form_name;


            $message =
                'Profile updated successfully.';
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Edit Profile | Diyara
</title>


<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
rel="stylesheet"
>

<link
rel="stylesheet"
href="diyara.css?v=71"
>

</head>


<body class="page-edit-profile">


<header class="site-topbar">


<div class="topbar-brand">

<div class="topbar-logo-slot"></div>

<div class="topbar-brand-text">

<strong>Diyara</strong>

<span>Live where you belong.</span>

</div>

</div>


<nav class="topbar-nav">

<a
href="index.php"
class="topbar-link"
>
Home
</a>

<a
href="recommendations.php"
class="topbar-link"
>
Recommendations
</a>

<a
href="profile.php"
class="topbar-link active"
>
My Profile
</a>

<a
href="logout.php"
class="topbar-link"
>
Logout
</a>

</nav>


</header>



<main class="page-body edit-pattern-page">


<div class="edit-pattern-grid">


<section class="edit-main-card">


<div class="edit-intro">


<div class="section-label">

<span></span>

ACCOUNT SETTINGS

</div>


<h1>
Edit Profile
</h1>


<p>
Keep your personal information accurate
so your Diyara account stays up to date.
</p>


</div>



<?php if ($message): ?>


<div class="notification success-message">

<div class="notification-icon">
✓
</div>

<div>

<strong>
Updated successfully
</strong>

<p>

<?php
echo htmlspecialchars(
    $message,
    ENT_QUOTES,
    'UTF-8'
);
?>

</p>

</div>

</div>


<?php endif; ?>



<?php if ($error): ?>


<div class="notification error-message">

<div class="notification-icon">
!
</div>

<div>

<strong>
Please check your information
</strong>

<p>

<?php
echo htmlspecialchars(
    $error,
    ENT_QUOTES,
    'UTF-8'
);
?>

</p>

</div>

</div>


<?php endif; ?>



<form
method="POST"
class="edit-card"
>


<div class="edit-card-header">


<div>

<span class="card-number">
01
</span>

<h2>
Personal Information
</h2>

</div>


<p>
<span>*</span>
Required fields
</p>


</div>



<div class="form-grid two-column">


<div class="input-group">


<label for="name">

Full Name

<span>*</span>

</label>


<input
type="text"
id="name"
name="name"
maxlength="100"
autocomplete="name"
placeholder="Enter your full name"
value="<?php
echo htmlspecialchars(
    $form_name,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


<small>
Use the name displayed
on your Diyara profile.
</small>


</div>



<div class="input-group">


<label for="email">

Email Address

<span>*</span>

</label>


<input
type="email"
id="email"
name="email"
maxlength="150"
autocomplete="email"
placeholder="name@example.com"
value="<?php
echo htmlspecialchars(
    $form_email,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


<small>
This email must be unique
and valid.
</small>


</div>


</div>



<div class="form-actions">


<a
href="profile.php"
class="button cancel-button"
>
Cancel
</a>


<button
type="submit"
class="button continue-button"
>
Save Changes →
</button>


</div>


</form>


</section>



<aside class="edit-pattern-side">


<div class="edit-side-word">

DIYARA
<br>
RIYADH

</div>


<div class="edit-side-copy">


<span>
DIYARA · ACCOUNT
</span>


<h3 dir="rtl">
حدّث تفاصيلك،
وخلك على راحتك.
</h3>


</div>


</aside>


</div>


</main>



<footer class="diyara-footer">


<div class="footer-brand">

<div class="footer-mark"></div>

<div>

<strong>Diyara</strong>

<span>Live where you belong.</span>

</div>

</div>


<div class="footer-center">

<strong dir="rtl">
ديارٍ تشبهك، وحيٍّ يناسبك.
</strong>

<span>
Riyadh · Heritage · Future
</span>

</div>


<div class="footer-end">

<span class="footer-line"></span>

<p>
Riyadh, Saudi Arabia
<br>
© 2026 Diyara
</p>

</div>


</footer>


</body>

</html>