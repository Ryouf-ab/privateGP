<?php
/**
 * Diyara: accessible explanation of a WSM neighborhood result.
 *
 * neighborhood-recommendations.php calls nr_render_explanation($item) once per neighborhood card,
 * where $item is one result of get_wsm_neighborhoods() (wsm.php):
 *   neighborhood_id, name_ar, name_en, region, suitability_score, suitability_level, rank,
 *   service_contributions => [ 'Schools' => [count, weight, normalized, points], ... ]
 *
 * The explanation module supplies qualitative interpretation only.
 * MODULE CONTRACT:
 *   Create explanation.php next to this file with:
 *       function diyara_explain_neighborhood(array $item, array $allResults): array|string
 *   - Return a STRING  -> it is printed as-is inside the expandable section (your own HTML component).
 *   - Return an ARRAY  -> this file draws it. Keys (all optional):
 *       'summary'      => string        one-sentence reason it is recommended
 *       'limitations'  => string[]      specific trade-offs affecting its level
 *   Property match and neighborhood suitability are separate calculations.
 */

require_once __DIR__ . '/includes/bilingual-explanation.php';

if (is_file(__DIR__ . '/explanation.php')) {
    require_once __DIR__ . '/explanation.php';
}

// Escape explanation text.
function nr_x_escape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

// Render detail list.
function nr_x_list(string $title, array $items, string $class): string
{
    $items = array_values(array_filter(array_map('strval', $items), static fn($s) => trim($s) !== ''));
    if (!$items) {
        return '';
    }
    $html = '<div class="nrx-block ' . $class . '"><h4>' . nr_x_escape($title) . '</h4><ul>';
    foreach ($items as $text) {
        $html .= '<li>' . nr_x_escape($text) . '</li>';
    }
    return $html . '</ul></div>';
}

/** One expandable "Why this neighborhood?" section for a WSM result. */
// Render neighborhood explanation.
function nr_render_explanation(array $item, array $allResults = []): string
{
    $id = 'nrx-' . (int) ($item['neighborhood_id'] ?? 0);

    $explanation = null;
    if (function_exists('diyara_explain_neighborhood')) {
        try {
            $explanation = diyara_explain_neighborhood($item, $allResults);
        } catch (Throwable $e) {
            error_log('Diyara explanation error: ' . $e->getMessage());
            $explanation = null;
        }
    }

    if (is_string($explanation) && trim($explanation) !== '') {
        $body = $explanation; // Person 4's own HTML component
    } elseif (is_array($explanation) && isset($explanation['en'], $explanation['ar'])) {
        $body = diyara_bilingual_explanation($explanation);
    } else {
        $x = is_array($explanation) ? $explanation : [];
        $body = '';
        if (!empty($x['summary'])) {
            $body .= '<p class="nrx-summary">' . nr_x_escape($x['summary']) . '</p>';
        }
        if (!empty($x['highlights'])) {
            $body .= '<dl class="nrx-facts">';
            foreach ($x['highlights'] as $label => $value) {
                $body .= '<div><dt>' . nr_x_escape($label) . '</dt><dd>' . nr_x_escape($value) . '</dd></div>';
            }
            $body .= '</dl>';
        }
        $tradeoffTitle = 'Worth considering';
        $body .= nr_x_list($tradeoffTitle, (array) ($x['limitations'] ?? []), 'nrx-limits');
        if ($body === '') {
            $body .= '<p class="nrx-pending">Adjust your lifestyle priorities to make this match more personal.</p>';
        }
    }

    return '<details class="nrx" id="' . $id . '">'
         . '<summary><span>Why this neighborhood?</span><span class="nrx-chev" aria-hidden="true"></span></summary>'
         . '<div class="nrx-body">' . $body . '</div>'
         . '</details>';
}
