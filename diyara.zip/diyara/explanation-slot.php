<?php
/**
 * Diyara Sprint 2 - Person 3: place for Person 4's explanation on Neighborhood Recommendations.
 *
 * neighborhood-recommendations.php calls nr_render_explanation($item) once per neighborhood card,
 * where $item is one result of get_wsm_neighborhoods() (wsm.php):
 *   neighborhood_id, name_ar, name_en, region, suitability_score, suitability_level, rank,
 *   service_contributions => [ 'Schools' => [count, weight, normalized, points], ... ]
 *
 * HOW PERSON 4 PLUGS IN (no change to this file or to the page is needed):
 *   Create explanation.php next to this file with:
 *       function diyara_explain_neighborhood(array $item, array $allResults): array|string
 *   - Return a STRING  -> it is printed as-is inside the expandable section (your own HTML component).
 *   - Return an ARRAY  -> this file draws it. Keys (all optional):
 *       'summary'      => string        one-sentence reason it is recommended
 *       'level_reason' => string        why it is High / Medium / Low
 *       'reasons'      => string[]      main reasons (top contributing services)
 *       'strengths'    => string[]
 *       'limitations'  => string[]
 *       'breakdown'    => [ ['service' => 'Schools', 'points' => 18.4, 'note' => '...'], ... ]
 *                         (if missing, the breakdown is built from service_contributions)
 *   Until explanation.php exists, the section shows only the WSM breakdown and a "coming soon" note.
 */

if (is_file(__DIR__ . '/explanation.php')) {
    require_once __DIR__ . '/explanation.php';
}

function nr_x_escape($value): string
{
    return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/** Breakdown rows from the WSM output, biggest contribution first. */
function nr_x_breakdown_from_wsm(array $item): array
{
    $rows = [];
    foreach (($item['service_contributions'] ?? []) as $service => $c) {
        $rows[] = [
            'service' => (string) $service,
            'points'  => (float) ($c['points'] ?? 0),
            'weight'  => (float) ($c['weight'] ?? 0),
            'count'   => (float) ($c['count'] ?? 0),
        ];
    }
    usort($rows, static fn($a, $b) => $b['points'] <=> $a['points']);
    return $rows;
}

function nr_x_list(string $title, array $items, string $class): string
{
    $items = array_values(array_filter(array_map('strval', $items), static fn($s) => trim($s) !== ''));
    if (!$items) {
        return '';
    }
    $html = '<div class="nrx-block ' . $class . '"><h4>' . nr_x_escape($title) . '</h4><ul>';
    foreach ($items as $text) {
        $html .= '<li>' . nr_x_escape($text) . '</li>';
    }
    return $html . '</ul></div>';
}

function nr_x_breakdown_html(array $rows, float $score): string
{
    if (!$rows) {
        return '';
    }
    $html = '<div class="nrx-block nrx-breakdown"><h4>How your score of ' . number_format($score, 1) . ' is made</h4>';
    foreach ($rows as $r) {
        $points = (float) ($r['points'] ?? 0);
        $width = max(0, min(100, $points));
        $meta = [];
        if (isset($r['weight'])) {
            $meta[] = 'your weight ' . round((float) $r['weight'] * 100) . '%';
        }
        if (isset($r['count'])) {
            $meta[] = number_format((float) $r['count']) . ' available';
        }
        $note = isset($r['note']) && $r['note'] !== '' ? $r['note'] : implode(' · ', $meta);
        $html .= '<div class="nrx-row">'
               . '<span class="nrx-service">' . nr_x_escape($r['service'] ?? '') . '</span>'
               . '<span class="nrx-bar" aria-hidden="true"><span style="width:' . $width . '%"></span></span>'
               . '<strong class="nrx-points">+' . number_format($points, 1) . '</strong>'
               . ($note !== '' ? '<small class="nrx-note">' . nr_x_escape($note) . '</small>' : '')
               . '</div>';
    }
    return $html . '</div>';
}

/** One expandable "Why this neighborhood?" section for a WSM result. */
function nr_render_explanation(array $item, array $allResults = []): string
{
    $score = (float) ($item['suitability_score'] ?? 0);
    $level = (string) ($item['suitability_level'] ?? '');
    $id = 'nrx-' . (int) ($item['neighborhood_id'] ?? 0);

    $explanation = null;
    if (function_exists('diyara_explain_neighborhood')) {
        try {
            $explanation = diyara_explain_neighborhood($item, $allResults);
        } catch (Throwable $e) {
            error_log('Diyara explanation error: ' . $e->getMessage());
            $explanation = null;
        }
    }

    if (is_string($explanation) && trim($explanation) !== '') {
        $body = $explanation; // Person 4's own HTML component
    } else {
        $x = is_array($explanation) ? $explanation : [];
        $body = '';
        if (!empty($x['summary'])) {
            $body .= '<p class="nrx-summary">' . nr_x_escape($x['summary']) . '</p>';
        }
        if (!empty($x['level_reason'])) {
            $body .= '<p class="nrx-level nrx-level-' . nr_x_escape(strtolower($level)) . '"><strong>' . nr_x_escape($level) . ' match:</strong> ' . nr_x_escape($x['level_reason']) . '</p>';
        }
        $body .= nr_x_list('Why we recommend it', (array) ($x['reasons'] ?? []), 'nrx-reasons');
        $lists = nr_x_list('Strengths for you', (array) ($x['strengths'] ?? []), 'nrx-strengths')
               . nr_x_list('Limitations', (array) ($x['limitations'] ?? []), 'nrx-limits');
        if ($lists !== '') {
            $body .= '<div class="nrx-two">' . $lists . '</div>';
        }
        $rows = !empty($x['breakdown']) && is_array($x['breakdown']) ? $x['breakdown'] : nr_x_breakdown_from_wsm($item);
        $body .= nr_x_breakdown_html($rows, $score);
        if (!$x) {
            $body .= '<p class="nrx-pending">A written explanation of this result is coming soon.</p>';
        }
    }

    return '<details class="nrx" id="' . $id . '">'
         . '<summary><span>Why this neighborhood?</span><span class="nrx-chev" aria-hidden="true"></span></summary>'
         . '<div class="nrx-body">' . $body . '</div>'
         . '</details>';
}
