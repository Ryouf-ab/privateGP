<?php
/**
 * EXAMPLE ONLY (not loaded by the site). Shows Person 4 the shape that explanation-slot.php accepts.
 * To use: Person 4 writes the real logic and saves it as explanation.php (same folder).
 * The text below is a simple placeholder, not the real Explanation Generator.
 */
function diyara_explain_neighborhood(array $item, array $allResults): array
{
    $c = $item['service_contributions'] ?? [];
    uasort($c, static fn($a, $b) => $b['points'] <=> $a['points']);
    $top = array_slice(array_keys($c), 0, 2);
    $weak = array_keys(array_filter($c, static fn($x) => $x['weight'] >= 0.15 && $x['normalized'] < 0.25));

    return [
        'summary'      => 'Recommended mainly for its ' . strtolower(implode(' and ', $top)) . '.',
        'level_reason' => 'Its score of ' . number_format($item['suitability_score'], 1) . ' is in the '
                          . $item['suitability_level'] . ' band (High ≥ 70, Medium 40–69, Low < 40).',
        'reasons'      => array_map(static fn($s) => "$s adds " . number_format($c[$s]['points'], 1) . ' points', $top),
        'strengths'    => array_map(static fn($s) => "Good $s coverage", $top),
        'limitations'  => array_map(static fn($s) => "Few $s for how much you care about them", $weak),
        // 'breakdown' left out: explanation-slot.php builds it from service_contributions
    ];
}
