<?php

// Explain service priorities.
function diyara_explain_neighborhood(array $item, array $allResults = []): array
{
    $services = [
        'Schools' => ['schools', 'المدارس'],
        'Healthcare' => ['hospitals and clinics', 'المستشفيات والعيادات'],
        'Parks' => ['parks', 'الحدائق'],
        'Supermarkets' => ['supermarkets', 'محلات السوبرماركت'],
        'Banks' => ['banks', 'البنوك'],
        'Gas Stations' => ['fuel stations', 'محطات الوقود'],
    ];

    $priorities = array_intersect_key($item['service_contributions'] ?? [], $services);
    $priorities = array_filter($priorities, static fn(array $service): bool => $service['weight'] > 0);
    uasort($priorities, static fn(array $a, array $b): int =>
        ($b['weight'] <=> $a['weight']) ?: ($b['points'] <=> $a['points']));

    $units = [
        'Schools' => ['school', 'مدرسة', 'مدرستان', 'مدارس'],
        'Healthcare' => ['healthcare facility', 'منشأة صحية', 'منشأتان صحيتان', 'منشآت صحية'],
        'Parks' => ['park', 'حديقة', 'حديقتان', 'حدائق'],
        'Supermarkets' => ['supermarket', 'متجر تموين', 'متجرا تموين', 'متاجر تموين'],
        'Banks' => ['bank', 'بنك', 'بنكان', 'بنوك'],
        'Gas Stations' => ['fuel station', 'محطة وقود', 'محطتا وقود', 'محطات وقود'],
    ];
    $topicsEn = $topicsAr = $presentEn = $presentAr = $missingEn = $missingAr = [];
    foreach ($priorities as $key => $service) {
        [$plural, $label] = $services[$key];
        $count = (int) $service['count'];
        if ($count === 0) {
            $missingEn[] = $plural;
            $missingAr[] = $label;
        } elseif (count($presentAr) < 3) {
            $topicsAr[] = ['Schools' => 'التعليم', 'Healthcare' => 'الرعاية الصحية'][$key] ?? $label;
            $topicsEn[] = ['Schools' => 'education', 'Healthcare' => 'healthcare'][$key] ?? $plural;
            [$one, $singular, $dual, $few] = $units[$key];
            $presentEn[] = $count . ' ' . ($count === 1 ? $one : ($key === 'Healthcare' ? 'healthcare facilities' : $plural));
            $presentAr[] = $count === 1 ? $singular . (in_array($key, ['Banks','Supermarkets'], true) ? ' واحد' : ' واحدة') : ($count === 2 ? $dual :
                $count . ' ' . ($count % 100 >= 3 && $count % 100 <= 10 ? $few : $singular));
        }
    }
    $joinEnglish = static function (array $items): string {
        $last = array_pop($items);
        return $items ? implode(', ', $items) . ' and ' . $last : (string) $last;
    };
    $en = $ar = [];
    if ($presentAr) {
        $intro = [1 => 'خدمة تهمّك فيه، وهي ', 2 => 'خدمتين تهمّانك فيه، هما ', 3 => 'خدمات تهمّك فيه، منها '];
        $ar[] = 'رُشّح لك هذا الحي لتوافر ' . $intro[count($topicsAr)] . implode(' و', $topicsAr) . '. ويضمّ الحي ' . implode(' و', $presentAr) . '.';
        $en[] = 'This neighborhood is recommended because it offers services you value: ' . $joinEnglish($topicsEn) . '. It has ' . $joinEnglish($presentEn) . '.';
    }
    if ($missingAr) {
        $ar[] = ($presentAr ? 'ومن أولوياتك أيضًا ' : 'من أولوياتك ') . implode(' و', $missingAr) . '، لكنها غير متوافرة داخل الحي.';
        $en[] = ($presentEn ? 'You also value ' : 'You value ') . $joinEnglish($missingEn) . ', but the neighborhood has none.';
    }
    return [
        'en' => [implode(' ', $en) ?: 'Rate your service preferences to see how this neighborhood fits.'],
        'ar' => [implode(' ', $ar) ?: 'حدّد أهمية الخدمات لديك ليتضح مدى ملاءمة الحي لاحتياجاتك.'],
    ];
}
