
<?php
/**
 * DIYARA - Person 4: Explainable Recommendation Generator.
 *
 * This module explains the actual WSM results.
 * It does not calculate or modify the WSM score.
 */

/**
 * Generate a personalized explanation for one neighborhood.
 *
 * @param array $item       One neighborhood's WSM result.
 * @param array $allResults All neighborhoods returned by WSM.
 * @return array            Explanation content for the UI component.
 */
function diyara_explain_neighborhood(array $item, array $allResults): array
{
    // Read the actual WSM result fields.
    $score = (float) ($item['suitability_score'] ?? 0);
    $level = (string) ($item['suitability_level'] ?? 'Unknown');
    $contributions = $item['service_contributions'] ?? [];

    // Sort services by their actual contribution points.
    uasort($contributions, static function ($a, $b) {
        return (float) ($b['points'] ?? 0)
            <=> (float) ($a['points'] ?? 0);
    });

    $reasons = [];
    $strengths = [];
    $limitations = [];

    // Find the services that contribute most to the score.
    $topServices = array_slice($contributions, 0, 3, true);

    foreach ($topServices as $service => $data) {
        $points = (float) ($data['points'] ?? 0);
        $count = (float) ($data['count'] ?? 0);

        // Explain the contribution using actual WSM values.
        if ($points > 0) {
            $reasons[] = $service . ' contributes '
                . number_format($points, 1)
                . ' points to the neighborhood score.';

            $strengths[] = $service . ' has '
                . number_format($count)
                . ' available services.';
        }
    }

    // Identify highly prioritized services with low coverage.
    foreach ($contributions as $service => $data) {
        $weight = (float) ($data['weight'] ?? 0);
        $normalized = (float) ($data['normalized'] ?? 0);
        $count = (float) ($data['count'] ?? 0);

        // A high weight means the user considers this service important.
        if ($weight >= 0.15 && $normalized < 0.25) {
            if ($count <= 0) {
                $limitations[] = 'No recorded ' . $service
                    . ' services, although this service is important to you.';
            } else {
                $limitations[] = 'Limited ' . $service
                    . ' coverage compared with your preferences.';
            }
        }
    }

    // Explain the suitability category using the WSM thresholds.
    if ($level === 'High') {
        $levelReason = 'This neighborhood achieved a score of '
            . number_format($score, 1)
            . ', which meets the High suitability threshold (70 or above).';
    } elseif ($level === 'Medium') {
        $levelReason = 'This neighborhood achieved a score of '
            . number_format($score, 1)
            . ', which falls within the Medium suitability range (40 to below 70).';
    } elseif ($level === 'Low') {
        $levelReason = 'This neighborhood achieved a score of '
            . number_format($score, 1)
            . ', which is below the Low suitability threshold (40).';
    } else {
        $levelReason = 'The suitability category is not available.';
    }

    // Build a personalized summary from the strongest contributions.
    $topNames = array_slice(array_keys($topServices), 0, 2);

    if (!empty($topNames)) {
        $summary = 'This neighborhood is recommended mainly because of its '
            . implode(' and ', $topNames)
            . ' contributions to your preferences.';
    } else {
        $summary = 'There is not enough service contribution data to explain this recommendation.';
    }

    // Provide a clear message when no limitations were identified.
    if (empty($limitations)) {
        $limitations[] = 'No major service limitations were identified based on the current importance and coverage values.';
    }

    // Return the explanation in the format expected by explanation-slot.php.
    return [
        'summary' => $summary,
        'level_reason' => $levelReason,
        'reasons' => $reasons,
        'strengths' => $strengths,
        'limitations' => $limitations
        // The UI component builds the contribution breakdown
        // directly from the original WSM service_contributions.
    ];
}
