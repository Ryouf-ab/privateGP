<?php
/**
 * DIYARA — Multi-Criteria Property Recommendations
 *
 * Hard requirement:
 * - Property price must never exceed the user's budget.
 * - Property type must match the requested type.
 *
 * Ranking preferences:
 * - Selected neighborhoods first.
 * - Area closeness: 40 points.
 * - Bedroom closeness: 30 points.
 * - Price proximity without exceeding budget: 30 points.
 */
function get_candidate_neighborhoods(PDO $pdo, array $prefs): array
{
    $userId = $_SESSION['user_id'] ?? null;
    if (!$userId) {
        return [];
    }
    // Always load the latest saved preferences.
    $stmt = $pdo->prepare("
        SELECT
            budget,
            property_type,
            preferred_size,
            bedrooms,
            preferred_location
        FROM housing_preferences
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $housing = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$housing) {
        return [];
    }
    $budget = (float) ($housing['budget'] ?? 0);
    $propertyType = trim($housing['property_type'] ?? '');
    if ($budget <= 0 || $propertyType === '') {
        return [];
    }
    /*
     * Support English preference values and Arabic listing values.
     */
    $typeAliases = [
        'apartment' => ['Apartment', 'شقة'],
        'villa'     => ['Villa', 'فيلا'],
        'floor'     => ['Floor', 'دور'],
        'land'      => ['Land', 'أرض'],
        'استراحة'   => ['استراحة'],
        'عمارة'     => ['عمارة']
    ];
    $typeKey = strtolower($propertyType);
    $allowedTypes = $typeAliases[$typeKey] ?? [$propertyType];
    $typePlaceholders = implode(
        ', ',
        array_fill(0, count($allowedTypes), '?')
    );
    $normalizedTypes = array_map(
        static function ($type) {
            return strtolower(trim($type));
        },
        $allowedTypes
    );
    /*
     * Read multiple selected neighborhoods.
     * Supports comma, Arabic comma, semicolon, and new lines.
     */
    $locationText = trim(
        $housing['preferred_location'] ?? ''
    );
    $preferredLocations = [];
    if ($locationText !== '') {
        $parts = preg_split(
            '/[,،;؛\r\n]+/u',
            $locationText
        );
        foreach ($parts as $part) {
            $part = trim($part);
            if ($part !== '') {
                $preferredLocations[] = $part;
            }
        }
    }
    $preferredArea = (
        isset($housing['preferred_size']) &&
        is_numeric($housing['preferred_size']) &&
        (float) $housing['preferred_size'] > 0
    )
        ? (float) $housing['preferred_size']
        : null;
    $preferredBedrooms = (
        isset($housing['bedrooms']) &&
        is_numeric($housing['bedrooms']) &&
        (int) $housing['bedrooms'] > 0
    )
        ? (int) $housing['bedrooms']
        : null;
    /*
     * The SQL enforces budget and property type.
     * Area and bedrooms are ranking criteria, not exclusion criteria.
     */
    $sql = "
        SELECT
            n.neighborhood_id,
            n.name_ar,
            n.name_en,
            n.region,
            n.schools_count,
            n.hospitals_count,
            n.parks_count,
            n.gyms_count,
            n.pharmacies_count,
            n.supermarkets_count,
            n.shopping_centers_count,
            n.metro_stations_count,
            n.median_price_m2,
            n.median_property_price,
            n.median_apartment_price,
            n.median_villa_price,
            n.listings_count,
            p.property_id,
            p.property_type AS listing_type,
            p.bedrooms AS listing_bedrooms,
            p.bathrooms AS listing_bathrooms,
            p.area_m2 AS listing_area,
            p.price AS listing_price
        FROM properties p
        INNER JOIN neighborhoods n
            ON n.neighborhood_id = p.neighborhood_id
        WHERE p.price IS NOT NULL
          AND p.price > 0
          AND p.price <= ?
          AND LOWER(TRIM(p.property_type))
              IN ($typePlaceholders)
    ";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(
        array_merge([$budget], $normalizedTypes)
    );
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);
    if (!$rows) {
        return [];
    }
    /*
     * Compare neighborhood names without case differences
     * for English names.
     */
    $normalizeLocation = static function ($value) {
        return strtolower(trim((string) $value));
    };
    $isPreferredNeighborhood = static function ($row) use (
        $preferredLocations,
        $normalizeLocation
    ) {
        foreach ($preferredLocations as $location) {
            if (
                $normalizeLocation($row['name_ar'] ?? '') ===
                    $normalizeLocation($location) ||
                $normalizeLocation($row['name_en'] ?? '') ===
                    $normalizeLocation($location)
            ) {
                return true;
            }
        }
        return false;
    };
    $grouped = [];
    foreach ($rows as $row) {
        $price = (float) $row['listing_price'];
        $area = (
            $row['listing_area'] !== null &&
            is_numeric($row['listing_area']) &&
            (float) $row['listing_area'] > 0
        )
            ? (float) $row['listing_area']
            : null;
        $bedrooms = (
            $row['listing_bedrooms'] !== null &&
            is_numeric($row['listing_bedrooms'])
        )
            ? (int) $row['listing_bedrooms']
            : null;
        /*
         * Area score: 40 points.
         * Exact area receives 40 points.
         * Closer areas receive higher scores.
         */
        $areaScore = 0;
        if ($preferredArea !== null && $area !== null) {
            $areaScore = max(
                0,
                40 * (
                    1 - abs($area - $preferredArea) /
                    $preferredArea
                )
            );
        }
        /*
         * Bedrooms score: 30 points.
         */
        $bedroomScore = 0;
        if (
            $preferredBedrooms !== null &&
            $bedrooms !== null
        ) {
            $bedroomScore = max(
                0,
                30 * (
                    1 - abs($bedrooms - $preferredBedrooms) /
                    max($preferredBedrooms, 1)
                )
            );
        }
        /*
         * Price score: 30 points.
         * The property can never exceed the budget because
         * the SQL query already enforces that condition.
         * Higher affordable prices receive a higher proximity score.
         */
        $priceScore = min(
            30,
            max(0, 30 * ($price / $budget))
        );
        /*
         * If an area or bedroom preference is unavailable,
         * distribute its weight proportionally across available
         * criteria so that missing data does not automatically
         * penalize a property.
         */
        $availableWeights = 30; // Price is always available.
        if ($preferredArea !== null && $area !== null) {
            $availableWeights += 40;
        } else {
            $areaScore = null;
        }
        if (
            $preferredBedrooms !== null &&
            $bedrooms !== null
        ) {
            $availableWeights += 30;
        } else {
            $bedroomScore = null;
        }
        $weightedTotal = 0;
        if ($priceScore !== null) {
            $weightedTotal += $priceScore;
        }
        if ($areaScore !== null) {
            $weightedTotal += $areaScore;
        }
        if ($bedroomScore !== null) {
            $weightedTotal += $bedroomScore;
        }
        $matchScore = round(
            ($weightedTotal / $availableWeights) * 100,
            1
        );
        $neighborhoodId = $row['neighborhood_id'];
        if (!isset($grouped[$neighborhoodId])) {
            $grouped[$neighborhoodId] = [
                'neighborhood_id' => $neighborhoodId,
                'name_ar' => $row['name_ar'],
                'name_en' => $row['name_en'],
                'region' => $row['region'],
                'schools_count' => $row['schools_count'],
                'hospitals_count' => $row['hospitals_count'],
                'parks_count' => $row['parks_count'],
                'gyms_count' => $row['gyms_count'],
                'pharmacies_count' => $row['pharmacies_count'],
                'supermarkets_count' => $row['supermarkets_count'],
                'shopping_centers_count' => $row['shopping_centers_count'],
                'metro_stations_count' => $row['metro_stations_count'],
                'median_price_m2' => $row['median_price_m2'],
                'median_property_price' => $row['median_property_price'],
                'median_apartment_price' => $row['median_apartment_price'],
                'median_villa_price' => $row['median_villa_price'],
                'listings_count' => $row['listings_count'],
                'is_preferred' => $isPreferredNeighborhood($row),
                'properties' => []
            ];
        }
        $grouped[$neighborhoodId]['properties'][] = [
            'property_id' => $row['property_id'],
            'property_type' => $row['listing_type'],
            'bedrooms' => $row['listing_bedrooms'],
            'bathrooms' => $row['listing_bathrooms'],
            'area_m2' => $row['listing_area'],
            'price' => $row['listing_price'],
            'area_score' => $areaScore,
            'bedroom_score' => $bedroomScore,
            'price_score' => $priceScore,
            'match_score' => $matchScore
        ];
    }
    // Sort properties inside each neighborhood.
    foreach ($grouped as &$neighborhood) {
        usort(
            $neighborhood['properties'],
            static function ($a, $b) {
                if ($a['match_score'] != $b['match_score']) {
                    return $b['match_score'] <=> $a['match_score'];
                }
                return (float) $a['price']
                    <=> (float) $b['price'];
            }
        );
        $neighborhood['best_match_score'] =
            $neighborhood['properties'][0]['match_score'];
    }
    unset($neighborhood);
    $results = array_values($grouped);
    // Selected neighborhoods always appear before alternatives.
    usort(
        $results,
        static function ($a, $b) {
            if ($a['is_preferred'] !== $b['is_preferred']) {
                return $a['is_preferred'] ? -1 : 1;
            }
            if (
                $a['best_match_score'] !=
                $b['best_match_score']
            ) {
                return $b['best_match_score']
                    <=> $a['best_match_score'];
            }
            return (float) $a['properties'][0]['price']
                <=> (float) $b['properties'][0]['price'];
        }
    );
    return $results;
}