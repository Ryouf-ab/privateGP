<?php
// PERSON 3 owns this file: replace the body with the real rule-based filtering.
// Keep the function name and return shape so recommendations.php keeps working:
//   input:  $prefs = one row from the preferences table (array)
//   output: array of rows from the neighborhoods table
//
// TEMPORARY version (Person 4) so the results page can be tested. It reads these
// preference keys if they exist: budget, region, needs_schools, needs_hospital, near_metro.
function get_candidate_neighborhoods(PDO $pdo, array $prefs): array {
    $sql = 'SELECT * FROM neighborhoods WHERE 1=1';
    $params = [];

    if (!empty($prefs['budget'])) {
        $sql .= ' AND median_property_price <= ?';
        $params[] = $prefs['budget'];
    }
    if (!empty($prefs['region'])) {
        $sql .= ' AND region = ?';
        $params[] = $prefs['region'];
    }
    if (!empty($prefs['needs_schools'])) {
        $sql .= ' AND schools_count > 0';
    }
    if (!empty($prefs['needs_hospital'])) {
        $sql .= ' AND hospitals_count > 0';
    }
    if (!empty($prefs['near_metro'])) {
        $sql .= ' AND metro_stations_count > 0';
    }

    $sql .= ' ORDER BY median_property_price IS NULL, median_property_price';
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}
