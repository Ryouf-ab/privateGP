<?php
require_once __DIR__ . '/includes/property-preferences.php';

require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];

$message = '';
$error = '';

/* PROPERTY TYPES */

$property_types = array_keys(DIYARA_HOME_TYPES);

/* GET CURRENT HOUSING PREFERENCES */
$stmt = $pdo->prepare("
    SELECT
        budget,
        property_type,
        preferred_size,
        bedrooms
    FROM housing_preferences
    WHERE user_id = ?
");
$stmt->execute([$user_id]);

$preferences = $stmt->fetch(PDO::FETCH_ASSOC);
$has_preferences = (bool) $preferences;

/* DEFAULT VALUES */
$form_budget = $preferences['budget'] ?? '';
$selectedTypes = diyara_preferred_types($preferences['property_type'] ?? '');
$form_preferred_size = $preferences['preferred_size'] ?? '';
$form_bedrooms = $preferences['bedrooms'] ?? '';

/* SAVE / UPDATE */
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? 'save';

    $form_budget = trim($_POST['budget'] ?? '');
    $submitted = (array) ($_POST['property_type'] ?? []);
    $selectedTypes = array_values(array_filter($property_types, static function ($type) use ($submitted) {
        return in_array($type, $submitted, true);
    }));
    $form_preferred_size = trim($_POST['preferred_size'] ?? '');
    $form_bedrooms = (int) ($_POST['bedrooms'] ?? 0);

    /* VALIDATION */
    if (
        $form_budget === '' ||
        !is_numeric($form_budget) ||
        (float) $form_budget <= 0
    ) {
        $error = 'Please enter a valid budget greater than 0.';

    } elseif (
        !$selectedTypes || count(array_filter($submitted, static function ($type) use ($property_types) { return !in_array($type, $property_types, true); })) > 0
    ) {
        $error = 'Select at least one property type.';

    } elseif (
        $form_preferred_size === '' ||
        !is_numeric($form_preferred_size) ||
        (float) $form_preferred_size <= 0
    ) {
        $error = 'Please enter a valid preferred size greater than 0.';

    } elseif ($form_bedrooms < 1 || $form_bedrooms > 20) {
        $error = 'Number of bedrooms must be between 1 and 20.';

    } else {
        // Save housing preferences.
        $stmt = $pdo->prepare("
            INSERT INTO housing_preferences
                (user_id, budget, property_type, preferred_size, bedrooms, preferred_location)
            VALUES (?, ?, ?, ?, ?, '')
            ON DUPLICATE KEY UPDATE
                budget = VALUES(budget),
                property_type = VALUES(property_type),
                preferred_size = VALUES(preferred_size),
                bedrooms = VALUES(bedrooms)
        ");
        $stmt->execute([$user_id, $form_budget, implode(',', $selectedTypes), $form_preferred_size, $form_bedrooms]);
        $has_preferences = true;

        if ($action === 'complete') {
            header('Location: profile.php');
            exit;
        }
        $message = 'Your housing preferences have been updated successfully.';
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Housing Preferences | Diyara</title>

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
        rel="stylesheet"
    >

    <link rel="stylesheet" href="diyara.css?v=72">
    <link rel="stylesheet" href="assets/css/theme.css?v=1">
    <script src="assets/js/theme.js?v=2"></script>
    <link rel="stylesheet" href="assets/css/atelier.css?v=8">
    <link rel="stylesheet" href="assets/css/arabic-refinements.css?v=1">
<link rel="stylesheet" href="assets/css/editorial-surfaces.css?v=10">
</head>

<body class="page-housing">

<header class="site-topbar">
    <div class="topbar-brand">
        <div class="topbar-logo-slot"></div>
        <div class="topbar-brand-text">
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>
    </div>

    <nav class="topbar-nav">
        <a href="index.php" class="topbar-link">Home</a>
        <?php if (($_SESSION['role'] ?? '') === 'agent'): ?><a href="agent-dashboard.php" class="topbar-link">My Listings</a><?php else: ?><a href="recommendations.php" class="topbar-link">Recommendations</a><?php endif; ?>
        <a href="profile.php" class="topbar-link">My Profile</a>
        <a href="logout.php" class="topbar-link">Logout</a>
    </nav>
</header>

<main class="page-body housing-page">

    <div class="housing-top">

        <section class="housing-heading">
            <div class="section-label">
                <span></span>
                YOUR HOME
            </div>

            <h1>Housing Preferences</h1>

            <p>
                Set your maximum budget and tell us what you prefer in a home.
            </p>

            <div class="housing-progress">
                <div class="progress-track">
                    <div class="progress-step completed">
                        <div class="step-circle">✓</div>
                        <span>Lifestyle</span>
                    </div>

                    <div class="step-line completed-line"></div>

                    <div class="progress-step current">
                        <div class="step-circle">2</div>
                        <span>Housing</span>
                    </div>

                    <div class="step-line"></div>

                    <div class="progress-step">
                        <div class="step-circle">3</div>
                        <span>Complete</span>
                    </div>
                </div>
            </div>
        </section>

        <section class="housing-hero">
            <img src="images/housing-art.png" alt="Riyadh Villa">

            <div class="housing-copy">
                <h3 dir="rtl">دارك… على قدّ تفاصيلك</h3>
                <p dir="rtl">
                    احتياجك يحدد الدار،
                    وديّارا يقرّب لك الأنسب بالرياض.
                </p>
            </div>
        </section>

    </div>

    <section class="housing-form">

        <?php if ($message): ?>
            <div class="notification success-message">
                <div class="notification-icon">✓</div>
                <div>
                    <strong>Saved successfully</strong>
                    <p><?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?></p>
                </div>
            </div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="notification error-message">
                <div class="notification-icon">!</div>
                <div>
                    <strong>Check your information</strong>
                    <p><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></p>
                </div>
            </div>
        <?php endif; ?>

        <form method="POST" class="form-card">

            <div class="form-card-header">
                <div>
                    <span class="form-number">02</span>
                    <h2>Define your housing needs</h2>
                </div>

                <p>All fields marked with <span>*</span> are required.</p>
            </div>

            <div class="form-grid two-column">

                <div class="input-group">
                    <label for="budget">Budget <span>*</span></label>

                    <div class="input-with-suffix">
                        <input
                            type="number"
                            id="budget"
                            name="budget"
                            min="1"
                            step="0.01"
                            placeholder="e.g. 1200000"
                            value="<?= htmlspecialchars((string)$form_budget, ENT_QUOTES, 'UTF-8') ?>"
                            required
                        >
                        <div class="suffix">SAR</div>
                    </div>

                    <small>Maximum budget you are comfortable with.</small>
                </div>

                <div class="input-group">
                    <div class="type-heading"><span id="property-type-label">Property Type <span>*</span></span><button type="button" id="select-types">Select all</button></div>

                    <div class="property-options" role="group" aria-labelledby="property-type-label">
                        <?php foreach ($property_types as $type): ?>
                            <label class="property-choice">
                                <input
                                    type="checkbox"
                                    name="property_type[]"
                                    value="<?= htmlspecialchars($type, ENT_QUOTES, 'UTF-8') ?>"
                                    <?= in_array($type, $selectedTypes, true) ? 'checked' : '' ?>
                                >

                                <span>
                                    <span class="choice-dot"></span>
                                    <?= htmlspecialchars($type, ENT_QUOTES, 'UTF-8') ?>
                                </span>
                            </label>
                        <?php endforeach; ?>
                    </div>
                </div>

            </div>

            <div class="form-grid two-column">

                <div class="input-group">
                    <label for="preferred_size">Preferred Size <span>*</span></label>

                    <div class="input-with-suffix">
                        <input
                            type="number"
                            id="preferred_size"
                            name="preferred_size"
                            min="1"
                            step="0.01"
                            placeholder="e.g. 250"
                            value="<?= htmlspecialchars((string)$form_preferred_size, ENT_QUOTES, 'UTF-8') ?>"
                            required
                        >
                        <div class="suffix">m²</div>
                    </div>
                </div>

                <div class="input-group">
                    <label for="bedrooms">Preferred Number of Bedrooms <span>*</span></label>

                    <input
                        type="number"
                        id="bedrooms"
                        name="bedrooms"
                        min="1"
                        max="20"
                        placeholder="e.g. 4"
                        value="<?= htmlspecialchars((string)$form_bedrooms, ENT_QUOTES, 'UTF-8') ?>"
                        required
                    >
                </div>

            </div>

            <div class="form-actions">
                <a href="lifestyle-preferences.php" class="button back-button">
                    ← Back
                </a>

                <div class="primary-actions">

                    <?php if ($has_preferences): ?>
                        <button
                            type="submit"
                            name="action"
                            value="save"
                            class="button save-button"
                        >
                            Save Changes
                        </button>
                    <?php endif; ?>

                    <button
                        type="submit"
                        name="action"
                        value="complete"
                        class="button continue-button"
                    >
                        Save Preferences →
                    </button>

                </div>
            </div>

        </form>
    </section>

</main>

<footer class="diyara-footer">

    <div class="footer-brand">
        <div class="footer-mark"></div>
        <div>
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>
    </div>

    <div class="footer-center">
        <strong dir="rtl">ديارا | لكل طبعٍ حيّ</strong>
        <span>Riyadh · Heritage · Future</span>
    </div>

    <div class="footer-end">
        <span class="footer-line"></span>
        <p>Riyadh, Saudi Arabia<br>© 2026 Diyara</p>
    </div>

</footer>

<script>
const typeInputs = [...document.querySelectorAll('.property-options input[type="checkbox"]')];
const selectTypes = document.getElementById('select-types');
function refreshTypes() {
    selectTypes.disabled = typeInputs.every(input => input.checked);
    typeInputs[0].setCustomValidity(typeInputs.some(input => input.checked) ? '' : 'Select at least one property type.');
}
selectTypes.addEventListener('click', () => {
    typeInputs.forEach(input => { input.checked = true; });
    refreshTypes();
});
typeInputs.forEach(input => input.addEventListener('change', refreshTypes));
refreshTypes();
</script>
</body>
</html>
