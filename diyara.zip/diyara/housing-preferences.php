<?php

require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];

$message = '';
$error = '';


/* =========================================================
PROPERTY TYPES
========================================================= */

$property_types = [
    'Apartment',
    'Villa'
];


/* =========================================================
REGION DISPLAY NAMES
========================================================= */

$region_labels = [
    'شمال' => 'North Riyadh',
    'جنوب' => 'South Riyadh',
    'شرق' => 'East Riyadh',
    'غرب' => 'West Riyadh',
    'وسط' => 'Central Riyadh',
    'الدرعية' => 'Diriyah'
];


/* =========================================================
GET NEIGHBORHOODS FROM PERSON 4 DATASET
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        neighborhood_id,
        name_ar,
        name_en,
        region
    FROM neighborhoods
    ORDER BY
        CASE region
            WHEN 'شمال' THEN 1
            WHEN 'شرق' THEN 2
            WHEN 'وسط' THEN 3
            WHEN 'غرب' THEN 4
            WHEN 'جنوب' THEN 5
            WHEN 'الدرعية' THEN 6
            ELSE 7
        END,
        name_ar ASC
");

$stmt->execute();

$neighborhoods =
    $stmt->fetchAll(PDO::FETCH_ASSOC);


/* =========================================================
GROUP NEIGHBORHOODS BY REGION
========================================================= */

$neighborhoods_by_region = [];

foreach ($neighborhoods as $neighborhood) {

    $region = $neighborhood['region'] ?? '';

    if ($region === '') {
        $region = 'Other';
    }

    if (!isset($neighborhoods_by_region[$region])) {
        $neighborhoods_by_region[$region] = [];
    }

    $neighborhoods_by_region[$region][] = $neighborhood;
}


/* =========================================================
GET CURRENT HOUSING PREFERENCES
========================================================= */

$stmt = $pdo->prepare("
    SELECT *
    FROM housing_preferences
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$preferences =
    $stmt->fetch(PDO::FETCH_ASSOC);

$has_preferences =
    (bool)$preferences;


/* =========================================================
DEFAULT VALUES
========================================================= */

$form_budget =
    $preferences['budget'] ?? '';

$form_property_type =
    $preferences['property_type'] ?? '';

$form_preferred_size =
    $preferences['preferred_size'] ?? '';

$form_bedrooms =
    $preferences['bedrooms'] ?? '';

$form_preferred_neighborhood_id =
    $preferences['preferred_neighborhood_id'] ?? '';

$form_preferred_location =
    $preferences['preferred_location'] ?? '';


/* =========================================================
BACKWARD COMPATIBILITY
========================================================= */

if (
    empty($form_preferred_neighborhood_id) &&
    $form_preferred_location !== ''
) {

    $stmt = $pdo->prepare("
        SELECT neighborhood_id
        FROM neighborhoods
        WHERE name_ar = ?
        LIMIT 1
    ");

    $stmt->execute([
        $form_preferred_location
    ]);

    $old_neighborhood =
        $stmt->fetch(PDO::FETCH_ASSOC);

    if ($old_neighborhood) {
        $form_preferred_neighborhood_id =
            $old_neighborhood['neighborhood_id'];
    }
}


/* =========================================================
SAVE / UPDATE
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action =
        $_POST['action'] ?? 'save';

    $form_budget =
        trim($_POST['budget'] ?? '');

    $form_property_type =
        trim($_POST['property_type'] ?? '');

    $form_preferred_size =
        trim($_POST['preferred_size'] ?? '');

    $form_bedrooms =
        (int)($_POST['bedrooms'] ?? 0);

    $form_preferred_neighborhood_id =
        (int)($_POST['preferred_neighborhood_id'] ?? 0);


    /* =====================================================
    VALIDATION
    ===================================================== */

    if (
        $form_budget === '' ||
        !is_numeric($form_budget) ||
        (float)$form_budget <= 0
    ) {

        $error =
            'Please enter a valid budget greater than 0.';

    } elseif (
        $form_property_type === '' ||
        !in_array(
            $form_property_type,
            $property_types,
            true
        )
    ) {

        $error =
            'Please select a valid property type.';

    } elseif (
        $form_preferred_size === '' ||
        !is_numeric($form_preferred_size) ||
        (float)$form_preferred_size <= 0
    ) {

        $error =
            'Please enter a valid preferred size greater than 0.';

    } elseif (
        $form_bedrooms < 1 ||
        $form_bedrooms > 20
    ) {

        $error =
            'Number of bedrooms must be between 1 and 20.';

    } elseif (
        $form_preferred_neighborhood_id <= 0
    ) {

        $error =
            'Please select your preferred neighborhood.';

    } else {


        /* =================================================
        CHECK SELECTED NEIGHBORHOOD EXISTS
        ================================================= */

        $stmt = $pdo->prepare("
            SELECT
                neighborhood_id,
                name_ar,
                name_en,
                region
            FROM neighborhoods
            WHERE neighborhood_id = ?
            LIMIT 1
        ");

        $stmt->execute([
            $form_preferred_neighborhood_id
        ]);

        $selected_neighborhood =
            $stmt->fetch(PDO::FETCH_ASSOC);


        if (!$selected_neighborhood) {

            $error =
                'Please select a valid neighborhood.';

        } else {

            $form_preferred_location =
                $selected_neighborhood['name_ar'];


            /* =============================================
            INSERT / UPDATE
            ============================================= */

            $sql = "
                INSERT INTO housing_preferences
                (
                    user_id,
                    budget,
                    property_type,
                    preferred_size,
                    bedrooms,
                    preferred_neighborhood_id,
                    preferred_location
                )

                VALUES (?, ?, ?, ?, ?, ?, ?)

                ON DUPLICATE KEY UPDATE

                    budget =
                        VALUES(budget),

                    property_type =
                        VALUES(property_type),

                    preferred_size =
                        VALUES(preferred_size),

                    bedrooms =
                        VALUES(bedrooms),

                    preferred_neighborhood_id =
                        VALUES(preferred_neighborhood_id),

                    preferred_location =
                        VALUES(preferred_location)
            ";


            $stmt =
                $pdo->prepare($sql);


            $stmt->execute([
                $user_id,
                $form_budget,
                $form_property_type,
                $form_preferred_size,
                $form_bedrooms,
                $form_preferred_neighborhood_id,
                $form_preferred_location
            ]);


            $has_preferences = true;


            if ($action === 'save') {

                $message =
                    'Your housing preferences have been updated successfully.';
            }


            if ($action === 'complete') {

                header(
                    'Location: profile.php'
                );

                exit;
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Housing Preferences | Diyara
</title>

<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
rel="stylesheet"
>

<link
rel="stylesheet"
href="diyara.css?v=71"
>

</head>


<body class="page-housing">


<header class="site-topbar">


<div class="topbar-brand">

<div class="topbar-logo-slot"></div>

<div class="topbar-brand-text">

<strong>Diyara</strong>

<span>Live where you belong.</span>

</div>

</div>


<nav class="topbar-nav">

<a
href="index.php"
class="topbar-link"
>
Home
</a>

<a
href="recommendations.php"
class="topbar-link"
>
Recommendations
</a>

<a
href="profile.php"
class="topbar-link"
>
My Profile
</a>

<a
href="logout.php"
class="topbar-link"
>
Logout
</a>

</nav>

</header>



<main class="page-body housing-page">


<div class="housing-top">


<section class="housing-heading">


<div class="section-label">

<span></span>

YOUR HOME

</div>


<h1>
Housing Preferences
</h1>


<p>
Define what your future home should feel like.
Diyara uses your needs to identify suitable
residential options across Riyadh.
</p>


<div class="housing-progress">

<div class="progress-track">


<div class="progress-step completed">

<div class="step-circle">✓</div>

<span>Lifestyle</span>

</div>


<div class="step-line completed-line"></div>


<div class="progress-step current">

<div class="step-circle">2</div>

<span>Housing</span>

</div>


<div class="step-line"></div>


<div class="progress-step">

<div class="step-circle">3</div>

<span>Complete</span>

</div>


</div>

</div>


</section>



<section class="housing-hero">


<img
src="images/housing-art.png"
alt="Riyadh Villa"
>


<div class="housing-copy">


<h3 dir="rtl">
دارك… على قدّ تفاصيلك
</h3>


<p dir="rtl">
احتياجك يحدد الدار،
وديّارا يقرّب لك الأنسب بالرياض.
</p>


</div>


</section>


</div>



<section class="housing-form">


<?php if ($message): ?>

<div class="notification success-message">

<div class="notification-icon">
✓
</div>

<div>

<strong>
Saved successfully
</strong>

<p>
<?php
echo htmlspecialchars(
    $message,
    ENT_QUOTES,
    'UTF-8'
);
?>
</p>

</div>

</div>

<?php endif; ?>



<?php if ($error): ?>

<div class="notification error-message">

<div class="notification-icon">
!
</div>

<div>

<strong>
Check your information
</strong>

<p>
<?php
echo htmlspecialchars(
    $error,
    ENT_QUOTES,
    'UTF-8'
);
?>
</p>

</div>

</div>

<?php endif; ?>



<form
method="POST"
class="form-card"
>


<div class="form-card-header">


<div>

<span class="form-number">
02
</span>

<h2>
Define your housing needs
</h2>

</div>


<p>
All fields marked with
<span>*</span>
are required.
</p>


</div>



<div class="form-grid two-column">


<div class="input-group">

<label for="budget">

Budget

<span>*</span>

</label>


<div class="input-with-suffix">


<input
type="number"
id="budget"
name="budget"
min="1"
step="0.01"
placeholder="e.g. 1200000"
value="<?php
echo htmlspecialchars(
    (string)$form_budget,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


<div class="suffix">
SAR
</div>


</div>


<small>
Maximum budget you are comfortable with.
</small>


</div>



<div class="input-group">


<label>

Property Type

<span>*</span>

</label>


<div class="property-options">


<?php foreach ($property_types as $type): ?>


<label class="property-choice">


<input
type="radio"
name="property_type"
value="<?php
echo htmlspecialchars(
    $type,
    ENT_QUOTES,
    'UTF-8'
);
?>"

<?php
echo (
    $form_property_type === $type
)
? 'checked'
: '';
?>

required
>


<span>

<span class="choice-dot"></span>

<?php
echo htmlspecialchars(
    $type,
    ENT_QUOTES,
    'UTF-8'
);
?>

</span>


</label>


<?php endforeach; ?>


</div>


</div>


</div>



<div class="form-grid two-column">


<div class="input-group">


<label for="preferred_size">

Preferred Size

<span>*</span>

</label>


<div class="input-with-suffix">


<input
type="number"
id="preferred_size"
name="preferred_size"
min="1"
step="0.01"
placeholder="e.g. 250"
value="<?php
echo htmlspecialchars(
    (string)$form_preferred_size,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


<div class="suffix">
m²
</div>


</div>


</div>



<div class="input-group">


<label for="bedrooms">

Number of Bedrooms

<span>*</span>

</label>


<input
type="number"
id="bedrooms"
name="bedrooms"
min="1"
max="20"
placeholder="e.g. 4"
value="<?php
echo htmlspecialchars(
    (string)$form_bedrooms,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


</div>


</div>



<div class="input-group">


<label for="preferred_neighborhood_id">

Preferred Neighborhood

<span>*</span>

</label>


<select
id="preferred_neighborhood_id"
name="preferred_neighborhood_id"
required
>


<option value="">
Select your preferred neighborhood
</option>


<?php
foreach (
    $neighborhoods_by_region
    as $region => $region_neighborhoods
):
?>


<?php

$region_title =
    $region_labels[$region]
    ?? 'Other Areas';

?>


<optgroup
label="<?php
echo htmlspecialchars(
    $region_title,
    ENT_QUOTES,
    'UTF-8'
);
?>"
>


<?php
foreach (
    $region_neighborhoods
    as $neighborhood
):
?>


<option
value="<?php
echo (int)$neighborhood['neighborhood_id'];
?>"

<?php
echo (
    (string)$form_preferred_neighborhood_id
    ===
    (string)$neighborhood['neighborhood_id']
)
? 'selected'
: '';
?>
>


<?php
echo htmlspecialchars(
    $neighborhood['name_ar'],
    ENT_QUOTES,
    'UTF-8'
);
?>


<?php if (!empty($neighborhood['name_en'])): ?>

—
<?php
echo htmlspecialchars(
    $neighborhood['name_en'],
    ENT_QUOTES,
    'UTF-8'
);
?>

<?php endif; ?>


</option>


<?php endforeach; ?>


</optgroup>


<?php endforeach; ?>


</select>


<small>
Choose a neighborhood from Diyara's Riyadh dataset.
</small>


</div>



<div class="form-actions">


<a
href="lifestyle-preferences.php"
class="button back-button"
>
← Back
</a>


<div class="primary-actions">


<?php if ($has_preferences): ?>

<button
type="submit"
name="action"
value="save"
class="button save-button"
>
Save Changes
</button>

<?php endif; ?>


<button
type="submit"
name="action"
value="complete"
class="button continue-button"
>
Save Preferences →
</button>


</div>


</div>


</form>


</section>


</main>



<footer class="diyara-footer">


<div class="footer-brand">

<div class="footer-mark"></div>

<div>

<strong>Diyara</strong>

<span>Live where you belong.</span>

</div>

</div>


<div class="footer-center">

<strong dir="rtl">
ديارٍ تشبهك، وحيٍّ يناسبك.
</strong>

<span>
Riyadh · Heritage · Future
</span>

</div>


<div class="footer-end">

<span class="footer-line"></span>

<p>
Riyadh, Saudi Arabia
<br>
© 2026 Diyara
</p>

</div>


</footer>


</body>

</html>