<?php

// Render localized explanation.
function diyara_bilingual_explanation(array $copy): string
{
    $html = '<div class="diyara-explain-languages">';
    foreach (['en' => 'ltr', 'ar' => 'rtl'] as $language => $direction) {
        if (empty($copy[$language])) {
            continue;
        }
        $html .= '<div lang="' . $language . '" dir="' . $direction . '">';
        foreach ($copy[$language] as $paragraph) {
            $html .= '<p>' . htmlspecialchars($paragraph, ENT_QUOTES, 'UTF-8') . '</p>';
        }
        $html .= '</div>';
    }
    return $html . '</div>';
}
