<?php
require_once __DIR__ . "/neighborhood-name.php";
// Escape filter labels.
function dy_filter_text($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Localize listing types.
function dy_property_type($type): string
{
    $type = trim((string) $type);
    return ['apartment' => 'Apartment', 'villa' => 'Villa', 'floor' => 'Floor',
        'شقة' => 'Apartment', 'فيلا' => 'Villa', 'دور' => 'Floor'][strtolower($type)] ?? $type;
}

// Render catalog filters.
function dy_listing_filters(array $listings, bool $isCatalog): void
{
    $regions = $neighborhoods = [];
    foreach ($listings as $listing) {
        $region = trim((string) ($listing['region'] ?? ''));
        if ($region !== '') {
            $regions[$region] = $region;
        }
        $id = (int) ($listing['neighborhood_id'] ?? 0);
        if ($id > 0) {
            $neighborhoods[$id] = diyara_neighborhood_name($listing);
        }
    }
    asort($neighborhoods, SORT_STRING);
    ?>
    <div class="dy-filter-fields">
        <?php if ($isCatalog): ?>
        <label>Property Type
            <select data-filter="type">
                <option value="">All types</option>
                <?php foreach (['Villa', 'Apartment', 'Floor'] as $type): ?>
                    <option value="<?= dy_filter_text($type) ?>"><?= dy_filter_text($type) ?></option>
                <?php endforeach; ?>
            </select>
        </label>
        <?php endif; ?>
        <label>Region
            <select data-filter="region">
                <option value="">All regions</option>
                <?php foreach ($regions as $region): ?>
                    <option value="<?= dy_filter_text($region) ?>"><?= dy_filter_text(diyara_region_name($region)) ?></option>
                <?php endforeach; ?>
				<?php if (empty($_GET['neighborhood_id']) && !isset($regions['الدرعية'])): ?>

    <option value="الدرعية">Diriyah · الدرعية</option>

<?php endif; ?>
            </select>
        </label>
        <div class="dy-area-field"><span>Neighborhoods</span>
        <details class="dy-neighborhood-picker">
            <summary aria-label="Choose neighborhoods"><span data-area-caption>All neighborhoods</span></summary>
            <div>
                <?php foreach ($neighborhoods as $id => $name): ?>
                    <label><input type="checkbox" name="neighborhood_filter[]" value="<?= $id ?>"> <?= dy_filter_text($name) ?></label>
                <?php endforeach; ?>
            </div>
        </details></div>
        <label>Minimum price (SAR) <input data-min="price" type="number" min="0" inputmode="numeric" dir="ltr"></label>
        <label>Maximum price (SAR) <input data-max="price" type="number" min="0" inputmode="numeric" dir="ltr"></label>
        <label>Minimum area (m²) <input data-min="area" type="number" min="0" inputmode="decimal" dir="ltr"></label>
        <?php if ($isCatalog): ?>
            <label>Number of bedrooms <input data-filter="bedrooms" type="number" min="0" inputmode="numeric" dir="ltr"></label>
        <?php endif; ?>
        <button type="button" data-reset-listings><span aria-hidden="true">↺</span> Reset filters</button>
    </div>
    <?php
}
