</main>
<footer class="site-footer">
  <div class="container">Diyara. Neighborhood recommendations for Riyadh.</div>
</footer>
</body>
</html>
