<?php
// Usage at the top of ANY page (before any HTML):
//   $page_title = 'My Profile';   // shown in the browser tab
//   $active = 'profile';          // home | recommendations | profile
//   require 'includes/header.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$logged_in = isset($_SESSION['user_id']);
$page_title = $page_title ?? 'Diyara';
$active = $active ?? '';
function nav_class($key, $active) { return $key === $active ? 'active' : ''; }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?php echo htmlspecialchars($page_title); ?> | Diyara</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;600&family=DM+Serif+Display&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<header class="site-header">
  <div class="container">
    <a class="brand" href="index.php">Diyara</a>
    <nav class="nav">
      <a class="<?php echo nav_class('home', $active); ?>" href="index.php">Home</a>
      <a class="<?php echo nav_class('recommendations', $active); ?>" href="recommendations.php">Recommendations</a>
      <a class="<?php echo nav_class('profile', $active); ?>" href="profile.php">My Profile</a>
      <?php if ($logged_in): ?>
        <a href="logout.php">Logout</a>
      <?php else: ?>
        <a href="login.html">Login</a>
      <?php endif; ?>
    </nav>
  </div>
</header>
<main>
