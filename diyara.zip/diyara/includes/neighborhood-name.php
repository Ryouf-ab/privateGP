<?php
// Format neighborhood names.
function diyara_neighborhood_name(array $row): string
{
    $names = [trim((string) ($row['name_ar'] ?? '')), trim((string) ($row['name_en'] ?? ''))];
    return implode(' · ', array_unique(array_filter($names)));
}

// Format region names.
function diyara_region_name($value): string
{
    $region = trim((string) $value);
    $directions = ['شمال' => 'North', 'جنوب' => 'South', 'شرق' => 'East', 'غرب' => 'West', 'وسط' => 'Central'];
    foreach ($directions as $arabic => $english) {
        if ($region === $arabic || strcasecmp($region, $english) === 0) {
            return $english . ' Riyadh · ' . $arabic . ' الرياض';
        }
    }
    return $region;
}
