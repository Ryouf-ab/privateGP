<?php
const DIYARA_HOME_TYPES = ['Apartment' => 'شقة', 'Villa' => 'فيلا', 'Floor' => 'دور'];

// Read saved types.
function diyara_preferred_types(string $stored): array
{
    if (strcasecmp(trim($stored), 'Both') === 0) return ['Apartment', 'Villa'];
    $types = [];
    foreach (explode(',', $stored) as $value) {
        $value = trim($value);
        if ($value === '') continue;
        foreach (DIYARA_HOME_TYPES as $name => $arabic) {
            if (strcasecmp($value, $name) === 0 || $value === $arabic) {
                $value = $name;
                break;
            }
        }
        $types[] = $value;
    }
    return array_values(array_unique($types));
}
