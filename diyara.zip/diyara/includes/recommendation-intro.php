<?php
// Render recommendation navigation and cover.
function diyara_recommendation_intro(bool $homes, bool $compare = false): void
{
    $image = $homes ? 'property-hero-hd.webp' : 'district-hero-hd.webp';
    ?>
    <header class="riyadh-cover">
        <nav class="riyadh-switch" aria-label="Recommendation types">
            <a href="recommendations.php" <?= $homes ? 'aria-current="page"' : '' ?>>Properties</a>
            <a href="neighborhood-recommendations.php" <?= !$homes ? 'aria-current="page"' : '' ?>>Neighborhoods</a>
        </nav>
        <div class="riyadh-cover-copy">
            <h1><?= $homes ? 'Find your home' : 'Find your neighborhood' ?></h1>
            <p><?= $homes ? 'Explore homes that match your housing preferences.' : 'Explore Riyadh by the services you use most.' ?></p>
            <div class="riyadh-cover-links">
                <a href="<?= $homes ? 'housing-preferences.php' : 'lifestyle-preferences.php' ?>"><?= $homes ? 'Refine my preferences' : 'Adjust my priorities' ?> <span aria-hidden="true">↗</span></a>
                <?php if ($compare): ?><a href="#pr-compare-tools">Compare properties</a><?php endif; ?>
            </div>
        </div>
        <div class="riyadh-cover-art" aria-hidden="true"><img src="assets/<?= $image ?>" alt="" fetchpriority="high"></div>
    </header>
    <?php
}
