-- Diyara Sprint 2: photos for agent listings. Safe to run more than once.
-- Import in phpMyAdmin: select diyara_db > SQL tab > paste > Go.
SET NAMES utf8mb4;
CREATE TABLE IF NOT EXISTS property_images (
  image_id    INT AUTO_INCREMENT PRIMARY KEY,
  property_id VARCHAR(20) NOT NULL,
  file_name   VARCHAR(80) NOT NULL,
  sort_order  INT NOT NULL DEFAULT 0,
  created_at  TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_property_images_property (property_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
