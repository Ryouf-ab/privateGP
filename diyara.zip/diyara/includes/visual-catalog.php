<?php
/**
 * Presentation-only Diyara visual catalog.
 *
 * These generated photographs are *illustrations*, never evidence of what a
 * specific listing or neighborhood looks like. This file deliberately reads
 * no database data, changes no eligibility rule and computes no match score.
 */

if (!function_exists('dy_property_photo_kind')) {
    function dy_visual_src($assetPath): string
    {
        $assetPath = (string) $assetPath;
        if (!preg_match('/^assets\/[a-z0-9-]+\.jpg$/D', $assetPath)) return $assetPath;
        $updated = @filemtime(dirname(__DIR__) . '/' . $assetPath);
        return $assetPath . '?v=' . ($updated ?: '2');
    }

    function dy_property_photo_kind($propertyType): string
    {
        $type = mb_strtolower(trim((string) $propertyType), 'UTF-8');
        if (strpos($type, 'villa') !== false || mb_strpos($type, 'فيلا') !== false) return 'villa';
        if (strpos($type, 'apartment') !== false || mb_strpos($type, 'شقة') !== false) return 'apartment';
        return 'other';
    }

    function dy_property_exterior_photos($propertyType): array
    {
        $kind = dy_property_photo_kind($propertyType);
        if ($kind === 'villa') {
            return ['property-villa-exterior.jpg', 'property-villa-modern.jpg', 'property-villa-garden.jpg'];
        }
        if ($kind === 'apartment') {
            return ['property-apartment-exterior.jpg', 'property-apartment-courtyard.jpg', 'property-apartment-tower.jpg'];
        }
        return ['property-hero.jpg']; // Never mislabel an unknown type as a villa or apartment.
    }

    function dy_stable_photo_index($identifier, int $count): int
    {
        if ($count < 2) return 0;
        return (int) (hexdec(substr(sha1((string) $identifier), 0, 7)) % $count);
    }

    function dy_property_card_photo($propertyType, $propertyId): string
    {
        $images = dy_property_exterior_photos($propertyType);
        return 'assets/' . $images[dy_stable_photo_index($propertyId, count($images))];
    }

    function dy_property_gallery_photos($propertyType, $propertyId): array
    {
        $cover = dy_property_card_photo($propertyType, $propertyId);
        $kind = dy_property_photo_kind($propertyType);
        if ($kind === 'villa') {
            $otherExteriors = array_values(array_filter(dy_property_exterior_photos($propertyType), static function ($file) use ($cover) {
                return 'assets/' . $file !== $cover;
            }));
            return [
                ['file'=>$cover, 'label'=>'Villa exterior', 'alt'=>'Illustrative contemporary Riyadh villa exterior'],
                ['file'=>'assets/property-villa-interior.jpg', 'label'=>'Living room', 'alt'=>'Illustrative luxury villa living room interior'],
                ['file'=>'assets/property-villa-courtyard.jpg', 'label'=>'Garden courtyard', 'alt'=>'Illustrative Riyadh villa garden and courtyard'],
                ['file'=>'assets/' . $otherExteriors[0], 'label'=>'Architecture & garden', 'alt'=>'Illustrative Saudi villa architectural garden'],
            ];
        }
        if ($kind === 'apartment') {
            return [
                ['file'=>$cover, 'label'=>'Apartment building', 'alt'=>'Illustrative multi-unit Riyadh apartment building exterior'],
                ['file'=>'assets/property-apartment-interior.jpg', 'label'=>'Living room', 'alt'=>'Illustrative apartment living room interior'],
                ['file'=>'assets/property-apartment-kitchen.jpg', 'label'=>'Kitchen & dining', 'alt'=>'Illustrative apartment kitchen and dining room'],
                ['file'=>'assets/property-bedroom-interior.jpg', 'label'=>'Bedroom', 'alt'=>'Illustrative apartment bedroom'],
                ['file'=>'assets/property-terrace.jpg', 'label'=>'Terrace', 'alt'=>'Illustrative apartment terrace with city view'],
            ];
        }
        return [['file'=>$cover, 'label'=>'Riyadh living', 'alt'=>'Illustrative residential Riyadh scene']];
    }

    function dy_neighborhood_card_photo($region, $neighborhoodId): string
    {
        $sets = [
            'شمال'=>['neighborhood-villas.jpg', 'neighborhood-streets.jpg', 'neighborhood-park.jpg'],
            'جنوب'=>['neighborhood-park.jpg', 'neighborhood-streets.jpg', 'neighborhood-cafe.jpg'],
            'شرق'=>['neighborhood-boulevard.jpg', 'neighborhood-streets.jpg', 'neighborhood-park.jpg'],
            'غرب'=>['neighborhood-heritage.jpg', 'neighborhood-courtyard.jpg', 'neighborhood-streets.jpg'],
            'وسط'=>['neighborhood-skyline.jpg', 'neighborhood-cafe.jpg', 'neighborhood-boulevard.jpg'],
            'الدرعية'=>['neighborhood-heritage.jpg', 'neighborhood-courtyard.jpg'],
        ];
        $images = $sets[trim((string) $region)] ?? [
            'neighborhood-boulevard.jpg', 'neighborhood-park.jpg', 'neighborhood-heritage.jpg',
            'neighborhood-streets.jpg', 'neighborhood-villas.jpg', 'neighborhood-skyline.jpg',
            'neighborhood-courtyard.jpg', 'neighborhood-cafe.jpg',
        ];
        // Imagery style is inspired by a broad region; never a verified view of this district.
        return 'assets/' . $images[dy_stable_photo_index($neighborhoodId, count($images))];
    }
}
