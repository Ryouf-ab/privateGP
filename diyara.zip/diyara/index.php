


<?php

require 'db.php';

$page_title = 'Home';
$active = 'home';

/* ==========================================
   PROPERTY SORTING
========================================== */

$sort = $_GET['sort'] ?? 'name_az';

$allowedSorts = [

    'name_az' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) ASC
    ",

    'name_za' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) DESC
    ",

    'price_low' => "
        p.price IS NULL ASC,
        p.price ASC
    ",

    'price_high' => "
        p.price IS NULL ASC,
        p.price DESC
    "

];

if (!array_key_exists($sort, $allowedSorts)) {
    $sort = 'name_az';
}


/* ==========================================
   HELPER FUNCTIONS
========================================== */

function home_escape($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

function home_price($value)
{
    if ($value === null || $value === '') {
        return 'Price unavailable';
    }

    return number_format((float) $value) . ' SAR';
}


/* ==========================================
   GET ALL AVAILABLE PROPERTIES
========================================== */

$properties = [];
$errorMessage = '';

try {

    $sql = "
        SELECT
            p.property_id,
            p.property_type,
            p.price,
            p.area_m2,
            p.bedrooms,
            p.bathrooms,
            n.name_en,
            n.name_ar

        FROM properties p

        INNER JOIN neighborhoods n
            ON n.neighborhood_id = p.neighborhood_id

        ORDER BY
            " . $allowedSorts[$sort] . ",
            p.property_id ASC
    ";

    $stmt = $pdo->query($sql);

    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    error_log(
        'DIYARA home properties: ' . $e->getMessage()
    );

    $errorMessage = 'Properties are temporarily unavailable.';

}


/* ==========================================
   HEADER
========================================== */

require 'includes/header.php';

?>

<!-- LOAD HOME STYLES -->
<link rel="stylesheet" href="recommendations-extra.css?v=74">
<link rel="stylesheet" href="diyara.css?v=74">


<!-- ==========================================
     HERO SECTION
========================================== -->

<section class="hero">

    <div class="container">

        <div>

            <h1>
                Find Your Ideal Neighborhood
                <span>in Riyadh</span>
            </h1>

            <p>
                Personalized recommendations to match your lifestyle,
                needs, and future.
            </p>

            <a
                class="btn"
                href="<?php echo !empty($logged_in) ? 'recommendations.php' : 'register.html'; ?>"
            >
                Get Started
            </a>

        </div>

        <div
            class="hero-art"
            role="img"
            aria-label="Riyadh skyline illustration"
        ></div>

    </div>

</section>


<!-- ==========================================
     FEATURES SECTION
========================================== -->

<section class="features">

    <div class="container grid grid-3">

        <div class="card">

            <h3>Personalized Recommendations</h3>

            <p>
                Neighborhoods ranked around your budget,
                family size, and daily routine.
            </p>

        </div>


        <div class="card">

            <h3>Insights About Riyadh Neighborhoods</h3>

            <p>
                See nearby schools, services,
                and what each area is like to live in.
            </p>

        </div>


        <div class="card">

            <h3>A Better Living Experience</h3>

            <p>
                Choose where to live with confidence,
                not guesswork.
            </p>

        </div>

    </div>

</section>


<!-- ==========================================
     ALL PROPERTIES SHOWCASE
========================================== -->

<section
    class="home-properties"
    id="home-properties"
>

    <div class="container">

        <!-- HEADING -->

        <div class="home-properties-heading">

            <div>

                <span class="rec-eyebrow">
                    EXPLORE DIYARA
                </span>

                <h2>Explore Our Properties</h2>

                <p>
                    Discover properties available across Riyadh.
                    Find a place that feels like home.
                </p>

            </div>

        </div>


        <!-- SORTING -->

        <form
            method="GET"
            action="index.php"
            class="home-sort"
        >

            <label for="property-sort">
                Sort properties by
            </label>


            <select
                id="property-sort"
                name="sort"
                onchange="this.form.submit()"
            >

                <option
                    value="name_az"
                    <?php echo $sort === 'name_az' ? 'selected' : ''; ?>
                >
                    Alphabetical: A–Z
                </option>


                <option
                    value="name_za"
                    <?php echo $sort === 'name_za' ? 'selected' : ''; ?>
                >
                    Alphabetical: Z–A
                </option>


                <option
                    value="price_low"
                    <?php echo $sort === 'price_low' ? 'selected' : ''; ?>
                >
                    Price: Lowest to Highest
                </option>


                <option
                    value="price_high"
                    <?php echo $sort === 'price_high' ? 'selected' : ''; ?>
                >
                    Price: Highest to Lowest
                </option>

            </select>

        </form>


        <!-- PROPERTIES -->

        <?php if ($errorMessage !== ''): ?>

            <div class="empty">

                <?php echo home_escape($errorMessage); ?>

            </div>


        <?php elseif (empty($properties)): ?>

            <div class="empty">

                No properties are currently available.

            </div>


        <?php else: ?>


            <!-- HORIZONTAL CAROUSEL -->

            <div class="home-properties-track">

                <?php foreach ($properties as $property): ?>

                    <?php

                    $type = (string) $property['property_type'];

                    $isVilla =
                        stripos($type, 'villa') !== false ||
                        strpos($type, 'فيلا') !== false;

                    $imageType = $isVilla
                        ? 'villa'
                        : 'apartment';

                    $neighborhood =
                        $property['name_en']
                        ?: $property['name_ar']
                        ?: 'Riyadh';

                    ?>


                    <article class="home-property-card">


                        <!-- PROPERTY IMAGE -->

                        <div
                            class="home-property-image rec-property-image rec-image-<?php echo $imageType; ?>"
                            role="img"
                            aria-label="Illustrative property image"
                        >

                            <span>
                                Illustrative image
                            </span>

                        </div>


                        <!-- PROPERTY INFORMATION -->

                        <div class="home-property-content">


                            <div class="home-property-title">

                                <h3>
                                    <?php echo home_escape($type); ?>
                                </h3>

                                <strong>
                                    <?php echo home_price($property['price']); ?>
                                </strong>

                            </div>


                            <p class="home-property-neighborhood">

                                <span>Location:</span>

                                <?php echo home_escape($neighborhood); ?>

                                <?php if (!empty($property['name_ar'])): ?>

                                    · <?php echo home_escape($property['name_ar']); ?>

                                <?php endif; ?>

                            </p>


                            <!-- PROPERTY DETAILS -->

                            <div class="home-property-details">


                                <span>

                                    <?php

                                    echo $property['area_m2'] !== null
                                        ? number_format((float) $property['area_m2']) . ' m²'
                                        : 'Area unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bedrooms'] !== null
                                        ? (int) $property['bedrooms'] . ' Bedrooms'
                                        : 'Bedrooms unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bathrooms'] !== null
                                        ? (int) $property['bathrooms'] . ' Bathrooms'
                                        : 'Bathrooms unavailable';

                                    ?>

                                </span>

                            </div>


                            <small class="home-property-id">

                                Property #
                                <?php echo home_escape($property['property_id']); ?>

                            </small>


                        </div>

                    </article>


                <?php endforeach; ?>

            </div>


            <p class="home-scroll-hint">

                Scroll horizontally to explore more properties →

            </p>


        <?php endif; ?>


    </div>

</section>


<!-- ==========================================
     FOOTER
========================================== -->

<?php require 'includes/footer.php'; ?>
