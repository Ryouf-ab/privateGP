


<?php
require_once __DIR__ . "/includes/neighborhood-name.php";

require 'db.php';
require_once 'includes/discovery-filters.php';

$page_title = 'Home';
$active = 'home';

/* ==========================================
   PROPERTY SORTING
========================================== */

$sort = $_GET['sort'] ?? 'name_az';

$allowedSorts = [

    'name_az' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) ASC
    ",

    'name_za' => "
        LOWER(COALESCE(NULLIF(TRIM(n.name_en), ''), n.name_ar, '')) DESC
    ",

    'price_low' => "
        p.price IS NULL ASC,
        p.price ASC
    ",

    'price_high' => "
        p.price IS NULL ASC,
        p.price DESC
    "

];

if (!is_string($sort) || !array_key_exists($sort, $allowedSorts)) {
    $sort = 'name_az';
}


/* ==========================================
   HELPER FUNCTIONS
========================================== */

// Escape catalog text.
function home_escape($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}

// Format asking price.
function home_price($value)
{
    if ($value === null || $value === '') {
        return 'Price unavailable';
    }

    return number_format((float) $value) . ' SAR';
}


/* ==========================================
   GET ALL AVAILABLE PROPERTIES
========================================== */

$properties = [];
$errorMessage = '';

try {

    $sql = "
        SELECT
            p.property_id,
            p.property_type,
            p.price,
            p.area_m2,
            p.bedrooms,
            p.bathrooms,
            n.name_en,
            n.name_ar,
            n.neighborhood_id,
            n.region

        FROM properties p

        INNER JOIN neighborhoods n
            ON n.neighborhood_id = p.neighborhood_id

        WHERE LOWER(TRIM(p.property_type)) IN ('villa', 'apartment', 'floor', 'فيلا', 'شقة', 'دور')
        ORDER BY
            " . $allowedSorts[$sort] . ",
            p.property_id ASC
    ";

    $stmt = $pdo->query($sql);

    $properties = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Throwable $e) {

    error_log(
        'DIYARA home properties: ' . $e->getMessage()
    );

    $errorMessage = 'Properties are temporarily unavailable.';

}

// Agent-uploaded listing photographs take precedence over type-matched visuals.
require_once __DIR__ . '/property_images_lib.php';
require_once __DIR__ . '/property_fallback_photos.php';
$homePhotoUses = [];
$homeListingPhotos = property_images_for($pdo, array_column($properties, 'property_id'));


/* ==========================================
   HEADER
========================================== */

require 'includes/header.php';

?>

<!-- LOAD HOME STYLES -->
<link rel="stylesheet" href="recommendations-extra.css?v=74">
<link rel="stylesheet" href="diyara.css?v=74">
<link rel="stylesheet" href="assets/css/home-premium.css?v=<?= @filemtime(__DIR__ . '/assets/css/home-premium.css') ?: time() ?>">
<link rel="stylesheet" href="assets/css/editorial-surfaces.css?v=5">


<!-- ==========================================
     HERO SECTION
========================================== -->

<section class="hero dy-home-hero">

    <div class="container dy-home-hero-inner">

        <div class="dy-home-copy">

            <h1 lang="ar" dir="rtl">ديارا <span class="dy-home-tagline">| لكل طبعٍ حيّ</span></h1>

            <p>
                Discover Riyadh neighborhoods for your daily life, and homes that fit how you want to live.
            </p>

            <div class="dy-home-actions">
                <a class="dy-home-primary" href="<?php echo !empty($logged_in) ? 'recommendations.php' : 'register.html'; ?>">Explore your matches <span aria-hidden="true">↗</span></a>
                <a class="dy-home-secondary" href="#home-properties">Discover properties <span aria-hidden="true">↓</span></a>
            </div>

        </div>

        <div class="dy-home-visual">
            <div class="dy-hero-weave" aria-hidden="true"></div>
            <div class="dy-hero-halo" aria-hidden="true"></div>
            <figure class="dy-home-main-photo">
                <img src="assets/riyadh-evening-hd.webp" alt="Riyadh skyline at dusk beyond a palm-lined promenade" fetchpriority="high" decoding="async">
            </figure>
            <div class="dy-hero-inset" aria-hidden="true"><img src="assets/home-limestone.webp" alt="" decoding="async"></div>
            <span class="dy-hero-diamond" aria-hidden="true"></span>
        </div>

    </div>

</section>


<!-- Two clear paths into the two independent recommendation experiences. -->
<section class="dy-home-journeys" aria-labelledby="dyJourneysTitle">
    <div class="container">
        <div class="dy-home-journeys-heading">
            <div><h2 id="dyJourneysTitle">Explore Diyara</h2></div>
        </div>
        <div class="dy-home-journeys-grid">
            <a class="dy-home-journey" href="<?= !empty($logged_in) ? 'recommendations.php' : 'register.html' ?>">
                <img src="assets/property-hero-hd.webp" alt="Contemporary architecture with landscaped outdoor living" loading="lazy" decoding="async">
                <span class="dy-home-journey-overlay"><strong>Discover properties</strong><span>Match homes to your budget, space and housing needs.</span><span class="dy-home-journey-arrow" aria-hidden="true">↗</span></span>
            </a>
            <a class="dy-home-journey" href="<?= !empty($logged_in) ? 'neighborhood-recommendations.php' : 'register.html' ?>">
                <img src="assets/district-hero-hd.webp" alt="Riyadh urban neighborhood with landscaped pedestrian streets" loading="lazy" decoding="async">
                <span class="dy-home-journey-overlay"><strong>Explore neighborhoods</strong><span>See how local services match your priorities.</span><span class="dy-home-journey-arrow" aria-hidden="true">↗</span></span>
            </a>
        </div>
    </div>
</section>


<!-- ==========================================
     ALL PROPERTIES SHOWCASE
========================================== -->

<section
    class="home-properties"
    id="home-properties" data-listing-view
>

    <div class="container">

        <!-- HEADING -->

        <div class="home-properties-heading">

            <div>

                <span class="rec-eyebrow">
                    EXPLORE DIYARA
                </span>

                <h2>Browse all properties</h2>

                <p>
                    Discover properties available across Riyadh.
                    
                </p>

            </div>



        <!-- SORTING -->

        <form
            method="GET"
            action="index.php#home-properties"
            class="home-sort"
        >

            <label for="property-sort">
                Sort properties by
            </label>


            <select
                id="property-sort"
                name="sort"
                onchange="this.form.requestSubmit()"
            >

                <option
                    value="name_az"
                    <?php echo $sort === 'name_az' ? 'selected' : ''; ?>
                >
                    Neighborhood: A–Z
                </option>


                <option
                    value="name_za"
                    <?php echo $sort === 'name_za' ? 'selected' : ''; ?>
                >
                    Neighborhood: Z–A
                </option>


                <option
                    value="price_low"
                    <?php echo $sort === 'price_low' ? 'selected' : ''; ?>
                >
                    Price: Lowest to Highest
                </option>


                <option
                    value="price_high"
                    <?php echo $sort === 'price_high' ? 'selected' : ''; ?>
                >
                    Price: Highest to Lowest
                </option>

            </select><noscript><button type="submit">Sort</button></noscript>

        </form>
        </div>


        <!-- PROPERTIES -->

        <?php if ($errorMessage !== ''): ?>

            <div class="empty">

                <?php echo home_escape($errorMessage); ?>

            </div>


        <?php elseif (empty($properties)): ?>

            <div class="empty">

                No properties are currently available.

            </div>


        <?php else: ?>


            <!-- HORIZONTAL CAROUSEL -->

            <?php dy_listing_filters($properties, true); ?>
            <p data-listing-count aria-live="polite"><?= count($properties) ?> properties</p>
            <p data-listing-empty hidden>No homes match your filters.</p>
            <div class="home-properties-track dy-catalog-grid" data-listing-grid>

                <?php foreach ($properties as $property): ?>

                    <?php

                    $type = (string) $property['property_type'];

                    $uploadedForThisHome = $homeListingPhotos[(string) $property['property_id']] ?? [];
                    $hasRealPhoto = !empty($uploadedForThisHome[0]['url']);
                    $homePhoto = $hasRealPhoto
                        ? $uploadedForThisHome[0]['url']
                        : diyara_property_photo((string) $property['property_id'], $type, 'all', $homePhotoUses) . '?v=20261120e';

                    $neighborhood =
                        diyara_neighborhood_name($property)
                        ?: 'Riyadh';

                    ?>


                    <article class="home-property-card"
                        data-name="<?= home_escape($neighborhood) ?>"
                        data-type="<?= home_escape(dy_property_type($type)) ?>"
                        data-region="<?= home_escape(trim((string)$property['region'])) ?>"
                        data-neighborhood="<?= (int)$property['neighborhood_id'] ?>"
                        data-price="<?= home_escape($property['price']) ?>"
                        data-area="<?= home_escape($property['area_m2']) ?>"
                        data-bedrooms="<?= home_escape($property['bedrooms']) ?>">


                        <!-- PROPERTY IMAGE -->

                        <div class="home-property-image rec-property-image dy-home-property-photo">
                            <?php if ($regionLabel = diyara_region_name($property['region'] ?? '')): ?><small class="listing-region" dir="auto"><?= home_escape($regionLabel) ?></small><?php endif; ?><img src="<?= home_escape($homePhoto) ?>"
                                 alt="<?= $hasRealPhoto ? 'Photo of this property' : '' ?>"
                                 loading="lazy" decoding="async">
                        </div>


                        <!-- PROPERTY INFORMATION -->

                        <div class="home-property-content">


                            <div class="home-property-title">

                                <h3>
                                    <?= home_escape(dy_property_type($type)) ?>
                                </h3>

                                <strong>
                                    <?php echo home_price($property['price']); ?>
                                </strong>

                            </div>


                            <p class="home-property-neighborhood">

                                <span>Location:</span>

                                <?php echo home_escape($neighborhood); ?>



                            </p>


                            <!-- PROPERTY DETAILS -->

                            <div class="home-property-details">


                                <span>

                                    <?php

                                    echo $property['area_m2'] !== null
                                        ? number_format((float) $property['area_m2']) . ' m²'
                                        : 'Area unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bedrooms'] !== null
                                        ? (int) $property['bedrooms'] . ' Bedrooms'
                                        : 'Bedrooms unavailable';

                                    ?>

                                </span>


                                <span>

                                    <?php

                                    echo $property['bathrooms'] !== null
                                        ? (int) $property['bathrooms'] . ' Bathrooms'
                                        : 'Bathrooms unavailable';

                                    ?>

                                </span>

                            </div>


                            <small class="home-property-id">

                                Property #
                                <?php echo home_escape($property['property_id']); ?>

                            </small>


                        </div>

                    </article>


                <?php endforeach; ?>

            </div>





        <?php endif; ?>


    </div>

</section>


<!-- ==========================================
     FOOTER
========================================== -->

<script src="assets/js/listing-filters.js?v=4" defer></script>
<?php require 'includes/footer.php'; ?>
