<?php
$page_title = 'Home';
$active = 'home';
require 'includes/header.php';
$start_link = $logged_in ? 'recommendations.php' : 'register.html';
?>
<section class="hero">
  <div class="container">
    <div>
      <h1>Find Your Ideal Neighborhood <span>in Riyadh</span></h1>
      <p>Personalized recommendations to match your lifestyle, needs, and future.</p>
      <a class="btn" href="<?php echo $start_link; ?>">Get Started</a>
    </div>
    <div class="hero-art" role="img" aria-label="Riyadh skyline illustration"></div>
  </div>
</section>

<section class="features">
  <div class="container grid grid-3">
    <div class="card"><h3>Personalized Recommendations</h3><p>Neighborhoods ranked around your budget, family size, and daily routine.</p></div>
    <div class="card"><h3>Insights About Riyadh Neighborhoods</h3><p>See nearby schools, services, and what each area is like to live in.</p></div>
    <div class="card"><h3>A Better Living Experience</h3><p>Choose where to live with confidence, not guesswork.</p></div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
