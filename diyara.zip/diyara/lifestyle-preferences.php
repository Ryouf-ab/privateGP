<?php

require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];

$message = '';
$error = '';


$income_options = [
    'Less than 10,000 SAR',
    '10,000 - 20,000 SAR',
    '20,001 - 30,000 SAR',
    '30,001 - 40,000 SAR',
    '40,001 - 50,000 SAR',
    'More than 50,000 SAR'
];


$routine_options = [
    'Student',
    'Employee',
    'Self-Employed',
    'Remote Worker',
    'Homemaker',
    'Retired',
    'Not Currently Working',
    'Flexible Schedule'
];


$services = [
    'Schools',
    'Healthcare',
    'Parks',
    'Supermarkets',
    'Banks',
    'Gas Stations'
];


/* =========================================================
GET CURRENT PREFERENCES
========================================================= */

$stmt = $pdo->prepare("
    SELECT *
    FROM lifestyle_preferences
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$preferences =
    $stmt->fetch(PDO::FETCH_ASSOC);

$has_preferences =
    (bool)$preferences;


$form_income_level =
    $preferences['income_level'] ?? '';

$form_family_size =
    $preferences['family_size'] ?? '';

$form_daily_routine =
    $preferences['daily_routine'] ?? '';

$form_important_destination =
    $preferences['important_destination'] ?? '';

$saved_services = [];


if (
    $preferences &&
    !empty($preferences['required_services'])
) {

    $saved_services =
        json_decode(
            $preferences['required_services'],
            true
        ) ?? [];
}


/* =========================================================
SAVE / UPDATE
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action =
        $_POST['action'] ?? 'save';


    $form_income_level =
        trim($_POST['income_level'] ?? '');


    $form_family_size =
        (int)($_POST['family_size'] ?? 0);


    $form_daily_routine =
        trim($_POST['daily_routine'] ?? '');


    $form_important_destination =
        trim($_POST['important_destination'] ?? '');


    $saved_services =
        $_POST['required_services'] ?? [];


    if (
        !in_array(
            $form_income_level,
            $income_options,
            true
        )
    ) {

        $error =
            'Please select a valid income level.';

    } elseif (
        $form_family_size < 1 ||
        $form_family_size > 20
    ) {

        $error =
            'Family size must be between 1 and 20.';

    } elseif (
        !in_array(
            $form_daily_routine,
            $routine_options,
            true
        )
    ) {

        $error =
            'Please select a valid daily routine.';

    } elseif (
        $form_important_destination === '' ||
        strlen($form_important_destination) > 255
    ) {

        $error =
            'Please enter a valid important destination.';

    } elseif (
        !is_array($saved_services) ||
        empty($saved_services)
    ) {

        $error =
            'Please select at least one required service.';

    } else {

        $invalid_services =
            array_diff(
                $saved_services,
                $services
            );

        if (!empty($invalid_services)) {

            $error =
                'Please select valid required services.';

        } else {

            $services_json =
                json_encode(
                    array_values(
                        array_unique(
                            $saved_services
                        )
                    ),
                    JSON_UNESCAPED_UNICODE
                );


            $sql = "
                INSERT INTO lifestyle_preferences
                (
                    user_id,
                    income_level,
                    family_size,
                    daily_routine,
                    important_destination,
                    required_services
                )

                VALUES (?, ?, ?, ?, ?, ?)

                ON DUPLICATE KEY UPDATE

                    income_level =
                        VALUES(income_level),

                    family_size =
                        VALUES(family_size),

                    daily_routine =
                        VALUES(daily_routine),

                    important_destination =
                        VALUES(important_destination),

                    required_services =
                        VALUES(required_services)
            ";


            $stmt =
                $pdo->prepare($sql);


            $stmt->execute([
                $user_id,
                $form_income_level,
                $form_family_size,
                $form_daily_routine,
                $form_important_destination,
                $services_json
            ]);


            $has_preferences = true;


            if ($action === 'save') {

                $message =
                    'Your lifestyle preferences have been updated successfully.';
            }


            if ($action === 'continue') {

                header(
                    'Location: housing-preferences.php'
                );

                exit;
            }
        }
    }
}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Lifestyle Preferences | Diyara
</title>


<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
rel="stylesheet"
>

<link
rel="stylesheet"
href="diyara.css?v=71"
>

</head>


<body class="page-lifestyle">


<header class="site-topbar">


<div class="topbar-brand">

<div class="topbar-logo-slot"></div>

<div class="topbar-brand-text">

<strong>
Diyara
</strong>

<span>
Live where you belong.
</span>

</div>

</div>


<nav class="topbar-nav">

<a
href="index.php"
class="topbar-link"
>
Home
</a>

<a
href="recommendations.php"
class="topbar-link"
>
Recommendations
</a>

<a
href="profile.php"
class="topbar-link"
>
My Profile
</a>

<a
href="logout.php"
class="topbar-link"
>
Logout
</a>

</nav>


</header>



<main class="page-body lifestyle-page">


<section class="lifestyle-visual">


<img
src="images/lifestyle-art.png"
alt="Riyadh lifestyle"
>


<div class="life-quote">


<h3 dir="rtl">
وش يقرّبك لجوّك؟
</h3>


<p dir="rtl">
يومك وتفاصيله تقول كثير،
ومنها نلقى لك الحي اللي يليق بك.
</p>


</div>


</section>



<section class="lifestyle-form-side">


<div class="lifestyle-progress">

<div class="progress-track">


<div class="progress-step current">

<div class="step-circle">
1
</div>

<span>
Lifestyle
</span>

</div>


<div class="step-line"></div>


<div class="progress-step">

<div class="step-circle">
2
</div>

<span>
Housing
</span>

</div>


<div class="step-line"></div>


<div class="progress-step">

<div class="step-circle">
3
</div>

<span>
Complete
</span>

</div>


</div>

</div>



<section class="page-intro">


<div class="section-label">

<span></span>

PERSONALIZATION

</div>


<h1>
Lifestyle Preferences
</h1>


<p>
Help us understand your daily life and priorities.
Your answers help Diyara identify Riyadh neighborhoods
that fit the way you live.
</p>


</section>



<?php if ($message): ?>

<div class="notification success-message">

<div class="notification-icon">
✓
</div>

<div>

<strong>
Saved successfully
</strong>

<p>
<?php
echo htmlspecialchars(
    $message,
    ENT_QUOTES,
    'UTF-8'
);
?>
</p>

</div>

</div>

<?php endif; ?>



<?php if ($error): ?>

<div class="notification error-message">

<div class="notification-icon">
!
</div>

<div>

<strong>
Check your information
</strong>

<p>
<?php
echo htmlspecialchars(
    $error,
    ENT_QUOTES,
    'UTF-8'
);
?>
</p>

</div>

</div>

<?php endif; ?>



<form
method="POST"
class="form-card"
>


<div class="form-card-header">

<div>

<span class="form-number">
01
</span>

<h2>
Tell us about your lifestyle
</h2>

</div>


<p>
All fields marked with
<span>*</span>
are required.
</p>

</div>



<div class="form-grid two-column">


<div class="input-group">

<label for="income_level">

Income Level

<span>*</span>

</label>


<select
id="income_level"
name="income_level"
required
>

<option value="">
Select income level
</option>


<?php foreach ($income_options as $option): ?>

<option
value="<?php
echo htmlspecialchars(
    $option,
    ENT_QUOTES,
    'UTF-8'
);
?>"

<?php
echo (
    $form_income_level === $option
)
? 'selected'
: '';
?>
>

<?php
echo htmlspecialchars(
    $option,
    ENT_QUOTES,
    'UTF-8'
);
?>

</option>

<?php endforeach; ?>


</select>

</div>



<div class="input-group">

<label for="family_size">

Family Size

<span>*</span>

</label>


<input
type="number"
id="family_size"
name="family_size"
min="1"
max="20"
placeholder="e.g. 4"
value="<?php
echo htmlspecialchars(
    (string)$form_family_size,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>

</div>


</div>



<div class="form-grid two-column">


<div class="input-group">

<label for="daily_routine">

Daily Routine

<span>*</span>

</label>


<select
id="daily_routine"
name="daily_routine"
required
>

<option value="">
Select your daily routine
</option>


<?php foreach ($routine_options as $option): ?>

<option
value="<?php
echo htmlspecialchars(
    $option,
    ENT_QUOTES,
    'UTF-8'
);
?>"

<?php
echo (
    $form_daily_routine === $option
)
? 'selected'
: '';
?>
>

<?php
echo htmlspecialchars(
    $option,
    ENT_QUOTES,
    'UTF-8'
);
?>

</option>

<?php endforeach; ?>


</select>

</div>



<div class="input-group">

<label for="important_destination">

Important Destination

<span>*</span>

</label>


<input
type="text"
id="important_destination"
name="important_destination"
maxlength="255"
placeholder="e.g. King Saud University"
value="<?php
echo htmlspecialchars(
    $form_important_destination,
    ENT_QUOTES,
    'UTF-8'
);
?>"
required
>


<small>
Workplace, university, school,
hospital or another regular destination.
</small>

</div>


</div>



<div class="services-section">


<div class="services-heading">


<div>

<label>

Required Services

<span>*</span>

</label>

<small>
Select nearby services that matter to you.
</small>

</div>


<div class="multi-select-label">
Multiple selection
</div>


</div>



<div class="services-grid">


<?php foreach ($services as $service): ?>


<label class="service-choice">


<input
type="checkbox"
name="required_services[]"
value="<?php
echo htmlspecialchars(
    $service,
    ENT_QUOTES,
    'UTF-8'
);
?>"

<?php
echo in_array(
    $service,
    $saved_services,
    true
)
? 'checked'
: '';
?>
>


<span class="service-box">

<span class="custom-check">
✓
</span>

<span>

<?php
echo htmlspecialchars(
    $service,
    ENT_QUOTES,
    'UTF-8'
);
?>

</span>

</span>


</label>


<?php endforeach; ?>


</div>


</div>



<div class="form-actions">


<a
href="profile.php"
class="button back-button"
>
← Back
</a>


<div class="primary-actions">


<?php if ($has_preferences): ?>

<button
type="submit"
name="action"
value="save"
class="button save-button"
>
Save Changes
</button>

<?php endif; ?>


<button
type="submit"
name="action"
value="continue"
class="button continue-button"
>
Continue →
</button>


</div>


</div>


</form>


</section>


</main>



<footer class="diyara-footer">


<div class="footer-brand">

<div class="footer-mark"></div>

<div>

<strong>Diyara</strong>

<span>Live where you belong.</span>

</div>

</div>


<div class="footer-center">

<strong dir="rtl">
ديارٍ تشبهك، وحيٍّ يناسبك.
</strong>

<span>
Riyadh · Heritage · Future
</span>

</div>


<div class="footer-end">

<span class="footer-line"></span>

<p>
Riyadh, Saudi Arabia
<br>
© 2026 Diyara
</p>

</div>


</footer>


</body>

</html>