
<?php

require 'auth_check.php';
try {
    require 'db.php';
} catch (Throwable $e) {
    // A failed MySQL connection used to terminate with a blank page when
    // display_errors is disabled in MAMP. Keep connection details private.
    error_log('Diyara Lifestyle DB connection: ' . $e->getMessage());
    http_response_code(503);
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><title>Diyara — Connection issue</title></head>'
       . '<body style="font:16px Arial,sans-serif;max-width:650px;margin:80px auto;padding:25px;color:#314550">'
       . '<h1>Unable to connect to Diyara</h1><p>Please start MySQL in MAMP and check the database host, port and credentials in <code>db.php</code>.</p>'
       . '<p>Your preferences have not been changed.</p></body></html>';
    exit;
}

$user_id = $_SESSION['user_id'];

$message = '';
$error = '';

/* =========================================================
   OPTIONS
========================================================= */

$income_options = [
    'Less than 10,000 SAR',
    '10,000 - 20,000 SAR',
    '20,001 - 30,000 SAR',
    '30,001 - 40,000 SAR',
    '40,001 - 50,000 SAR',
    'More than 50,000 SAR'
];


$routine_options = [
    'Student',
    'Employee',
    'Self-Employed',
    'Remote Worker',
    'Homemaker',
    'Retired',
    'Not Currently Working',
    'Flexible Schedule'
];

$services = [
    'Schools',
    'Healthcare',
    'Parks',
    'Supermarkets',
    'Banks',
    'Gas Stations'
];

/* =========================================================
   GET CURRENT PREFERENCES
========================================================= */

$preferences = false;
try {
    $stmt = $pdo->prepare("
        SELECT *
        FROM lifestyle_preferences
        WHERE user_id = ?
    ");
    $stmt->execute([$user_id]);
    $preferences = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) {
    error_log('Diyara Lifestyle load: ' . $e->getMessage());
    $error = 'Could not load your saved preferences. Please check that the lifestyle_preferences table exists in diyara_db.';
}

$has_preferences = (bool)$preferences;

$form_income_level =
    $preferences['income_level'] ?? '';

$form_family_size =
    $preferences['family_size'] ?? '';

$form_daily_routine =
    $preferences['daily_routine'] ?? '';

/* =========================================================
   GET MULTIPLE DESTINATIONS
   Supports old single destination and new JSON format
========================================================= */

$form_important_destinations = [];

$raw_destinations =
    $preferences['important_destination'] ?? '';

if (!empty($raw_destinations)) {

    $decoded_destinations =
        json_decode($raw_destinations, true);

    // array_values() check is compatible with older MAMP PHP versions.
    if (
        is_array($decoded_destinations) &&
        array_values($decoded_destinations) === $decoded_destinations
    ) {

        $form_important_destinations =
            $decoded_destinations;

    } else {

        // Support old single destination
        $form_important_destinations = [
            $raw_destinations
        ];
    }
}

if (empty($form_important_destinations)) {
    $form_important_destinations = [''];
}

/* =========================================================
   GET SAVED SERVICES
========================================================= */

$saved_services = [];

if (
    $preferences &&
    !empty($preferences['required_services'])
) {

    $saved_services = json_decode(
        $preferences['required_services'],
        true
    ) ?? [];

    if (!is_array($saved_services)) {
        $saved_services = [];
    }
}

/* Service ratings are stored separately to preserve the existing
   required_services JSON list used by the profile and other pages. */
$service_ratings = array_fill_keys($services, 0);
if ($preferences && !empty($preferences['service_importance'])) {
    $decoded_ratings = json_decode($preferences['service_importance'], true);
    if (is_array($decoded_ratings)) {
        foreach ($services as $service) {
            if (isset($decoded_ratings[$service]) && filter_var($decoded_ratings[$service], FILTER_VALIDATE_INT) !== false) {
                $service_ratings[$service] = max(0, min(5, (int)$decoded_ratings[$service]));
            }
        }
    }
} else {
    // Existing selections are kept when migrating from Sprint 1.
    foreach ($saved_services as $service) {
        if (array_key_exists($service, $service_ratings)) {
            $service_ratings[$service] = 3;
        }
    }
}

/* =========================================================
   SAVE / UPDATE
========================================================= */

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $action = $_POST['action'] ?? 'save';

    $form_income_level =
        trim($_POST['income_level'] ?? '');

    $form_family_size =
        (int)($_POST['family_size'] ?? 0);

    $form_daily_routine =
        trim($_POST['daily_routine'] ?? '');

    /* MULTIPLE DESTINATIONS */

    $form_important_destinations =
        $_POST['important_destinations'] ?? [];

    if (!is_array($form_important_destinations)) {
        $form_important_destinations = [];
    }

    $form_important_destinations =
        array_map(
            function ($destination) {
                return trim((string)$destination);
            },
            $form_important_destinations
        );

    // Remove empty destinations
    $form_important_destinations =
        array_filter(
            $form_important_destinations,
            function ($destination) {
                return $destination !== '';
            }
        );

    // Remove duplicate destinations
    $form_important_destinations =
        array_values(
            array_unique($form_important_destinations)
        );

    $posted_ratings = $_POST['service_importance'] ?? [];
    $service_ratings = [];
    $invalid_rating = !is_array($posted_ratings);
    $posted_ratings = is_array($posted_ratings) ? $posted_ratings : [];
    // Reject unknown service keys and non-integer values.
    foreach ($posted_ratings as $service => $rating) {
        if (!in_array($service, $services, true) || !is_scalar($rating)) {
            $invalid_rating = true;
        }
    }
    foreach ($services as $service) {
        $rating = $posted_ratings[$service] ?? null;
        if (!is_string($rating) || !preg_match('/^[0-5]$/', $rating)) {
            $invalid_rating = true;
            $service_ratings[$service] = 0;
        } else {
            $service_ratings[$service] = (int)$rating;
        }
    }
    // Preserve the legacy format for existing consumers of required_services.
    $saved_services = array_keys(array_filter(
        $service_ratings,
        static function ($rating) { return $rating > 0; }
    ));

    /* =====================================================
       VALIDATION
    ===================================================== */

    if (
        !in_array(
            $form_income_level,
            $income_options,
            true
        )
    ) {

        $error = 'Please select a valid income level.';

    } elseif (
        $form_family_size < 1 ||
        $form_family_size > 20
    ) {

        $error =
            'Family size must be between 1 and 20.';

    } elseif (
        !in_array(
            $form_daily_routine,
            $routine_options,
            true
        )
    ) {

        $error =
            'Please select a valid daily routine.';

    } elseif (
        empty($form_important_destinations)
    ) {

        $error =
            'Please enter at least one important destination.';

    } elseif (
        count($form_important_destinations) > 10
    ) {

        $error =
            'You can add a maximum of 10 destinations.';

    } elseif (
        count(
            array_filter(
                $form_important_destinations,
                function ($destination) {

                    return mb_strlen(
                        $destination,
                        'UTF-8'
                    ) > 255;

                }
            )
        ) > 0
    ) {

        $error =
            'Each destination must not exceed 255 characters.';

    } elseif ($invalid_rating) {

        $error = 'Please choose a valid importance rating (0–5) for every service.';

    } elseif (
        empty($saved_services)
    ) {

        $error =
            'Rate at least one service from 1 to 5 to get a personalized neighborhood service score.';

    } else {

        $invalid_services =
            array_diff(
                $saved_services,
                $services
            );

        if (!empty($invalid_services)) {

            $error =
                'Please enter valid service importance ratings.';

        } else {

            /* ENCODE DESTINATIONS */

            $destinations_json = json_encode(
                $form_important_destinations,
                JSON_UNESCAPED_UNICODE
            );

            /* ENCODE SERVICES */

            $services_json = json_encode(
                array_values(
                    array_unique($saved_services)
                ),
                JSON_UNESCAPED_UNICODE
            );

            /* SAVE TO DATABASE */

            $sql = "

                INSERT INTO lifestyle_preferences

                (
                    user_id,
                    income_level,
                    family_size,
                    daily_routine,
                    important_destination,
                    required_services,
                    service_importance
                )

                VALUES (?, ?, ?, ?, ?, ?, ?)

                ON DUPLICATE KEY UPDATE

                    income_level =
                        VALUES(income_level),

                    family_size =
                        VALUES(family_size),

                    daily_routine =
                        VALUES(daily_routine),

                    important_destination =
                        VALUES(important_destination),

                    required_services =
                        VALUES(required_services),

                    service_importance =
                        VALUES(service_importance)

            ";

            try {
                $stmt = $pdo->prepare($sql);
                $stmt->execute([
                    $user_id,
                    $form_income_level,
                    $form_family_size,
                    $form_daily_routine,
                    $destinations_json,
                    $services_json,
                    json_encode($service_ratings, JSON_UNESCAPED_UNICODE)
                ]);
                $has_preferences = true;

                if ($action === 'save') {
                    $message = 'Your lifestyle preferences have been updated successfully.';
                }

                if ($action === 'continue') {
                    header('Location: housing-preferences.php');
                    exit;
                }
            } catch (Throwable $e) {
                error_log('Diyara Lifestyle save: ' . $e->getMessage());
                $error = 'Your preferences could not be saved. Please check that the service_importance column exists in the lifestyle_preferences table.';
            }

        }
    }

    // Preserve form values after validation errors
    if (empty($form_important_destinations)) {
        $form_important_destinations = [''];
    }

}

?>

<!DOCTYPE html>

<html lang="en">

<head>

<meta charset="UTF-8">

<meta
name="viewport"
content="width=device-width, initial-scale=1.0"
>

<title>
Lifestyle Preferences | Diyara
</title>

<link
href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
rel="stylesheet"
>

<link
rel="stylesheet"
href="diyara.css?v=74"
>

<style>

/* =========================================================
   MULTIPLE DESTINATIONS
========================================================= */

.destination-input-row {

    display: flex;
    align-items: center;
    gap: 10px;
    margin-bottom: 12px;

}

.destination-input-row input {

    flex: 1;
    min-width: 0;

}

.remove-destination {

    width: 42px;
    min-width: 42px;
    height: 42px;

    border: 1px solid #d8c7c1;
    border-radius: 10px;

    background: #ffffff;
    color: #a66e61;

    font-size: 23px;
    cursor: pointer;

    transition: 0.2s;

}

.remove-destination:hover {

    background: #f8eeeb;
    border-color: #b98779;

}

.add-destination-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;

    margin-top: 5px;
    padding: 7px 11px;

    border: 1px solid #b98779;
    border-radius: 8px;

    background: transparent;
    color: #9c6d60;

    font-family: 'DM Sans', sans-serif;
    font-size: 11px;
    font-weight: 600;

    cursor: pointer;
    transition: 0.2s;
}

.add-destination-button:hover {
    background: #f8eeeb;
}


.add-destination-button:disabled {

    opacity: 0.5;
    cursor: not-allowed;

}

.destination-hint {

    display: block;
    margin-top: 10px;

    color: #888888;
    font-size: 12px;

}

@media (max-width: 600px) {

    .destination-input-row {
        gap: 7px;
    }

    .remove-destination {
        width: 38px;
        min-width: 38px;
        height: 38px;
    }

}

</style>

<link rel="stylesheet" href="lifestyle-pro.css?v=<?= @filemtime(__DIR__ . '/lifestyle-pro.css') ?: time() ?>">

    <link rel="stylesheet" href="assets/css/theme.css?v=1">
    <script src="assets/js/theme.js?v=2"></script>
    <link rel="stylesheet" href="assets/css/atelier.css?v=8">
    <link rel="stylesheet" href="assets/css/arabic-refinements.css?v=1">
<link rel="stylesheet" href="assets/css/editorial-surfaces.css?v=10">
</head>

<body class="page-lifestyle">

<header class="site-topbar">

    <div class="topbar-brand">

        <div class="topbar-logo-slot"></div>

        <div class="topbar-brand-text">

            <strong>
                Diyara
            </strong>

            <span>
                Live where you belong.
            </span>

        </div>

    </div>

    <nav class="topbar-nav">

        <a
        href="index.php"
        class="topbar-link"
        >
            Home
        </a>

        <?php if (($_SESSION['role'] ?? '') === 'agent'): ?><a href="agent-dashboard.php" class="topbar-link">My Listings</a><?php else: ?><a href="recommendations.php" class="topbar-link">Recommendations</a><?php endif; ?>

        <a
        href="profile.php"
        class="topbar-link"
        >
            My Profile
        </a>

        <a
        href="logout.php"
        class="topbar-link"
        >
            Logout
        </a>

    </nav>

</header>

<main class="page-body lifestyle-page">

    <section class="lifestyle-visual">

        <img
        src="images/lifestyle-art.png"
        alt="Riyadh lifestyle"
        >

        <div class="life-quote">

            <h3 dir="rtl">
                وش يقرّبك لجوّك؟
            </h3>

            <p dir="rtl">
                يومك وتفاصيله تقول كثير،
                ومنها نلقى لك الحي اللي يليق بك.
            </p>

        </div>

    </section>

    <section class="lifestyle-form-side">

        <div class="lifestyle-progress">

            <div class="progress-track">

                <div class="progress-step current">

                    <div class="step-circle">
                        1
                    </div>

                    <span>
                        Lifestyle
                    </span>

                </div>

                <div class="step-line"></div>

                <div class="progress-step">

                    <div class="step-circle">
                        2
                    </div>

                    <span>
                        Housing
                    </span>

                </div>

                <div class="step-line"></div>

                <div class="progress-step">

                    <div class="step-circle">
                        3
                    </div>

                    <span>
                        Complete
                    </span>

                </div>

            </div>

        </div>

        <section class="page-intro">

            <div class="section-label">

                <span></span>

                PERSONALIZATION

            </div>

            <h1>
                Lifestyle Preferences
            </h1>

            <p>
                Rate the services that matter to you to find neighborhoods in Riyadh.
            </p>

        </section>

        <?php if ($message): ?>

            <div class="notification success-message">

                <div class="notification-icon">
                    ✓
                </div>

                <div>

                    <strong>
                        Saved successfully
                    </strong>

                    <p>
                        <?php
                        echo htmlspecialchars(
                            $message,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </p>

                </div>

            </div>

        <?php endif; ?>

        <?php if ($error): ?>

            <div class="notification error-message">

                <div class="notification-icon">
                    !
                </div>

                <div>

                    <strong>
                        Check your information
                    </strong>

                    <p>
                        <?php
                        echo htmlspecialchars(
                            $error,
                            ENT_QUOTES,
                            'UTF-8'
                        );
                        ?>
                    </p>

                </div>

            </div>

        <?php endif; ?>

        <form
        method="POST"
        class="form-card"
        >

            <div class="form-card-header">

                <div>

                    <span class="form-number">
                        01
                    </span>

                    <h2>
                        Tell us about your lifestyle
                    </h2>

                </div>

                <p>
                    All fields marked with
                    <span>*</span>
                    are required.
                </p>

            </div>

            <!-- SERVICE IMPORTANCE RATINGS -->
            <div class="services-section">
                <div class="form-section-title"><span>1</span>Service Importance <em>*</em></div>
                <p class="services-lead">Rate each service from 0 (Not Required) to 5 (Very High).</p>
                <div class="service-ratings-list">
                    <?php
                    $rating_labels = ['Not Required', 'Very Low', 'Low', 'Moderate', 'High', 'Very High'];
                    
                    $service_icons = [
                        'Schools' => '<path d="m2 10 10-6 10 6-10 6-10-6Z"/><path d="M6 13v5c3 3 9 3 12 0v-5"/><path d="M22 10v7"/>',
                        'Healthcare' => '<rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 7v10M7 12h10"/>',
                        'Parks' => '<path d="m12 3-5 7h3l-5 7h14l-5-7h3l-5-7Z"/><path d="M12 17v5"/>',
                        'Supermarkets' => '<circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M2 3h2l2.4 12.1A2 2 0 0 0 8.4 17H20"/><path d="M5 7h17l-2 8H6"/>',
                        'Banks' => '<path d="M3 10 12 4l9 6"/><path d="M5 10v8M9.5 10v8M14.5 10v8M19 10v8"/><path d="M3 21h18"/>',
                        'Gas Stations' => '<path d="M5 21V5a2 2 0 0 1 2-2h6a2 2 0 0 1 2 2v16"/><path d="M4 21h12"/><path d="M8 8h4"/><path d="M15 10h2a2 2 0 0 1 2 2v5a1.5 1.5 0 0 0 3 0V9l-3-3"/>',
                    ];
                    foreach ($services as $service):
                        $key = 'service_' . strtolower(str_replace(' ', '_', $service));
                        $safe = htmlspecialchars($service, ENT_QUOTES, 'UTF-8');
                    ?>
                        <fieldset class="rating-row">
                            <legend class="rating-name">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><?php echo $service_icons[$service] ?? ''; ?></svg>
                                <?= htmlspecialchars($service, ENT_QUOTES, 'UTF-8') ?>
                            </legend>
                            <div class="rating-scale">
                                <?php foreach ($rating_labels as $rating => $label): ?>
                                    <input type="radio" id="<?php echo $key . '_' . $rating; ?>" name="service_importance[<?php echo $safe; ?>]" value="<?php echo $rating; ?>" data-label="<?php echo $label; ?>" <?php echo $service_ratings[$service] === $rating ? 'checked' : ''; ?> <?php echo $rating === 0 ? 'required' : ''; ?>>
                                    <label for="<?php echo $key . '_' . $rating; ?>" title="<?php echo $rating . ' – ' . $label; ?>"><?php echo $rating; ?></label>
                                <?php endforeach; ?>
                            </div>
                            <span class="rating-text"><?php echo $rating_labels[$service_ratings[$service]]; ?></span>
                        </fieldset>
                    <?php endforeach; ?>
                </div>
                <small class="service-rating-hint">At least one service must have a rating from 1 to 5.</small>
            </div>

            <p class="service-rating-hint">Your neighborhood recommendations are based on your service priorities. Your other lifestyle preferences are saved for future use.</p>

            <!-- Household details -->
            <div class="form-section-title"><span>1</span>About you</div>

            <div class="form-grid two-column">

                <div class="input-group">

                    <label for="income_level">

                        Income Level
                        <span>*</span>

                    </label>

                    <select
                    id="income_level"
                    name="income_level"
                    required
                    >

                        <option value="">
                            Select income level
                        </option>

                        <?php foreach ($income_options as $option): ?>

                            <option
                            value="<?php
                            echo htmlspecialchars(
                                $option,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            <?php
                            echo (
                                $form_income_level === $option
                            ) ? 'selected' : '';
                            ?>
                            >

                                <?php
                                echo htmlspecialchars(
                                    $option,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <div class="input-group">

                    <label for="family_size">

                        Family Size
                        <span>*</span>

                    </label>

                    <input
                    type="number"
                    id="family_size"
                    name="family_size"
                    min="1"
                    max="20"
                    placeholder="e.g. 4"
                    value="<?php
                    echo htmlspecialchars(
                        (string)$form_family_size,
                        ENT_QUOTES,
                        'UTF-8'
                    );
                    ?>"
                    required
                    >

                </div>

            </div>

            <!-- DAILY ROUTINE AND DESTINATIONS -->

            <div class="form-grid two-column routine-grid">

                <div class="input-group">

                    <label for="daily_routine">

                        Daily Routine
                        <span>*</span>

                    </label>

                    <select
                    id="daily_routine"
                    name="daily_routine"
                    required
                    >

                        <option value="">
                            Select your daily routine
                        </option>

                        <?php foreach ($routine_options as $option): ?>

                            <option
                            value="<?php
                            echo htmlspecialchars(
                                $option,
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>"
                            <?php
                            echo (
                                $form_daily_routine === $option
                            ) ? 'selected' : '';
                            ?>
                            >

                                <?php
                                echo htmlspecialchars(
                                    $option,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>

                            </option>

                        <?php endforeach; ?>

                    </select>

                </div>

                <!-- MULTIPLE IMPORTANT DESTINATIONS -->

                <div class="form-section-title destinations-title"><span>2</span>Places you visit regularly</div>
                <div class="input-group destinations-group">

                    <label>

                        Important Destinations
                        <span>*</span>

                    </label>

                    <div id="destinations-container">

                        <?php foreach (
                            $form_important_destinations
                            as $destination
                        ): ?>

                            <div class="destination-input-row">

                                <input
                                type="text"
                                name="important_destinations[]"
                                maxlength="255"
                                placeholder="e.g. King Saud University"
                                value="<?php
                                echo htmlspecialchars(
                                    $destination,
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>"
                                autocomplete="off"
                                required
                                >

                                <button
                                type="button"
                                class="remove-destination"
                                onclick="removeDestination(this)"
                                aria-label="Remove destination"
                                title="Remove destination"
                                >
                                    ×
                                </button>

                            </div>

                        <?php endforeach; ?>

                    </div>

                    <button
                    type="button"
                    id="add-destination"
                    class="add-destination-button"
                    >
                        + Add Another Destination
                    </button>

                    <small class="destination-hint">

                        Add your university, workplace, school,
                        hospital or another regular destination.

                        You can add up to 10 destinations.

                    </small>

                </div>

            </div>

            <!-- FORM ACTIONS -->

            <div class="form-actions">

                <a
                href="profile.php"
                class="button back-button"
                >
                    ← Back
                </a>

                <div class="primary-actions">

                    <?php if ($has_preferences): ?>

                        <button
                        type="submit"
                        name="action"
                        value="save"
                        class="button save-button"
                        >
                            Save Changes
                        </button>

                    <?php endif; ?>

                    <button
                    type="submit"
                    name="action"
                    value="continue"
                    class="button continue-button"
                    >
                        Continue →
                    </button>

                </div>

            </div>

        </form>

    </section>

</main>

<footer class="diyara-footer">

    <div class="footer-brand">

        <div class="footer-mark"></div>

        <div>

            <strong>Diyara</strong>

            <span>Live where you belong.</span>

        </div>

    </div>

    <div class="footer-center">

        <strong dir="rtl">
            ديارا | لكل طبعٍ حيّ
        </strong>

        <span>
            Riyadh · Heritage · Future
        </span>

    </div>

    <div class="footer-end">

        <span class="footer-line"></span>

        <p>
            Riyadh, Saudi Arabia
            <br>
            © 2026 Diyara
        </p>

    </div>

</footer>

<!-- =====================================================
     JAVASCRIPT: ADD / REMOVE DESTINATIONS
===================================================== -->

<script>

document.addEventListener('DOMContentLoaded', function () {

    const container =
        document.getElementById('destinations-container');

    const addButton =
        document.getElementById('add-destination');

    if (!container || !addButton) {
        return;
    }

    /* UPDATE BUTTON */

    function updateButton() {

        const rows =
            container.querySelectorAll(
                '.destination-input-row'
            );

        addButton.disabled = rows.length >= 10;

        addButton.textContent =
            rows.length >= 10
            ? 'Maximum 10 Destinations'
            : '+ Add Another Destination';

    }

    /* ADD DESTINATION */

    addButton.addEventListener('click', function () {

        const rows =
            container.querySelectorAll(
                '.destination-input-row'
            );

        if (rows.length >= 10) {

            alert('Maximum 10 destinations allowed.');

            return;
        }

        const newRow =
            document.createElement('div');

        newRow.className =
            'destination-input-row';

        const input =
            document.createElement('input');

        input.type = 'text';
        input.name = 'important_destinations[]';
        input.maxLength = 255;
        input.placeholder = 'Enter another destination';
        input.autocomplete = 'off';
        input.required = true;

        const removeButton =
            document.createElement('button');

        removeButton.type = 'button';
        removeButton.className = 'remove-destination';
        removeButton.textContent = '×';
        removeButton.setAttribute(
            'aria-label',
            'Remove destination'
        );

        removeButton.addEventListener(
            'click',
            function () {
                removeDestination(removeButton);
            }
        );

        newRow.appendChild(input);
        newRow.appendChild(removeButton);

        container.appendChild(newRow);

        input.focus();

        updateButton();

    });

    /* REMOVE DESTINATION */

    function removeDestination(button) {

        const rows =
            container.querySelectorAll(
                '.destination-input-row'
            );

        if (rows.length <= 1) {

            rows[0].querySelector('input').value = '';

            return;
        }

        button.closest(
            '.destination-input-row'
        ).remove();

        updateButton();

    }

    // Make function available for existing PHP-generated buttons
    window.removeDestination = removeDestination;

    /* INITIALIZE */

    updateButton();

});


document.querySelectorAll('.rating-row').forEach(function (row) {
    row.addEventListener('change', function (e) {
        var t = row.querySelector('.rating-text');
        if (t && e.target.dataset.label) { t.textContent = e.target.dataset.label; }
    });
});
</script>

</body>

</html>
