<?php

function diyara_neighborhood_photo(int $id): string
{
    $scene = (($id % 12 + 12) % 12) + 1;
    return sprintf('assets/district-scene-%02d.webp?v=20261120d', $scene);
}
