<?php
/** Diyara Sprint 2 — standalone neighborhood recommendations, powered by wsm.php. */
require_once __DIR__ . '/auth_check.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/wsm.php';
$userId = (int) ($_SESSION['user_id'] ?? 0);
if ($userId < 1) { header('Location: login.html'); exit; }
function nr_escape($value): string { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
$results = [];
$error = '';
try { $results = get_wsm_neighborhoods($pdo, $userId); }
catch (Throwable $e) { error_log('Diyara neighborhood WSM: ' . $e->getMessage()); $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to load neighborhood recommendations right now.'; }
$page_title = 'Neighborhood Recommendations';
$active = 'recommendations';
require __DIR__ . '/includes/header.php';
?>
<style>
/* Riyadh heritage editorial layout; WSM scores and source data unchanged */
.nr-wrap{--pine:#163b36;--terra:#b75c39;max-width:1450px;background:#fffaf5}
.nr-hero{border-radius:13px;min-height:270px}.nr-hero:after{background:linear-gradient(90deg,#102d2bcf 0%,#193b3888 43%,transparent 100%)}
.nr-copy{padding:32px 46px}.nr-grid{grid-template-columns:1fr;gap:15px}
.nr-card{display:grid;grid-template-columns:minmax(230px,29%) 1fr;min-height:245px;border-radius:13px;background:#fffdfb!important;box-shadow:0 5px 20px #48352516}
.nr-card-art,.nr-card:nth-child(n) .nr-card-art{height:100%;min-height:245px;background-position:center;background-size:cover}
.nr-card:nth-child(4n+1) .nr-card-art{background-image:url('assets/neighborhood-boulevard.jpg')}
.nr-card:nth-child(4n+2) .nr-card-art{background-image:url('assets/neighborhood-heritage.jpg')}
.nr-card:nth-child(4n+3) .nr-card-art{background-image:url('assets/neighborhood-courtyard.jpg')}
.nr-card:nth-child(4n) .nr-card-art{background-image:url('assets/neighborhood-park.jpg')}
.nr-body{padding:19px 25px!important}.nr-name{font-size:25px!important}.nr-compare-open{background:#a74d30!important}
.nr-tabs a[aria-current=page]{background:#a74d30!important}.nr-hero a{background:#ad5838!important}
.nr-card:hover{transform:translateY(-2px)}
@media(max-width:760px){.nr-card{display:block}.nr-card-art,.nr-card:nth-child(n) .nr-card-art{height:210px;min-height:210px}.nr-body{padding:20px!important}.nr-copy{padding:28px 23px}}

.nr-wrap{--pine:#153b35;--terra:#b65d39;--cream:#f8f5ef;max-width:1240px;margin:auto;padding:26px 24px 84px;color:var(--pine);font-family:'DM Sans',Arial,sans-serif}
.nr-tabs{display:flex;gap:5px;max-width:720px;margin:0 auto 24px;padding:5px;background:#f1ede5;border:1px solid #e4ded3;border-radius:15px}
.nr-tabs a{flex:1;text-align:center;padding:13px 12px;border-radius:11px;color:#4b625b;text-decoration:none;font-size:13px;font-weight:700;transition:.2s}
.nr-tabs a[aria-current=page]{background:var(--pine);color:#fff;box-shadow:0 4px 13px #153b3526}
.nr-tabs a:hover:not([aria-current=page]){background:#e7e0d5}
.nr-hero{position:relative;isolation:isolate;min-height:365px;border-radius:23px;overflow:hidden;display:flex;align-items:center;background:var(--pine);box-shadow:0 14px 34px #1c39301a}
.nr-hero:before{content:'';position:absolute;inset:0;background:url('assets/neighborhood-hero.jpg') center 50%/cover no-repeat;z-index:-2}
.nr-hero:after{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#102e2af2 0%,#123a35d9 32%,#123a3570 61%,#123a3508 100%);z-index:-1}
.nr-copy{max-width:670px;padding:43px 53px;color:#fff}
.nr-eyebrow{font-size:11px;letter-spacing:2.1px;color:#f0c9a5;font-weight:800}
.nr-hero h1{font:600 clamp(33px,3.7vw,49px)/1.14 'Playfair Display',Georgia,serif;color:#fff;margin:13px 0 15px;text-shadow:0 2px 10px #0003}
.nr-hero p{color:#f7f4ed;font-size:15px;line-height:1.8;max-width:500px;margin:0}
.nr-hero a{display:inline-flex;align-items:center;gap:8px;margin-top:24px;background:#bc623d;color:#fff;text-decoration:none;padding:13px 20px;border-radius:11px;font-weight:750;font-size:13px;box-shadow:0 5px 15px #0002}
.nr-hero a:hover{background:#a95132}
.nr-heading{margin:39px 0 0;padding-left:16px;border-left:4px solid var(--terra);position:relative}.nr-heading:after{content:'✧';position:absolute;right:8px;top:-7px;color:#c27a59;font-size:30px;opacity:.65}
.nr-section-title{font:600 29px/1.2 'Playfair Display',Georgia,serif;margin:0 0 6px;color:var(--pine)}
.nr-subtitle{font-size:13px;color:#738078;margin:0}
.nr-toolbar{display:flex;align-items:center;justify-content:space-between;gap:14px;flex-wrap:wrap;margin:23px 0 20px}
.nr-search{border:1px solid #dcdcd4;background:#fff;border-radius:12px;padding:13px 17px;font:inherit;min-width:240px;width:min(100%,420px);outline-color:#b65d39}
.nr-count{font-size:12px;color:#6d7a75}
.nr-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:22px}
.nr-card{background:linear-gradient(155deg,#fffdfa 0%,#faf4ec 100%);border:1px solid #e6e3da;border-radius:19px;overflow:hidden;box-shadow:0 6px 20px #173c3212;transition:transform .2s,box-shadow .2s}
.nr-card:hover{transform:translateY(-4px);box-shadow:0 13px 32px #173c3220}.nr-card:nth-child(3n+2){border-color:#d8c9b9}.nr-card:nth-child(3n){border-color:#d8d5e2}
.nr-card-art{height:208px;background:#d6c2a6 url('assets/neighborhood-boulevard.jpg') center 48%/cover no-repeat;display:flex;align-items:flex-start;justify-content:space-between;padding:15px;gap:8px;position:relative}
.nr-card:nth-child(3n+2) .nr-card-art{background-image:url('assets/neighborhood-courtyard.jpg');background-position:center 53%}
.nr-card:nth-child(3n) .nr-card-art{background-image:url('assets/neighborhood-park.jpg');background-position:center 48%}
.nr-card:nth-child(4n) .nr-card-art{background-image:url('assets/neighborhood-heritage.jpg');background-position:center 50%}
.nr-card-art:after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#0007 0%,transparent 70%);pointer-events:none}
.nr-rank,.nr-level{position:relative;z-index:1;font-size:10px;font-weight:800;letter-spacing:.35px;border-radius:30px;padding:8px 11px;white-space:nowrap}
.nr-rank{color:#fff;background:#123a34e8}.nr-level{color:#173d35;background:#f6e2c9ed}
.nr-body{padding:21px 22px 23px}
.nr-name{font:600 23px/1.25 'Playfair Display',Georgia,serif;color:#183c36;margin:0 0 4px;overflow-wrap:anywhere}
.nr-ar{font-family:'IBM Plex Sans Arabic',sans-serif;color:#7c877e;font-size:12px;min-height:20px}
.nr-score-row{display:flex;justify-content:space-between;align-items:baseline;margin-top:17px;gap:8px}
.nr-score{font-size:30px;font-weight:800;letter-spacing:-1px;color:#17473e}.nr-score small{font-size:12px;font-weight:500;color:#859088;letter-spacing:0}
.nr-score-label{font-size:11px;color:#78857e;text-align:right}
.nr-track{height:7px;background:#eae9e2;border-radius:20px;margin:9px 0 16px;overflow:hidden}.nr-fill{height:100%;border-radius:20px;background:#246b58}
.nr-detail{border-top:1px solid #ebe8e0;padding-top:14px}.nr-detail summary{cursor:pointer;color:#265d4d;font-size:13px;font-weight:750;list-style-position:inside}
.nr-contrib{margin-top:14px;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
.nr-line{display:flex;flex-direction:column;gap:3px;background:linear-gradient(135deg,#f5eee5,#edf2eb);padding:9px 11px;border-radius:9px;font-size:11px;color:#64746d}
.nr-line strong{font-size:13px;font-weight:750;color:#294c44}
.nr-properties-link{display:inline-flex;margin-top:16px;color:#fff!important;background:#193e37;padding:11px 15px;border-radius:10px;font-size:12px;font-weight:750;text-decoration:none}.nr-properties-link:hover{background:#315b4e}.nr-empty{background:#fff;border-radius:15px;padding:30px}.nr-footnote{margin:30px 0;color:#7d8982;font-size:12px;line-height:1.8}
@media(max-width:950px){.nr-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.nr-copy{padding:38px 35px}}
@media(max-width:620px){.nr-wrap{padding:18px 14px 55px}.nr-grid{grid-template-columns:1fr}.nr-hero{min-height:330px}.nr-hero:after{background:linear-gradient(90deg,#103b34fa 0%,#103b34e9 63%,#103b3466 100%)}.nr-copy{padding:30px 24px}.nr-hero h1{font-size:34px}.nr-tabs{width:100%}.nr-tabs a{padding:11px 8px;font-size:11px}.nr-section-title{font-size:27px}.nr-card-art{height:170px}}
/* Riyadh-inspired elevated finish */
.nr-wrap{background:linear-gradient(155deg,#f8f8f4 0%,#f1f1ed 55%,#f8f4f2 100%)}
.nr-hero{min-height:385px;box-shadow:0 20px 48px #153a352b}
.nr-hero:after{background:linear-gradient(90deg,#092e2bf5 0%,#153e38e3 38%,#153e3866 70%,transparent 100%)}
.nr-card{background:#fff;border:1px solid #dce3da;box-shadow:0 9px 27px #183a3218}
.nr-card-art{height:232px}.nr-card:nth-child(3n+2){border-color:#e1d2c3}.nr-card:nth-child(3n){border-color:#ddceba}
.nr-hero a{background:#eee0cf;color:#173c34}.nr-hero a:hover{background:#fff}
.nr-compare-select{display:flex;align-items:center;gap:8px;font-size:12px;font-weight:700;color:#80533c;margin-bottom:14px;cursor:pointer}
.nr-compare-select input{accent-color:#1d5549;width:17px;height:17px}
.nr-compare-open{display:inline-block;padding:12px 17px;background:#193e37;color:#fff!important;border-radius:11px;text-decoration:none;font-weight:700;font-size:12px}
.nr-compare-open:hover{background:#315b4e}.nr-toolbar{justify-content:flex-start}.nr-count{margin-left:auto}
@media(max-width:620px){.nr-count{margin-left:0;width:100%}.nr-card-art{height:205px}}
/* Final polish: cohesive green, ivory and muted mauve with vivid imagery */
.nr-wrap{background:linear-gradient(135deg,#f5f8f3 0%,#fbf6f0 50%,#f5f1f7 100%)}
.nr-card{box-shadow:0 12px 30px #1a3b3215}
.nr-card:hover{transform:translateY(-5px);box-shadow:0 20px 40px #1a3b3224}
.nr-tabs a:hover{background:#e4ece4;color:#173c34}
.nr-properties-link:focus-visible,.nr-tabs a:focus-visible{outline:3px solid #b17b9b;outline-offset:3px}

/* Final neighborhood visual system: refined editorial horizontal layout */
.nr-wrap{--pine:#163b35;--terra:#b76b46;background:#faf8f4!important;max-width:1500px!important}
.nr-hero{min-height:285px!important;border-radius:16px!important}.nr-hero:after{background:linear-gradient(90deg,#102c29ef,#102c29a8 38%,transparent 78%)!important}
.nr-tabs{max-width:800px}.nr-tabs a[aria-current=page]{background:#a95737!important}
.nr-grid{grid-template-columns:1fr!important;gap:15px!important}
.nr-card{display:grid!important;grid-template-columns:minmax(235px,28%) minmax(0,1fr);min-height:225px!important;border:1px solid #e4d9d0!important;border-radius:17px!important;background:#fffdfb!important;box-shadow:0 6px 24px #332a2311!important}
.nr-card-art{height:100%!important;min-height:225px!important;border-radius:0}.nr-body{padding:19px 27px!important;display:grid;align-content:center}
.nr-name{font-size:25px!important}.nr-score-row{margin-top:8px}.nr-score{font-size:25px}.nr-track{margin:7px 0 10px}.nr-contrib{display:flex;flex-wrap:wrap;gap:7px;margin-top:8px}.nr-line{padding:7px 10px;min-width:110px;background:#f8efe8;border:1px solid #f0e3d9}.nr-line strong{font-size:12px}
.nr-detail{border-top:1px solid #f0e7e0;padding-top:8px}.nr-properties-link{margin-top:12px;background:#173e36!important}.nr-compare-open{background:#a95737!important}.nr-compare-check{accent-color:#a95737!important}
.nr-selection-bar{position:sticky;bottom:12px;z-index:20;display:flex;align-items:center;gap:16px;flex-wrap:wrap;margin-top:18px;padding:13px 16px;background:#fffaf5;border:1px solid #dfcbbd;border-radius:13px;box-shadow:0 8px 30px #28180c22;font-size:13px}.nr-selection-bar strong{background:#173e36;color:#fff;padding:12px 14px;border-radius:9px}.nr-selection-bar #nrSelectedNames{flex:1;color:#654f45}.nr-selection-bar a{background:#a95737;color:#fff;padding:12px 19px;border-radius:9px;text-decoration:none;font-weight:700}
@media(max-width:780px){.nr-card{grid-template-columns:1fr!important}.nr-card-art{height:210px!important;min-height:210px!important}.nr-body{padding:19px!important}.nr-selection-bar{position:static}.nr-selection-bar a{width:100%;text-align:center}}
/* Final design: warm mineral tones, copper accents, green reserved for contrast */
.nr-wrap{--pine:#263d3b;--terra:#a85e3f;background:#f9f6f1!important}
.nr-tabs a[aria-current=page],.nr-compare-open,.nr-selection-bar a{background:#995337!important}
.nr-hero{border:1px solid #dcc8b5!important}
.nr-card{border-color:#e8d8c8!important;box-shadow:0 8px 22px #60452b16!important}
.nr-line{background:#f6ede3!important}.nr-level{background:#fff6e9!important;color:#74452e!important}
.nr-selection-bar a[aria-disabled=true]{opacity:.55;cursor:not-allowed}
@media(max-width:780px){.nr-selection-bar{position:static!important}}

/* DIYARA FINAL VISUAL SYSTEM: heritage clay + contemporary charcoal, restrained accents */
.pr-wrap,.nr-wrap{--ink:#292f35!important;--pine:#303b40!important;--terra:#bb6847!important;--rust:#bb6847!important;--mauve:#91766e!important;background:linear-gradient(145deg,#f8f7f4,#f5f0e9 58%,#f8f7f4)!important;color:#292f35!important}
.pr-tabs,.nr-tabs{background:#f2e9df!important;border-color:#e8d7c8!important}
.pr-tabs a[aria-current=page],.nr-tabs a[aria-current=page]{background:#34464a!important;color:#fff!important}
.pr-hero:before{background:linear-gradient(90deg,#27353bed 0%,#354149cc 44%,#35414910 100%),url('assets/property-hero.jpg') center/cover!important}
.nr-hero:after{background:linear-gradient(90deg,#27353bef 0%,#354149d0 42%,#35414910 100%)!important}
.pr-card,.nr-card{background:#fffdfa!important;border:1px solid #e9dfd4!important;box-shadow:0 10px 32px #34302b16!important}
.pr-card:hover,.nr-card:hover{box-shadow:0 18px 40px #34302b22!important}
.pr-details,.nr-properties-link{background:#34464a!important;color:white!important}
.pr-compare-toolbar,.nr-selection-bar{background:#f8eee6!important;border-color:#e6d2c2!important}
.pr-compare-toolbar button:not(:disabled),.nr-compare-open,.nr-selection-bar a{background:#ae6146!important;color:#fff!important}
.pr-compare-label input,.nr-compare-check,.nr-compare-select input{accent-color:#ae6146!important}
.pr-rank,.nr-rank{background:#34464aee!important}
.pr-price,.nr-score,.nr-name,.nr-section-title{color:#303a3d!important}
.pr-hero,.nr-hero{border-radius:19px!important}
.pr-photo{background-position:center!important}
@media(max-width:720px){.pr-wrap,.nr-wrap{padding-left:13px!important;padding-right:13px!important}}


/* FINAL DIYARA VISUAL SYSTEM — heritage x contemporary Riyadh */
.pr-wrap,.nr-wrap{--pine:#183b36;--terra:#b66a4a;--cream:#fff9f3;background:#fff9f3!important;color:#243d3a!important;max-width:1480px!important}
.pr-hero,.nr-hero{border-radius:18px!important;min-height:270px!important;box-shadow:0 14px 32px #392a1f19!important}
.pr-hero:before{background:linear-gradient(90deg,#142d2bf2 0%,#193c38d9 31%,#183d3960 58%,#183d3905 100%),url('assets/property-hero.jpg') center/cover!important}
.nr-hero:after{background:linear-gradient(90deg,#142d2bf0 0%,#193c38d9 32%,#183d3960 60%,transparent 100%)!important}
.pr-tabs,.nr-tabs{margin:0 0 20px!important;max-width:850px!important;background:#f3e7dc!important;border-color:#e5d3c4!important}
.pr-tabs a[aria-current=page],.nr-tabs a[aria-current=page]{background:#1d4a42!important;color:#fff!important}
.pr-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:18px!important}
.pr-card,.nr-card{background:#fffdfb!important;border:1px solid #eadbd0!important;border-radius:17px!important;box-shadow:0 7px 25px #49342613!important}
.pr-photo{height:245px!important;background-size:cover!important}
.nr-grid{display:grid!important;grid-template-columns:1fr!important;gap:14px!important}
.nr-card{display:grid!important;grid-template-columns:minmax(235px,29%) minmax(0,1fr)!important;min-height:240px!important}
.nr-card-art{height:100%!important;min-height:240px!important;background-size:cover!important}
.nr-body{padding:20px 25px!important}
.nr-name,.nr-score,.pr-price{color:#203f39!important}
.pr-details,.nr-properties-link,.pr-compare-toolbar button:not(:disabled),.nr-compare-open,.nr-selection-bar a{background:#1d4a42!important;color:white!important}
.pr-rank,.nr-rank{background:#173d36ee!important}
.pr-compare-toolbar,.nr-selection-bar{background:#f5e8de!important;border-color:#e6cdbb!important}
.pr-compare-label input,.nr-compare-check,.nr-compare-select input{accent-color:#b66a4a!important}
.pr-card:hover,.nr-card:hover{transform:translateY(-3px)!important;box-shadow:0 12px 28px #44312220!important}
@media(max-width:1000px){.pr-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.nr-card{grid-template-columns:minmax(200px,34%) minmax(0,1fr)!important}}
@media(max-width:700px){.pr-grid{grid-template-columns:1fr!important}.nr-card{display:block!important}.nr-card-art{height:215px!important;min-height:215px!important}.pr-hero,.nr-hero{min-height:290px!important}}


/* Compact, calmer neighborhood discovery */.nr-wrap{max-width:1330px!important;padding:18px 25px 65px!important}.nr-hero{min-height:195px!important;border-radius:15px!important}.nr-copy{padding:23px 32px!important}.nr-hero h1{font-size:clamp(27px,3vw,37px)!important;margin:8px 0!important}.nr-hero p{font-size:13px!important;line-height:1.5!important}.nr-hero a{margin-top:12px!important;padding:9px 14px!important}.nr-heading{margin:19px 0 12px!important}.nr-section-title{font-size:25px!important}.nr-grid{gap:13px!important}.nr-card{border-radius:13px!important}.nr-card-art{min-height:180px!important}.nr-body{padding:15px 18px!important}.nr-name{font-size:20px!important}.nr-hero:after{background:linear-gradient(90deg,#233e43ef 0%,#233e43c9 35%,transparent 88%)!important}@media(max-width:700px){.nr-hero{min-height:220px!important}.nr-wrap{padding:14px!important}}
.nr-selection-bar{z-index:999!important;position:sticky!important;bottom:8px!important}
.nr-selection-bar button{background:#1d4a42;color:#fff;border:0;border-radius:9px;padding:12px 19px;font:700 13px inherit;cursor:pointer;white-space:nowrap}
.nr-selection-bar button:disabled{opacity:.5;cursor:not-allowed}
.nr-selection-bar button:not(:disabled):hover{background:#306459}
</style>
<section class="nr-wrap">
  <nav class="nr-tabs" aria-label="Recommendation types">
    <a href="recommendations.php">Property Recommendations</a>
    <a href="neighborhood-recommendations.php" aria-current="page">Neighborhood Recommendations</a>
  </nav>
  <div class="nr-hero"><div class="nr-copy">
    <span class="nr-eyebrow">DIYARA &middot; FIND YOUR PLACE</span>
    <h1>Neighborhood Recommendations</h1>
    <p>Discover Riyadh neighborhoods that best match the services you care about. Explore your top matches and see what each area offers.</p>
    <a href="lifestyle-preferences.php">Adjust my priorities &rarr;</a>
  </div></div>
  <div class="nr-heading"><h2 class="nr-section-title">Recommended for you</h2>
  <p class="nr-subtitle">Explore neighborhoods ranked by how well they match your priorities.</p></div>
  <?php if ($error !== ''): ?>
    <div class="nr-empty"><strong>Recommendations unavailable</strong><p><?= nr_escape($error) ?></p><a class="nr-btn" href="lifestyle-preferences.php">Open Lifestyle Preferences</a></div>
  <?php elseif (!$results): ?>
    <div class="nr-empty">No neighborhoods are available in the database.</div>
  <?php else: ?>
    <div class="nr-toolbar">
      <input class="nr-search" id="nrSearch" type="search" placeholder="Search for a neighborhood..." aria-label="Search neighborhoods">
      <a class="nr-compare-open" id="nrCompareOpen" href="compare.php" aria-label="Compare neighborhoods">Compare neighborhoods <span id="nrCompareCount">(0/2)</span></a><span class="nr-count" id="nrCount"><?= count($results) ?> neighborhoods &middot; Ranked by suitability</span>
    </div>
    <div class="nr-grid" id="nrGrid">
    <?php foreach ($results as $item):
      $name = trim((string)($item['name_en'] ?? '')) ?: (string)($item['name_ar'] ?? 'Neighborhood');
      $score = (float)$item['suitability_score'];
      $level = (string)$item['suitability_level'];
    ?>
      <article class="nr-card" data-search="<?= nr_escape(mb_strtolower($name . ' ' . ($item['name_ar'] ?? ''), 'UTF-8')) ?>">
        <div class="nr-card-art"><span class="nr-rank">#<?= (int)$item['rank'] ?> MATCH</span><span class="nr-level"><?= nr_escape($level) ?> match</span></div>
        <div class="nr-body"><label class="nr-compare-select"><input type="checkbox" class="nr-compare-check" value="<?= (int)$item['neighborhood_id'] ?>"> Compare this neighborhood</label><h3 class="nr-name"><?= nr_escape($name) ?></h3>
        <?php if (!empty($item['name_ar'])): ?><div class="nr-ar" lang="ar" dir="rtl"><?= nr_escape($item['name_ar']) ?></div><?php endif; ?>
        <div class="nr-score-row"><div class="nr-score"><?= number_format($score, 1) ?> <small>/ 100</small></div><span class="nr-score-label">Neighborhood suitability</span></div>
        <div class="nr-track" aria-hidden="true"><div class="nr-fill" style="width:<?= min(100,max(0,$score)) ?>%"></div></div>
        <div class="nr-detail"><div class="nr-contrib">
        <?php foreach ($item['service_contributions'] as $service => $details): ?>
          <div class="nr-line"><span><?= nr_escape($service) ?></span><strong><?= number_format((float)$details['count'],0) ?> available</strong></div>
        <?php endforeach; ?>
        </div></div><a class="nr-properties-link" href="recommendations.php?neighborhood_id=<?= (int)$item['neighborhood_id'] ?>">Explore properties in this neighborhood &rarr;</a></div>
      </article>
    <?php endforeach; ?>
    </div>

    <div class="nr-selection-bar" id="nrSelectionBar" aria-live="polite"><strong>Compare selected neighborhoods <span id="nrBarCount">(0/2)</span></strong><span id="nrSelectedNames">Choose two neighborhoods</span><form id="nrCompareForm" action="compare.php" method="get" style="display:inline-flex;margin:0"><input type="hidden" name="a" id="nrFormA" value=""><input type="hidden" name="b" id="nrFormB" value=""><button type="submit" id="nrBarGo" disabled>Compare Now →</button></form></div>
  <?php endif; ?>
</section>
<script>
(function () {
  'use strict';
  const checks = Array.from(document.querySelectorAll('.nr-compare-check'));
  const topLink = document.getElementById('nrCompareOpen');
  const form = document.getElementById('nrCompareForm');
  const submit = document.getElementById('nrBarGo');
  const formA = document.getElementById('nrFormA');
  const formB = document.getElementById('nrFormB');
  const countTop = document.getElementById('nrCompareCount');
  const countBottom = document.getElementById('nrBarCount');
  const names = document.getElementById('nrSelectedNames');
  const chosen = () => checks.filter(c => c.checked);
  function update() {
    const selected = chosen();
    const valid = selected.length === 2 && selected[0].value !== selected[1].value;
    if (countTop) countTop.textContent = '(' + selected.length + '/2)';
    if (countBottom) countBottom.textContent = '(' + selected.length + '/2)';
    if (names) names.textContent = selected.map(c => c.closest('.nr-card')?.querySelector('.nr-name')?.textContent.trim() || c.value).join(' · ') || 'Choose two neighborhoods';
    if (formA) formA.value = valid ? selected[0].value : '';
    if (formB) formB.value = valid ? selected[1].value : '';
    if (submit) submit.disabled = !valid;
    if (topLink) {
      topLink.href = valid ? 'compare.php?a=' + encodeURIComponent(selected[0].value) + '&b=' + encodeURIComponent(selected[1].value) : '#nrSelectionBar';
      topLink.setAttribute('aria-disabled', String(!valid));
    }
  }
  checks.forEach(c => c.addEventListener('change', () => {
    if (chosen().length > 2) { c.checked = false; alert('Choose only two neighborhoods.'); }
    update();
  }));
  form?.addEventListener('submit', e => {
    update();
    if (chosen().length !== 2 || !formA.value || !formB.value) { e.preventDefault(); alert('Select two different neighborhoods.'); }
  });
  topLink?.addEventListener('click', e => { if (chosen().length !== 2) { e.preventDefault(); alert('Select two different neighborhoods.'); } });
  const search = document.getElementById('nrSearch');
  const cards = Array.from(document.querySelectorAll('.nr-card'));
  const count = document.getElementById('nrCount');
  search?.addEventListener('input', () => {
    const term = search.value.toLocaleLowerCase().trim();
    let shown = 0;
    cards.forEach(card => { const visible = (card.dataset.search || '').includes(term); card.hidden = !visible; card.style.display = visible ? '' : 'none'; if (visible) shown++; });
    if (count) count.textContent = shown + ' of ' + cards.length + ' neighborhoods';
  });
  update();
})();
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
