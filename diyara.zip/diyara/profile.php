<?php

require 'auth_check.php';
require 'db.php';

$user_id = $_SESSION['user_id'];


/* =========================================================
USER
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        name,
        email,
        role
    FROM users
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user) {
    header('Location: logout.php');
    exit;
}


/* =========================================================
LIFESTYLE
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        income_level,
        family_size,
        daily_routine,
        important_destination,
        required_services
    FROM lifestyle_preferences
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$lifestyle = $stmt->fetch(PDO::FETCH_ASSOC);


/* =========================================================
HOUSING
========================================================= */

$stmt = $pdo->prepare("
    SELECT
        budget,
        property_type,
        preferred_size,
        bedrooms,
        preferred_location
    FROM housing_preferences
    WHERE user_id = ?
");

$stmt->execute([$user_id]);

$housing = $stmt->fetch(PDO::FETCH_ASSOC);


/* =========================================================
SERVICES
========================================================= */

$required_services = [];

if (
    $lifestyle &&
    !empty($lifestyle['required_services'])
) {
    $required_services = json_decode(
        $lifestyle['required_services'],
        true
    ) ?? [];

    if (!is_array($required_services)) {
        $required_services = [];
    }
}


/* =========================================================
HELPER
========================================================= */

function displayValue($value)
{
    if ($value === null || $value === '') {
        return 'Not set yet';
    }

    return htmlspecialchars(
        (string)$value,
        ENT_QUOTES,
        'UTF-8'
    );
}


/* =========================================================
NEIGHBORHOOD DISPLAY
========================================================= */

$display_neighborhood = '';

if ($housing && !empty($housing['preferred_location'])) {
    $display_neighborhood = $housing['preferred_location'];
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    >

    <title>My Profile | Diyara</title>

    <link
        href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap"
        rel="stylesheet"
    >

    <link
        rel="stylesheet"
        href="diyara.css?v=71"
    >
</head>

<body class="page-profile">

<header class="site-topbar">

    <div class="topbar-brand">
        <div class="topbar-logo-slot"></div>

        <div class="topbar-brand-text">
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>
    </div>

    <nav class="topbar-nav">
        <a href="index.php" class="topbar-link">Home</a>

        <a href="recommendations.php" class="topbar-link">
            Recommendations
        </a>

        <a href="profile.php" class="topbar-link active">
            My Profile
        </a>

        <a href="logout.php" class="topbar-link">Logout</a>
    </nav>

</header>


<main class="page-body profile-page">

    <div class="profile-top">

        <section class="profile-title">

            <div class="section-label">
                <span></span>
                MY DIYARA
            </div>

            <h1>My Profile</h1>

            <p>
                Your personal space for managing account details,
                lifestyle priorities and housing preferences.
            </p>

            <a href="edit-profile.php" class="primary-edit-button">
                Edit Profile
            </a>

        </section>


        <section class="profile-mini-hero">

            <img
                src="images/profile-art.png"
                alt="Riyadh"
            >

            <div class="profile-mini-text">

                <h3 dir="rtl">كل شي بمكانه.</h3>

                <p dir="rtl">
                    بياناتك وتفضيلاتك مرتبة،
                    عشان تجربتك تكون أوضح.
                </p>

            </div>

        </section>

    </div>


    <section class="profile-card personal-card">

        <div class="card-heading">
            <div>
                <span class="card-number">01</span>
                <h2>Personal Information</h2>
            </div>
        </div>

        <div class="personal-grid">

            <div class="info-item">
                <span class="info-label">Full Name</span>

                <strong class="info-value">
                    <?php echo displayValue($user['name']); ?>
                </strong>
            </div>

            <div class="info-item">
                <span class="info-label">Email Address</span>

                <strong class="info-value">
                    <?php echo displayValue($user['email']); ?>
                </strong>
            </div>

        </div>

    </section>


    <section class="preferences-title">

        <div class="section-label">
            <span></span>
            SAVED PREFERENCES
        </div>

        <h2>Your Preferences</h2>

        <p>
            These preferences help Diyara understand
            the neighborhoods and homes that fit you best.
        </p>

    </section>


    <div class="preferences-grid">


        <!-- LIFESTYLE PREFERENCES -->

        <section class="profile-card preference-card">

            <div class="preference-header">

                <div>
                    <span class="card-number">02</span>
                    <h3>Lifestyle Preferences</h3>
                </div>

                <a href="lifestyle-preferences.php" class="edit-small">
                    Edit
                </a>

            </div>


            <?php if ($lifestyle): ?>

                <div class="preference-list">

                    <div class="preference-row">
                        <span>Income Level</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $lifestyle['income_level']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Family Size</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $lifestyle['family_size']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Daily Routine</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $lifestyle['daily_routine']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Important Destination</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $lifestyle['important_destination']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="services-preview">

                        <span class="preference-label">
                            Required Services
                        </span>

                        <div class="service-tags">

                            <?php if (!empty($required_services)): ?>

                                <?php foreach ($required_services as $service): ?>

                                    <span class="service-tag">
                                        <?php
                                        echo htmlspecialchars(
                                            (string)$service,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </span>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <span>Not set yet</span>

                            <?php endif; ?>

                        </div>

                    </div>

                </div>

            <?php else: ?>

                <div class="empty-state">

                    <h4>
                        Lifestyle preferences not added yet
                    </h4>

                    <a href="lifestyle-preferences.php">
                        Add Preferences
                    </a>

                </div>

            <?php endif; ?>

        </section>


        <!-- HOUSING PREFERENCES -->

        <section class="profile-card preference-card">

            <div class="preference-header">

                <div>
                    <span class="card-number">03</span>
                    <h3>Housing Preferences</h3>
                </div>

                <a href="housing-preferences.php" class="edit-small">
                    Edit
                </a>

            </div>


            <?php if ($housing): ?>

                <div class="preference-list">

                    <div class="preference-row">
                        <span>Budget</span>

                        <strong>
                            <?php
                            echo number_format(
                                (float)$housing['budget']
                            );
                            ?>
                            SAR
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Property Type</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $housing['property_type']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Preferred Size</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $housing['preferred_size']
                            );
                            ?>
                            m²
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Bedrooms</span>

                        <strong>
                            <?php
                            echo displayValue(
                                $housing['bedrooms']
                            );
                            ?>
                        </strong>
                    </div>


                    <div class="preference-row">
                        <span>Preferred Neighborhood</span>

                        <strong dir="rtl">
                            <?php
                            echo displayValue(
                                $display_neighborhood
                            );
                            ?>
                        </strong>
                    </div>

                </div>

            <?php else: ?>

                <div class="empty-state">

                    <h4>
                        Housing preferences not added yet
                    </h4>

                    <a href="housing-preferences.php">
                        Add Preferences
                    </a>

                </div>

            <?php endif; ?>

        </section>

    </div>

</main>


<footer class="diyara-footer">

    <div class="footer-brand">

        <div class="footer-mark"></div>

        <div>
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>

    </div>


    <div class="footer-center">

        <strong dir="rtl">
            ديارٍ تشبهك، وحيٍّ يناسبك.
        </strong>

        <span>Riyadh · Heritage · Future</span>

    </div>


    <div class="footer-end">

        <span class="footer-line"></span>

        <p>
            Riyadh, Saudi Arabia
            <br>
            © 2026 Diyara
        </p>

    </div>

</footer>

</body>
</html>