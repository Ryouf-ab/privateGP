<?php
// PERSON 2 owns this page (Profile + Preferences).
require 'auth_check.php';   // keeps it login-only
require 'db.php';           // $pdo is ready to use
$page_title = 'My Profile';
$active = 'profile';
require 'includes/header.php';
?>
<section class="page">
  <div class="container">
    <h1>My Profile</h1>
    <div class="card">
      <p><strong>Name:</strong> <?php echo htmlspecialchars($_SESSION['name']); ?></p>
      <p><strong>Account type:</strong> <?php echo htmlspecialchars($_SESSION['role']); ?></p>
      <!-- PERSON 2: add the Update Profile form and the Preferences form here.
           Use $_SESSION['user_id'] to know who the user is. -->
    </div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
