<?php
require_once __DIR__ . "/includes/neighborhood-name.php";
require 'auth_check.php';
require 'db.php';
require 'filter.php';
require_once 'housing-discovery.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) { header('Location: login.html'); exit; }
function pc_e($value) { return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8'); }
// Property IDs are VARCHAR(20), e.g. A877409248; never cast them to integers.
$a = trim((string) ($_GET['a'] ?? ''));
$b = trim((string) ($_GET['b'] ?? ''));
$validId = static function ($id) { return $id !== '' && strlen($id) <= 20 && preg_match('/^[A-Za-z0-9_-]+$/D', $id); };
$chosen = [];
$housing = null;
$error = '';
if (!$validId($a) || !$validId($b) || $a === $b) {
    $error = 'Select two different properties from Property Recommendations.';
} else {
    try {
        // Fetch the exact selected IDs. Do not infer selection from page position.
        $stmt = $pdo->prepare('SELECT p.*, n.name_en, n.name_ar, n.neighborhood_id FROM properties p LEFT JOIN neighborhoods n ON n.neighborhood_id = p.neighborhood_id WHERE p.property_id IN (?, ?)');
        $stmt->execute([$a, $b]);
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $id = (string)$row['property_id'];
            $chosen[$id] = ['property'=>$row, 'neighborhood'=>['name_en'=>$row['name_en']??'', 'name_ar'=>$row['name_ar']??'', 'neighborhood_id'=>$row['neighborhood_id']??null]];
        }
        if (count($chosen) !== 2) {
            $error = 'One or both selected properties could not be found.';
        } else {
            // Preserve the original rule-based property match scores where available.
            try {
                $pref = $pdo->prepare('SELECT budget, property_type, preferred_size, bedrooms FROM housing_preferences WHERE user_id = ? LIMIT 1');
                $pref->execute([$userId]);
                $housing = $pref->fetch(PDO::FETCH_ASSOC);
                if ($housing) foreach (get_candidate_neighborhoods($pdo, $housing) as $group) {
                    foreach ($group['properties'] as $candidate) {
                        $id = (string)$candidate['property_id'];
                        if (isset($chosen[$id])) $chosen[$id]['property']['match_score'] = $candidate['match_score'] ?? null;
                    }
                }
            } catch (Throwable $ignored) { $housing = null; error_log('DIYARA compare score lookup: '.$ignored->getMessage()); }
        }
    } catch (Throwable $e) {
        error_log('DIYARA property compare: '.$e->getMessage());
        $error = 'We could not open this comparison right now. Please try again.';
    }
}
$page_title = 'Compare Properties';
$active = 'recommendations';
require 'includes/header.php';
$items = $error ? [] : [$chosen[$a], $chosen[$b]];
require_once __DIR__ . '/property_images_lib.php';
require_once __DIR__ . '/property_fallback_photos.php';
$pcUploaded = $items ? property_images_for($pdo, array_map(static fn($item) => $item['property']['property_id'], $items)) : [];
$rows = [
    ['label'=>'Neighborhood','key'=>'neighborhood'],
    ['label'=>'Property type','key'=>'property_type'],
    ['label'=>'Price (SAR)','key'=>'price'],
    ['label'=>'Area (m²)','key'=>'area_m2'],
    ['label'=>'Bedrooms','key'=>'bedrooms'],
    ['label'=>'Bathrooms','key'=>'bathrooms'],
    ['label'=>'Property match score','key'=>'match_score'],
];
?>
<style>
.pc-wrap{max-width:1120px;margin:auto;padding:40px 24px 90px;color:#173d35;font-family:'DM Sans',Arial,sans-serif}
.pc-wrap h1{font:600 clamp(30px,4vw,48px) 'Playfair Display',Georgia,serif;margin:12px 0}
.pc-sub{color:#63786c;line-height:1.7;margin-bottom:30px}
.pc-back{color:#1c5948;text-decoration:none;font-weight:700}
.pc-table{width:100%;border-collapse:separate;border-spacing:0;overflow:hidden;border:1px solid #dce4dc;border-radius:14px;background:#fff;box-shadow:0 15px 35px #143b3210}
.pc-table th,.pc-table td{text-align:left;padding:19px 22px;border-bottom:1px solid #e8ede7;vertical-align:top}
.pc-table th{background:#f5e8dc;color:#21473d;font-weight:800}
.pc-table td:first-child{font-weight:700;color:#526b5e;width:27%;background:#f8faf7}
.pc-table tr:last-child td{border-bottom:0}
.pc-table td:not(:first-child){font-size:16px}
.pc-error{padding:25px;background:#fff6ed;border:1px solid #ead4bd;border-radius:14px}
@media(max-width:650px){.pc-wrap{padding:25px 12px}.pc-table th,.pc-table td{padding:13px 9px;font-size:12px!important}}

.pc-wrap{background:#faf8f4;color:#173e36}.pc-table{border-color:#e6d8cd}.pc-table th{background:#f2e5da}.pc-back{color:#a95737}.pc-table td:first-child{background:#faf5ef}
/* Coordinated compare page */
.pc-wrap{background:#f9f6f1!important}.pc-table th{background:#e9d8c9!important}
.pc-table td:first-child{background:#f6eee5!important}.pc-back{color:#995337!important}

.pc-wrap{max-width:1180px!important;background:#fff9f3!important;color:#213f39!important}
.pc-table{border:1px solid #e6d2c4!important;box-shadow:0 12px 30px #49342612!important}
.pc-table th{background:#e8d6c7!important;color:#183e36!important}
.pc-table td:first-child{background:#f9eee5!important}
.pc-back{color:#a65335!important}
.pc-table tbody tr:hover td{background:#fff9f3}
</style>
<link rel="stylesheet" href="assets/css/compare-graduation.css?v=<?= @filemtime(__DIR__ . '/assets/css/compare-graduation.css') ?: time() ?>">
<main class="pc-wrap">
<a class="pc-back" href="recommendations.php">&larr; Back to Property Recommendations</a>
<header class="pc-hero"><h1>Compare Properties</h1><p>See how your selected homes compare on price, space and fit.</p></header>
<?php if ($error): ?><p class="pc-error"><?= pc_e($error) ?></p><?php else: ?>
<div class="pc-property-heads">
<?php $comparePhotoUses = []; foreach ($items as $item):
  $pcProperty = $item['property'];
  $pcId = (string) $pcProperty['property_id'];
  $pcType = (string) ($pcProperty['property_type'] ?? 'Property');
  $pcNeighborhood = (diyara_neighborhood_name($item['neighborhood']) ?: 'Riyadh');
  $pcHasPhoto = !empty($pcUploaded[$pcId][0]['url']);
  $pcImage = $pcHasPhoto ? $pcUploaded[$pcId][0]['url'] : diyara_property_photo($pcId, $pcType, 'all', $comparePhotoUses);
  $pcMatch = $pcProperty['match_score'] ?? null;
?>
<article class="pc-property-head">
<img src="<?= pc_e($pcImage . ($pcHasPhoto ? '' : '?v=20261120e')) ?>" alt="<?= $pcHasPhoto ? pc_e($pcType . ' in ' . $pcNeighborhood) : '' ?>" loading="lazy" decoding="async">
<div class="pc-property-head-copy">
<h2><?= pc_e($pcType . ' in ' . $pcNeighborhood) ?></h2>
<div class="pc-property-head-meta"><strong><?= is_numeric($pcProperty['price']) ? number_format((float)$pcProperty['price']) . ' SAR' : 'Price not listed' ?></strong>
<?php if (is_numeric($pcMatch)): ?><em><?= number_format((float)$pcMatch, 1) ?>% match</em><?php elseif ($housing): ?><em>Outside saved criteria</em><?php endif; ?></div>
<?php if ($housing): ?>
<?= diyara_bilingual_explanation(diyara_housing_summary($pcProperty, $housing)) ?>
<?php endif; ?>
</div></article>
<?php endforeach; ?>
</div>
<div class="pc-table-scroll" tabindex="0" role="region" aria-label="Property comparison table">
<table class="pc-table"><thead><tr><th>Property details</th>
<?php foreach ($items as $item): ?><th><?= pc_e($item['property']['property_type'] ?? 'Property') ?> in <?= pc_e(diyara_neighborhood_name($item['neighborhood'])) ?></th><?php endforeach; ?>
</tr></thead><tbody>
<?php foreach ($rows as $row): ?><tr><td><?= pc_e($row['label']) ?></td>
<?php foreach ($items as $item): $p=$item['property'];$n=$item['neighborhood'];$key=$row['key'];
$value=$key==='neighborhood'?diyara_neighborhood_name($n):($p[$key] ?? null);
if ($key==='price' && is_numeric($value)) $value=number_format((float)$value);
if ($key==='match_score' && is_numeric($value)) $value=number_format((float)$value,1).' / 100';
?><td><?= pc_e($value===null || $value===''?'Not listed':$value) ?></td><?php endforeach; ?></tr><?php endforeach; ?>
<tr><td>Details</td><?php foreach ($items as $item): ?><td><a class="pc-back" href="property-details.php?id=<?= rawurlencode((string)$item['property']['property_id']) ?>">View property &rarr;</a></td><?php endforeach; ?></tr>
</tbody></table>
</div>
<?php endif; ?>
</main>
<?php require 'includes/footer.php'; ?>
