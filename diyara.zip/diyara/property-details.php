<?php
require 'auth_check.php';
require 'db.php';
require 'filter.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) { header('Location: login.html'); exit; }
function detail_escape($value) { return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function detail_price($value) { return $value === null ? 'Not available' : number_format((float) $value) . ' SAR'; }
$id = trim((string) ($_GET['id'] ?? ''));
if (strlen($id) > 100 || preg_match('/[\x00-\x1F]/', $id)) { $id = ''; }
$property = null; $neighborhood = null; $housing = null;
$errorMessage = '';
try {
    if ($id) {
        $stmt = $pdo->prepare('SELECT budget, property_type, preferred_size, bedrooms, preferred_location FROM housing_preferences WHERE user_id=? LIMIT 1');
        $stmt->execute([$userId]);
        $housing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($housing) {
            // Reuse existing matching and ranking logic; no new recommendation algorithm.
            $recommendations = get_candidate_neighborhoods($pdo, $housing);
            foreach ($recommendations as $candidate) {
                foreach ($candidate['properties'] as $listing) {
                    if ((string) $listing['property_id'] === (string) $id) { $property = $listing; $neighborhood = $candidate; break 2; }
                }
            }
        }
    }
} catch (Throwable $e) { error_log('DIYARA property details: '.$e->getMessage()); $errorMessage = 'Property details are temporarily unavailable.'; }
$page_title = 'Property Details'; $active = 'recommendations';
require 'includes/header.php';
?>
<link rel="stylesheet" href="recommendations-extra.css">
<div class="page page-shared"><div class="container">
<a class="rec-detail-link" href="recommendations.php">← Back to Recommendations</a>
<?php if ($errorMessage !== ''): ?><div class="empty"><p><?= detail_escape($errorMessage) ?></p></div>
<?php elseif (!$property || !$neighborhood): ?><div class="empty"><p>Property not found among your current matching recommendations.</p><a class="btn" href="recommendations.php">View Recommendations</a></div>
<?php else:
$type=(string)$property['property_type'];
$isVilla=stripos($type,'villa')!==false || strpos($type,'فيلا')!==false;
$kind=$isVilla?'villa':'apartment';
$displayType=$isVilla?'Villa':'Apartment';
$neighborhoodName=$neighborhood['name_en'] ?: $neighborhood['name_ar'];
$price=$property['price']===null?null:(float)$property['price'];
$area=$property['area_m2']===null?null:(float)$property['area_m2'];
$bedrooms=$property['bedrooms']===null?null:(int)$property['bedrooms'];
$bathrooms=$property['bathrooms']===null?null:(int)$property['bathrooms'];
$budget=isset($housing['budget'])?(float)$housing['budget']:null;
$preferredArea=isset($housing['preferred_size'])?(float)$housing['preferred_size']:null;
$preferredBedrooms=isset($housing['bedrooms'])?(int)$housing['bedrooms']:null;
$preferredType=(string)($housing['property_type']??'');
$reasons=[];
if ($preferredType==='Both' || stripos($preferredType,$displayType)!==false) $reasons[]='Matches your selected property type ('.$displayType.').';
if ($price!==null && $budget!==null && $price<=$budget) $reasons[]='Within your saved housing budget.';
if ($area!==null && $preferredArea!==null) $reasons[]='Your preferred area is '.number_format($preferredArea).' m²; this property offers '.number_format($area).' m².';
if ($bedrooms!==null && $preferredBedrooms!==null) $reasons[]='Your preferred bedroom count is '.$preferredBedrooms.'; this property has '.$bedrooms.'.';
$comparisons=[
 ['Property Type',$preferredType?:'Not specified',$displayType],
 ['Area',$preferredArea===null?'Not specified':number_format($preferredArea).' m²',$area===null?'Not available':number_format($area).' m²'],
 ['Bedrooms',$preferredBedrooms===null?'Not specified':(string)$preferredBedrooms,$bedrooms===null?'Not available':(string)$bedrooms],
 ['Budget',$budget===null?'Not specified':detail_price($budget),detail_price($price)]
];
$services=[['Schools','schools_count'],['Healthcare','hospitals_count'],['Parks','parks_count'],['Supermarkets','supermarkets_count']];
$serviceIcons = [
    'Schools' => '<svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m2 10 10-6 10 6-10 6-10-6Z"/><path d="M6 13v5c3 3 9 3 12 0v-5"/><path d="M22 10v7"/></svg>',
    'Healthcare' => '<svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="3" width="18" height="18" rx="3"/><path d="M12 7v10M7 12h10"/></svg>',
    'Parks' => '<svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m12 3-5 7h3l-5 7h14l-5-7h3l-5-7Z"/><path d="M12 17v5"/></svg>',
    'Supermarkets' => '<svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="9" cy="20" r="1"/><circle cx="19" cy="20" r="1"/><path d="M2 3h2l2.4 12.1A2 2 0 0 0 8.4 17H20"/><path d="M5 7h17l-2 8H6"/></svg>'
];
?>
<div class="dy-detail">
  <div class="dy-heading"><div><span class="dy-eyebrow">DIYARA PROPERTY</span><h1><?= detail_escape($displayType) ?> in <?= detail_escape($neighborhoodName) ?></h1><p><?= detail_escape($neighborhoodName) ?>, Riyadh &nbsp; | &nbsp; Property #<?= detail_escape($property['property_id']) ?></p></div><span class="dy-pill"><?= detail_escape($displayType) ?></span></div>
  <div class="dy-gallery"><div class="rec-property-image rec-image-<?= $kind ?>" role="img" aria-label="Illustrative exterior"><span>EXTERIOR</span></div><div class="rec-property-image rec-image-interior-<?= $kind ?>" role="img" aria-label="Illustrative interior"><span>INTERIOR</span></div></div>
  <p class="dy-photo-note">Illustrative property images </p>
  <section class="dy-section"><h2>Property Overview</h2><div class="dy-specs">
    <div><svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="5" width="18" height="15" rx="2"/><path d="M3 9h18"/><path d="M16 15h2"/></svg><small>Price</small><strong><?= detail_price($price) ?></strong></div>
    <div><svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M21 3 3 21"/><path d="m15 3 6 6"/><path d="m3 15 6 6"/><path d="m13 5 2 2"/><path d="m9 9 2 2"/><path d="m5 13 2 2"/></svg><small>Area</small><strong><?= $area===null?'Not available':number_format($area).' m²' ?></strong></div>
    <div><svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 18v-7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v7"/><path d="M3 14h18"/><path d="M5 9V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3"/><path d="M12 9V6a2 2 0 0 1 2-2h3a2 2 0 0 1 2 2v3"/><path d="M3 18v2m18-2v2"/></svg><small>Bedrooms</small><strong><?= $bedrooms===null?'Not available':$bedrooms ?></strong></div>
    <div><svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 13h18v2a6 6 0 0 1-6 6H9a6 6 0 0 1-6-6v-2Z"/><path d="M6 13V5a2 2 0 0 1 2-2h2"/><path d="M9 6h4"/><path d="M7 21v1m10-1v1"/></svg><small>Bathrooms</small><strong><?= $bathrooms===null?'Not available':$bathrooms ?></strong></div>
    <div><svg class="dy-line-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m3 10 9-7 9 7"/><path d="M5 9v12h14V9"/><path d="M9 21v-7h6v7"/></svg><small>Property Type</small><strong><?= detail_escape($displayType) ?></strong></div>
  </div></section>
  <section class="dy-reasons"><h2>Why This Property Matches You</h2><?php if ($reasons): ?><ul><?php foreach ($reasons as $reason): ?><li><span aria-hidden="true">✓</span><?= detail_escape($reason) ?></li><?php endforeach; ?></ul><?php else: ?><p>Compare the property details with your saved preferences below.</p><?php endif; ?></section>
  <section class="dy-section"><h2>Your Preferences vs. This Property</h2><div class="dy-table-wrap"><table class="dy-table"><thead><tr><th>Feature</th><th>Your Preference</th><th>This Property</th></tr></thead><tbody><?php foreach ($comparisons as $c): ?><tr><th scope="row"><?= detail_escape($c[0]) ?></th><td><?= detail_escape($c[1]) ?></td><td><?= detail_escape($c[2]) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
  <section class="dy-area"><span class="dy-eyebrow">EXPLORE THE AREA</span><h2>About the Neighborhood — <?= detail_escape($neighborhoodName) ?></h2><p>Explore neighborhood services </p><div class="dy-services"><?php foreach ($services as $service): $count=isset($neighborhood[$service[1]])?(int)$neighborhood[$service[1]]:null; ?><div><?= $serviceIcons[$service[0]] ?? '' ?><strong><?= detail_escape($service[0]) ?></strong><small><?= $count===null?'Data unavailable':($count===0?'None ':number_format($count).'') ?></small></div><?php endforeach; ?></div><p class="dy-footnote"></p></section>
</div>
<?php endif; ?></div></div>
<?php require 'includes/footer.php'; ?>
