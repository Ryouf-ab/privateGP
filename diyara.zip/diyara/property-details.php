<?php
require 'auth_check.php';
require 'db.php';
require 'filter.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) { header('Location: login.html'); exit; }
function detail_escape($value) { return htmlspecialchars((string) ($value ?? ''), ENT_QUOTES, 'UTF-8'); }
function detail_price($value) { return $value === null ? 'Not available' : number_format((float) $value) . ' SAR'; }
$id = trim((string) ($_GET['id'] ?? ''));
if (strlen($id) > 100 || preg_match('/[\x00-\x1F]/', $id)) { $id = ''; }
$property = null; $neighborhood = null; $housing = null;
$errorMessage = '';
try {
    if ($id) {
        $stmt = $pdo->prepare('SELECT budget, property_type, preferred_size, bedrooms, preferred_location FROM housing_preferences WHERE user_id=? LIMIT 1');
        $stmt->execute([$userId]);
        $housing = $stmt->fetch(PDO::FETCH_ASSOC);
        if ($housing) {
            // Reuse existing matching and ranking logic; no new recommendation algorithm.
            $recommendations = get_candidate_neighborhoods($pdo, $housing);
            foreach ($recommendations as $candidate) {
                foreach ($candidate['properties'] as $listing) {
                    if ((string) $listing['property_id'] === (string) $id) { $property = $listing; $neighborhood = $candidate; break 2; }
                }
            }
        }
    }
} catch (Throwable $e) { error_log('DIYARA property details: '.$e->getMessage()); $errorMessage = 'Property details are temporarily unavailable.'; }
$page_title = 'Property Details'; $active = 'recommendations';
require 'includes/header.php';
?>
<link rel="stylesheet" href="recommendations-extra.css">
<div class="page page-shared"><div class="container">
<a class="rec-detail-link" href="recommendations.php">← Back to Recommendations</a>
<?php if ($errorMessage !== ''): ?><div class="empty"><p><?= detail_escape($errorMessage) ?></p></div>
<?php elseif (!$property || !$neighborhood): ?><div class="empty"><p>Property not found among your current matching recommendations.</p><a class="btn" href="recommendations.php">View Recommendations</a></div>
<?php else:
$type = (string) $property['property_type'];
$isVilla = stripos($type, 'villa') !== false || strpos($type, 'فيلا') !== false;
$kind = $isVilla ? 'villa' : 'apartment';
$reasons = [];
 $reasons[] = (($housing['property_type'] ?? '') === 'Both') ? 'You selected both apartments and villas; this listing is one of those property types.' : 'This property matches your selected property type.';
if ((float) $property['price'] <= (float) $housing['budget']) $reasons[] = 'Its price is within your saved housing budget.';
if ($housing['preferred_size'] !== null && $property['area_m2'] !== null) {
    $reasons[] = 'Your preferred size is '.number_format((float)$housing['preferred_size']).' m²; this property is '.number_format((float)$property['area_m2']).' m².';
}
if ($housing['bedrooms'] !== null && $property['bedrooms'] !== null) {
    $reasons[] = 'Your preferred bedroom count is '.(int)$housing['bedrooms'].'; this property has '.(int)$property['bedrooms'].'.';
}
?>
<div class="rec-detail-page">
<span class="rec-eyebrow">DIYARA PROPERTY</span>
<h1><?= detail_escape($type) ?> in <?= detail_escape($neighborhood['name_en'] ?: $neighborhood['name_ar']) ?></h1>
<p class="rec-subtitle">Property #<?= detail_escape($property['property_id']) ?> · Illustrative property images </p>
<div class="rec-photo-gallery">
<div class="rec-property-image rec-image-<?= $kind ?>" role="img" aria-label="Illustrative property exterior"><span>exterior</span></div>
<div class="rec-property-image rec-image-interior-<?= $kind ?>" role="img" aria-label="Illustrative property interior"><span>interior</span></div>
</div>
<div class="rec-detail-columns"><section class="rec-neighborhood"><h2>Property Details</h2><div class="rec-detail-attributes">
<div><small>Price</small><strong><?= detail_price($property['price']) ?></strong></div>
<div><small>Area</small><strong><?= $property['area_m2'] === null ? 'Not available' : number_format((float)$property['area_m2']).' m²' ?></strong></div>
<div><small>Bedrooms</small><strong><?= $property['bedrooms'] === null ? 'Not available' : (int)$property['bedrooms'] ?></strong></div>
<div><small>Bathrooms</small><strong><?= $property['bathrooms'] === null ? 'Not available' : (int)$property['bathrooms'] ?></strong></div>
</div></section><section class="rec-neighborhood"><span class="rec-eyebrow">MATCH EXPLANATION</span><h2>Why this property matches</h2><ul class="rec-reasons"><?php foreach($reasons as $reason): ?><li><?= detail_escape($reason) ?></li><?php endforeach; ?></ul><p class="rec-explain-note"></p></section></div>
</div>
<?php endif; ?></div></div>
<?php require 'includes/footer.php'; ?>
