<?php
/**
 * Visual fallbacks only. Agent-uploaded listing photos always take priority.
 * No housing, recommendation, WSM or database logic lives in this file.
 */
function diyara_property_photo_pool(string $type, string $scene = 'all'): array
{
    $type = strtolower(trim($type));
    $categories = ['villa' => 'villa', 'فيلا' => 'villa', 'apartment' => 'apartment', 'شقة' => 'apartment'];
    if (in_array($type, ['floor', 'دور'], true)) {
        $inside = ['assets/collection-villa-interior-1.webp', 'assets/collection-apartment-interior-4.webp'];
        $facades = ['assets/luxe-villa-2.webp', 'assets/luxe-villa-4.webp'];
        return $scene === 'interior' ? $inside : ($scene === 'exterior' ? $facades : array_merge($inside, $facades));
    }
    $category = $categories[$type] ?? null;
    if ($category === null) {
        return ['assets/property-no-photo.webp'];
    }

    $exteriors = [];
    for ($index = 1; $index <= 4; $index++) {
        $exteriors[] = "assets/luxe-{$category}-{$index}.webp";
    }
    $interiors = [
        "assets/luxe-{$category}-room-1.webp",
        "assets/luxe-{$category}-room-2.webp",
        "assets/collection-{$category}-interior-2.webp",
        "assets/collection-{$category}-interior-3.webp",
    ];

    if ($scene === 'exterior') return $exteriors;
    if ($scene === 'interior') return $interiors;
    return array_merge($exteriors, $interiors);
}

function diyara_property_photo(string $id, string $type, string $scene = 'all', ?array &$used = null): string
{
    $photos = diyara_property_photo_pool($type, $scene);
    $hash = (int) sprintf('%u', crc32($id));
    $offset = $hash % count($photos);
    if ($used === null) {
        return $photos[$offset];
    }

    // Spread repeats out within each type, even when adjacent IDs hash alike.
    $fewestUses = min(array_map(static fn(string $photo): int => $used[$photo] ?? 0, $photos));
    for ($i = 0; $i < count($photos); $i++) {
        $photo = $photos[($offset + $i) % count($photos)];
        if (($used[$photo] ?? 0) === $fewestUses) {
            $used[$photo] = $fewestUses + 1;
            return $photo;
        }
    }

    return $photos[$offset];
}

function diyara_property_gallery(string $id, string $type): array
{
    // Different scenes and angles for each listing; strictly matching its type.
    return array_values(array_unique([
        diyara_property_photo($id, $type, 'exterior'),
        diyara_property_photo($id . '-interior', $type, 'interior'),
    ]));
}

// Full-resolution gallery.
function diyara_detail_photos(string $id, string $type): array
{
    $sets = [
        'villa' => ['villa-exterior','villa-interior','villa-living','villa-dining','villa-garden','villa-courtyard','villa-evening'],
        'apartment' => ['apartment-exterior','apartment-interior','apartment-kitchen','apartment-bedroom','apartment-balcony','apartment-living','apartment-balconies','apartment-street'],
        'floor' => ['villa-exterior','apartment-living','apartment-kitchen','bedroom-interior','terrace'],
    ];
    $category = ['فيلا'=>'villa','شقة'=>'apartment','دور'=>'floor'][trim($type)] ?? strtolower(trim($type));
    if (!isset($sets[$category])) return ['assets/property-no-photo.webp'];
    $views = $sets[$category];
    $start = crc32($id) % count($views);
    $ordered = array_merge(array_slice($views, $start), array_slice($views, 0, $start));
    return array_map(static function ($view) { return 'assets/property-' . $view . '.jpg'; }, array_slice($ordered, 0, 5));
}
