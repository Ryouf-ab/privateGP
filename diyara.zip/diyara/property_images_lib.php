<?php
/**
 * Diyara Sprint 2: property photos (uploaded by agents, shown to everyone).
 * Files live in uploads/properties/ ; one row per photo in property_images.
 * Every function fails quietly (empty result) if the table does not exist yet,
 * so the site keeps working before sprint2_images.sql is imported.
 */
const PROPERTY_IMAGE_MAX = 5;                       // photos per listing
const PROPERTY_IMAGE_DIR = 'uploads/properties';    // relative to the site folder

function property_images_dir(): string
{
    $dir = __DIR__ . '/' . PROPERTY_IMAGE_DIR;
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    /* Uploaded folder must never run PHP and must not list its files */
    $ht = __DIR__ . '/uploads/.htaccess';
    if (is_dir(__DIR__ . '/uploads') && !file_exists($ht)) {
        @file_put_contents($ht, "Options -Indexes\n<FilesMatch \"\\.(php|phtml|phar|php[0-9])$\">\n  Require all denied\n</FilesMatch>\n");
    }
    return $dir;
}

/** @return array<string, array<int, array{image_id:int,url:string}>> property_id => photos (in order) */
function property_images_for(PDO $pdo, array $propertyIds): array
{
    $propertyIds = array_values(array_unique(array_map('strval', $propertyIds)));
    if (!$propertyIds) {
        return [];
    }
    try {
        $in = implode(',', array_fill(0, count($propertyIds), '?'));
        $stmt = $pdo->prepare("SELECT image_id, property_id, file_name FROM property_images WHERE property_id IN ($in) ORDER BY sort_order, image_id");
        $stmt->execute($propertyIds);
        $out = [];
        foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $out[$r['property_id']][] = [
                'image_id' => (int) $r['image_id'],
                'url' => PROPERTY_IMAGE_DIR . '/' . $r['file_name'],
            ];
        }
        return $out;
    } catch (Throwable $e) {
        return [];
    }
}

/** Removes the files and rows of one listing (used when the listing is deleted). */
function property_images_delete_all(PDO $pdo, string $propertyId): void
{
    try {
        $stmt = $pdo->prepare('SELECT file_name FROM property_images WHERE property_id = ?');
        $stmt->execute([$propertyId]);
        foreach ($stmt->fetchAll(PDO::FETCH_COLUMN) as $name) {
            @unlink(property_images_dir() . '/' . basename((string) $name));
        }
        $pdo->prepare('DELETE FROM property_images WHERE property_id = ?')->execute([$propertyId]);
    } catch (Throwable $e) {
        /* table not created yet: nothing to remove */
    }
}
