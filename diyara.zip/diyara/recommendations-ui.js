(() => {
  const container = document.querySelector('#rec-results');
  if (!container) return;
  const cards = [...container.querySelectorAll('.rec-neighborhood')];
  const search = document.querySelector('#rec-search');
  const neighborhoodSort = document.querySelector('#rec-neighborhood-sort');
  const propertySort = document.querySelector('#rec-property-sort');
  const noMatches = document.querySelector('#rec-no-matches');
  const selected = [];
  const data = JSON.parse(document.querySelector('#rec-comparison-data').textContent);
  const byId = new Map(data.map(item => [String(item.id), item]));
  const esc = text => String(text ?? '').replace(/[&<>"']/g, ch => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
  const fmt = v => v == null || v === '' ? 'N/A' : Number(v).toLocaleString('en-US');
  function renderComparison() {
    const dest = document.querySelector('#rec-comparison');
    if (selected.length < 2) { dest.textContent = 'Select two neighborhoods to see their available data side by side.'; return; }
    const [a,b] = selected.map(id => byId.get(id));
    const rows = [['Median property price', 'price'],['Matching properties','count'], ['Schools','schools'], ['Hospitals','hospitals'], ['Parks','parks'], ['Supermarkets','supermarkets'], ['Shopping centers','shopping']];
    dest.innerHTML = `<div class="rec-compare-scroll"><table class="rec-compare-table"><thead><tr><th>Feature</th><th>${esc(a.name)}</th><th>${esc(b.name)}</th></tr></thead><tbody>${rows.map(([label,key]) => `<tr><th>${label}</th><td>${fmt(a[key])}</td><td>${fmt(b[key])}</td></tr>`).join('')}</tbody></table></div>`;
  }
  container.querySelectorAll('.rec-compare-check').forEach(input => input.addEventListener('change', () => {
    const id = input.value;
    if (input.checked) { if (selected.length === 2) { const removed = selected.shift(); const old = [...container.querySelectorAll('.rec-compare-check')].find(x => x.value === removed); if (old) old.checked = false; } selected.push(id); }
    else { const index = selected.indexOf(id); if (index !== -1) selected.splice(index,1); }
    renderComparison();
  }));
  function refresh() {
    const q = search.value.trim().toLocaleLowerCase();
    let matches = 0;
    cards.forEach(card => { const visible = (card.dataset.name+' '+card.dataset.ar).toLocaleLowerCase().includes(q); card.hidden = !visible; if (visible) matches++; });
    noMatches.hidden = matches > 0;
    const order = neighborhoodSort.value;
    const sorted = [...cards].sort((a,b) => {
      if (order === 'az' || order === 'za') { const result = a.dataset.name.localeCompare(b.dataset.name, undefined, {sensitivity:'base'}); return order === 'az' ? result : -result; }
      if (order === 'properties') return Number(b.dataset.count)-Number(a.dataset.count) || Number(a.dataset.index)-Number(b.dataset.index);
      return Number(a.dataset.index)-Number(b.dataset.index);
    });
    sorted.forEach(card => container.insertBefore(card, noMatches));
    cards.forEach(card => {
      const list = card.querySelector('.rec-property-list');
      const props = [...list.querySelectorAll('.rec-property')];
      props.forEach((el,i) => { if (!el.dataset.initialOrder) el.dataset.initialOrder = String(i+1); });
      props.sort((a,b) => { const key=propertySort.value; if(key === 'price-low') return +a.dataset.price - +b.dataset.price; if(key==='price-high') return +b.dataset.price - +a.dataset.price; if(key==='area-high') return +b.dataset.area - +a.dataset.area; if(key==='beds-high') return +b.dataset.beds - +a.dataset.beds; return +a.dataset.initialOrder - +b.dataset.initialOrder; });
      props.forEach(el => list.appendChild(el));
    });
  }
  [search, neighborhoodSort, propertySort].forEach(el => el.addEventListener(el === search ? 'input' : 'change', refresh));
  refresh();
})();
