<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
require 'auth_check.php';
require 'db.php';
require 'filter.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header('Location: login.html');
    exit;
}
function show_price($value)
{
    if ($value === null || $value === '') {
        return 'Not available';
    }
    return number_format((float) $value) . ' SAR';
}
function safe_output($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}
$page_title = 'Recommendations';
$active = 'recommendations';
$housing = null;
$results = [];
$errorMessage = '';
try {
    $stmt = $pdo->prepare("
        SELECT
            budget,
            property_type,
            preferred_size,
            bedrooms,
            preferred_location
        FROM housing_preferences
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $housing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($housing) {
        $results = get_candidate_neighborhoods($pdo, $housing);
    }
} catch (Throwable $e) {
    error_log('DIYARA recommendations error: ' . $e->getMessage());
    $errorMessage = 'We could not load recommendations. Please check your database configuration and try again.';
}
$totalProperties = 0;
foreach ($results as $neighborhood) {
    $totalProperties += count($neighborhood['properties']);
}
require 'includes/header.php';
?>
<section class="page">
    <div class="container">
        <h1>Recommended Neighborhoods</h1>
        <?php if ($errorMessage !== ''): ?>
            <div class="empty">
                <p><?php echo safe_output($errorMessage); ?></p>
                <a
                    class="btn btn-secondary"
                    href="housing-preferences.php"
                >
                    Edit Housing Preferences
                </a>
            </div>
        <?php elseif (!$housing): ?>
            <div class="empty">
                <p>
                    You haven't saved your housing preferences yet.
                    Enter your preferences to see recommendations.
                </p>
                <a class="btn" href="housing-preferences.php">
                    Set Housing Preferences
                </a>
            </div>
        <?php elseif (empty($results)): ?>
            <div class="empty">
                <p>
                    No properties match your current preferences.
                    Try changing your budget, property type,
                    or bedroom requirements.
                </p>
                <a
                    class="btn btn-secondary"
                    href="housing-preferences.php"
                >
                    Edit Housing Preferences
                </a>
            </div>
        <?php else: ?>
            <p>
                Found
                <strong><?php echo count($results); ?></strong>
                matching neighborhoods and
                <strong><?php echo $totalProperties; ?></strong>
                matching properties.
            </p>
            <div class="grid grid-3">
                <?php foreach ($results as $n): ?>
                    <div class="card">
                        <h2>
                            <?php
                            echo safe_output(
                                $n['name_ar'] ?: $n['name_en']
                            );
                            ?>
                        </h2>
                        <?php if (!empty($n['name_en'])): ?>
                            <p>
                                <?php echo safe_output($n['name_en']); ?>
                                <?php if (!empty($n['region'])): ?>
                                    · <?php echo safe_output($n['region']); ?>
                                <?php endif; ?>
                            </p>
                        <?php endif; ?>
                        <h3>Neighborhood Services</h3>
                        <ul>
                            <li>
                                Schools:
                                <?php echo (int) ($n['schools_count'] ?? 0); ?>
                            </li>
                            <li>
                                Hospitals:
                                <?php echo (int) ($n['hospitals_count'] ?? 0); ?>
                            </li>
                            <li>
                                Parks:
                                <?php echo (int) ($n['parks_count'] ?? 0); ?>
                            </li>
                            <li>
                                Gyms:
                                <?php echo (int) ($n['gyms_count'] ?? 0); ?>
                            </li>
                            <li>
                                Pharmacies:
                                <?php echo (int) ($n['pharmacies_count'] ?? 0); ?>
                            </li>
                            <li>
                                Supermarkets:
                                <?php echo (int) ($n['supermarkets_count'] ?? 0); ?>
                            </li>
                            <li>
                                Shopping centers:
                                <?php echo (int) ($n['shopping_centers_count'] ?? 0); ?>
                            </li>
                            <li>
                                Metro stations:
                                <?php echo (int) ($n['metro_stations_count'] ?? 0); ?>
                            </li>
                        </ul>
                        <hr>
                        <h3>
                            Matching Properties
                            (<?php echo count($n['properties']); ?>)
                        </h3>
                        <div class="grid grid-3">
                            <?php foreach ($n['properties'] as $property): ?>
                                <div class="card">
                                    <h4>
                                        <?php echo safe_output($property['property_type']); ?>
                                    </h4>
                                    <p>
                                        <strong>Property ID:</strong>
                                        <?php echo safe_output($property['property_id']); ?>
                                    </p>
                                    <p>
                                        <strong>Price:</strong>
                                        <?php echo show_price($property['price']); ?>
                                    </p>
                                    <p>
                                        <strong>Area:</strong>
                                        <?php
                                        echo $property['area_m2'] !== null
                                            ? number_format((float) $property['area_m2']) . ' m²'
                                            : 'Not available';
                                        ?>
                                    </p>
                                    <p>
                                        <strong>Bedrooms:</strong>
                                        <?php
                                        echo $property['bedrooms'] !== null
                                            ? (int) $property['bedrooms']
                                            : 'Not available';
                                        ?>
                                    </p>
                                    <p>
                                        <strong>Bathrooms:</strong>
                                        <?php
                                        echo $property['bathrooms'] !== null
                                            ? (int) $property['bathrooms']
                                            : 'Not available';
                                        ?>
                                    </p>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
</section>
<?php require 'includes/footer.php'; ?>