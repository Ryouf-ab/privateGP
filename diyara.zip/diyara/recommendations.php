<?php
ini_set('display_errors', '1');
ini_set('display_startup_errors', '1');
error_reporting(E_ALL);
require 'auth_check.php';
require 'db.php';
require 'filter.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header('Location: login.html');
    exit;
}
function show_price($value)
{
    if ($value === null || $value === '') {
        return 'Not available';
    }
    return number_format((float) $value) . ' SAR';
}
function safe_output($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}
$page_title = 'Recommendations';
$active = 'recommendations';
$housing = null;
$results = [];
$errorMessage = '';
try {
    $stmt = $pdo->prepare("
        SELECT
            budget,
            property_type,
            preferred_size,
            bedrooms,
            preferred_location
        FROM housing_preferences
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $housing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($housing) {
        $results = get_candidate_neighborhoods($pdo, $housing);
    }
} catch (Throwable $e) {
    error_log('DIYARA recommendations error: ' . $e->getMessage());
    $errorMessage = 'We could not load recommendations. Please check your database configuration and try again.';
}
$totalProperties = 0;
foreach ($results as $neighborhood) {
    $totalProperties += count($neighborhood['properties']);
}
require 'includes/header.php';
?>
<link rel="stylesheet" href="recommendations-extra.css">
<section class="page page-shared rec-redesign">
    <div class="container">
        <div class="rec-hero"><span class="rec-eyebrow">YOUR PERSONALIZED RESULTS</span><h1>Recommended Neighborhoods</h1><p>Discover Riyadh neighborhoods and properties that match your saved preferences.</p></div>
        <?php if ($errorMessage !== ''): ?>
            <div class="empty">
                <p><?php echo safe_output($errorMessage); ?></p>
                <a
                    class="btn btn-secondary"
                    href="housing-preferences.php"
                >
                    Edit Housing Preferences
                </a>
            </div>
        <?php elseif (!$housing): ?>
            <div class="empty">
                <p>
                    You haven't saved your housing preferences yet.
                    Enter your preferences to see recommendations.
                </p>
                <a class="btn" href="housing-preferences.php">
                    Set Housing Preferences
                </a>
            </div>
        <?php elseif (empty($results)): ?>
            <div class="empty">
                <p>
                    No properties match your current preferences.
                    Try changing your budget, property type,
                    or bedroom requirements.
                </p>
                <a
                    class="btn btn-secondary"
                    href="housing-preferences.php"
                >
                    Edit Housing Preferences
                </a>
            </div>
        <?php else: ?>
            <p>
                Found
                <strong><?php echo count($results); ?></strong>
                matching neighborhoods and
                <strong><?php echo $totalProperties; ?></strong>
                matching properties.
            </p>
            <div class="rec-toolbar" aria-label="Recommendation controls">
                <label class="rec-field">Search neighborhoods
                    <input id="rec-search" type="search" placeholder="Search by Arabic or English name..." autocomplete="off">
                </label>
                <label class="rec-field">Neighborhood order
                    <select id="rec-neighborhood-sort">
                        <option value="recommended">Recommended (original order)</option>
                        <option value="az">Name A–Z</option>
                        <option value="za">Name Z–A</option>
                        <option value="properties">Most matching properties</option>
                    </select>
                </label>
                <label class="rec-field">Property order
                    <select id="rec-property-sort">
                        <option value="recommended">Best match (original order)</option>
                        <option value="price-low">Price: low to high</option>
                        <option value="price-high">Price: high to low</option>
                        <option value="area-high">Area: largest first</option>
                        <option value="beds-high">Bedrooms: most first</option>
                    </select>
                </label>
            </div>
            <div class="rec-layout">
                <div class="rec-results" id="rec-results">
                    <?php foreach ($results as $index => $n): ?>
                        <?php
                        $neighborhoodName = $n['name_en'] ?: ($n['name_ar'] ?: 'Neighborhood');
                        ?>
                        <article class="rec-neighborhood" data-id="<?php echo (int) $n['neighborhood_id']; ?>" data-index="<?php echo (int) $index; ?>" data-name="<?php echo safe_output($neighborhoodName); ?>" data-ar="<?php echo safe_output($n['name_ar']); ?>" data-count="<?php echo count($n['properties']); ?>">
                            <div class="rec-neighborhood-top">
                                <div>
                                    <span class="rec-eyebrow">NEIGHBORHOOD <?php echo (int) ($index + 1); ?></span>
                                    <h2><?php echo safe_output($neighborhoodName); ?></h2>
                                    <p class="rec-subtitle"><?php echo safe_output($n['name_ar']); ?><?php if (!empty($n['region'])): ?> · <?php echo safe_output($n['region']); ?><?php endif; ?></p>
                                </div>
                                <div class="rec-top-actions">
                                    <?php if (!empty($n['is_preferred'])): ?><span class="rec-tag">Your preferred area</span><?php endif; ?>
                                    <span class="rec-count"><?php echo count($n['properties']); ?> matching properties</span>
                                    <label class="rec-compare-label"><input type="checkbox" class="rec-compare-check" value="<?php echo (int) $n['neighborhood_id']; ?>"> Compare</label>
                                </div>
                            </div>
                            <div class="rec-services">
                                <span>Schools <strong><?php echo (int) ($n['schools_count'] ?? 0); ?></strong></span>
                                <span>Hospitals <strong><?php echo (int) ($n['hospitals_count'] ?? 0); ?></strong></span>
                                <span>Parks <strong><?php echo (int) ($n['parks_count'] ?? 0); ?></strong></span>
                                <span>Supermarkets <strong><?php echo (int) ($n['supermarkets_count'] ?? 0); ?></strong></span>
                                <span>Shopping <strong><?php echo (int) ($n['shopping_centers_count'] ?? 0); ?></strong></span>
                                <span>Gyms <strong><?php echo (int) ($n['gyms_count'] ?? 0); ?></strong></span>
                            </div>
                            <div class="rec-neighborhood-reason"><strong>Why this neighborhood appears</strong><p>This neighborhood has <?php echo count($n['properties']); ?> <?php echo count($n['properties']) === 1 ? 'property' : 'properties'; ?> matching your saved property type and budget.<?php if (!empty($n['is_preferred'])): ?> It also matches your selected neighborhood preference.<?php endif; ?> </p></div>
                            <div class="rec-property-heading"><h3>Matching Properties</h3><span>Use Property order above to sort listings</span></div>
                            <div class="rec-property-list">
                                <?php foreach ($n['properties'] as $property): ?>
                                    <?php
                                    $listingType = (string) ($property['property_type'] ?? '');
                                    $isVilla = stripos($listingType, 'villa') !== false || strpos($listingType, 'فيلا') !== false;
                                    $imageType = $isVilla ? 'villa' : 'apartment';
                                    ?>
                                    <article class="rec-property" data-price="<?php echo (float) $property['price']; ?>" data-area="<?php echo (float) ($property['area_m2'] ?? 0); ?>" data-beds="<?php echo (int) ($property['bedrooms'] ?? 0); ?>">
                                        <div class="rec-property-image rec-image-<?php echo $imageType; ?>" role="img" aria-label="Illustrative <?php echo $imageType; ?> image"><span>Illustrative image</span></div>
                                        <div class="rec-property-info">
                                            <div class="rec-property-title"><strong><?php echo safe_output($listingType); ?></strong><span><?php echo show_price($property['price']); ?></span></div>
                                            <p><?php echo $property['area_m2'] !== null ? number_format((float) $property['area_m2']) . ' m²' : 'Area unavailable'; ?> · <?php echo $property['bedrooms'] !== null ? (int) $property['bedrooms'] . ' bedrooms' : 'Bedrooms unavailable'; ?> · <?php echo $property['bathrooms'] !== null ? (int) $property['bathrooms'] . ' bathrooms' : 'Bathrooms unavailable'; ?></p>
                                            <small>Property #<?php echo safe_output($property['property_id']); ?></small>
                                            <a class="rec-detail-link" href="property-details.php?id=<?php echo urlencode((string) $property['property_id']); ?>">View property details &amp; explanation <span aria-hidden="true">→</span></a>
                                        </div>
                                    </article>
                                <?php endforeach; ?>
                            </div>
                        </article>
                    <?php endforeach; ?>
                    <p id="rec-no-matches" class="rec-empty" hidden>No neighborhoods match this search.</p>
                </div>
                <aside class="rec-sidebar">
                    <div class="rec-compare-card">
                        <span class="rec-eyebrow">QUICK COMPARISON</span>
                        <h3>Compare neighborhoods</h3>
                        <p>Choose two neighborhoods with the Compare checkboxes.</p>
                        <div id="rec-comparison" aria-live="polite">Select two neighborhoods to see their available data side by side.</div>
                        <div class="rec-future" aria-disabled="true">Detailed comparison <span aria-hidden="true">→</span><small></small></div>
                    </div>
                </aside>
            </div>
            <script type="application/json" id="rec-comparison-data"><?php echo json_encode(array_map(static function ($n) {
                return [
                    'id' => (int) $n['neighborhood_id'],
                    'name' => (string) ($n['name_en'] ?: $n['name_ar'] ?: 'Neighborhood'),
                    'price' => $n['median_property_price'] === null ? null : (float) $n['median_property_price'],
                    'schools' => $n['schools_count'], 'hospitals' => $n['hospitals_count'],
                    'parks' => $n['parks_count'], 'supermarkets' => $n['supermarkets_count'],
                    'shopping' => $n['shopping_centers_count'], 'count' => count($n['properties'])
                ];
            }, $results), JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT); ?></script>
            <script src="recommendations-ui.js" defer></script>
        <?php endif; ?>
    </div>
</section>
<?php require 'includes/footer.php'; ?>