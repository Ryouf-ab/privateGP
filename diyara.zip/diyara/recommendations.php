<?php
require_once __DIR__ . "/includes/neighborhood-name.php";
require 'auth_check.php';
require 'db.php';
require 'filter.php';
require_once 'includes/discovery-filters.php';
require_once 'housing-discovery.php';
$userId = $_SESSION['user_id'] ?? null;
if (!$userId) {
    header('Location: login.html');
    exit;
}
function show_price($value)
{
    if ($value === null || $value === '') {
        return 'Not available';
    }
    return number_format((float) $value) . ' SAR';
}
function safe_output($value)
{
    return htmlspecialchars(
        (string) ($value ?? ''),
        ENT_QUOTES,
        'UTF-8'
    );
}
$page_title = 'Property Recommendations';
$active = 'recommendations';
$housing = null;
$results = [];
$errorMessage = '';
try {
    $stmt = $pdo->prepare("
        SELECT
            budget,
            property_type,
            preferred_size,
            bedrooms
        FROM housing_preferences
        WHERE user_id = ?
        LIMIT 1
    ");
    $stmt->execute([$userId]);
    $housing = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($housing) {
        $results = get_candidate_neighborhoods($pdo, $housing);
    }
} catch (Throwable $e) {
    error_log('DIYARA recommendations error: ' . $e->getMessage());
    $errorMessage = 'We could not load recommendations right now. Please try again in a moment.';
}
$totalProperties = 0;
foreach ($results as $neighborhood) {
    $totalProperties += count($neighborhood['properties']);
}
// Presentation only: flatten the already rule-filtered property results.
// The original filter.php and its property match calculations are untouched.
$propertyCards = [];
foreach ($results as $neighborhood) {
    foreach ($neighborhood['properties'] as $property) {
        $propertyCards[] = ['property' => $property, 'neighborhood' => $neighborhood];
    }
}
usort($propertyCards, static function ($a, $b) {
    $score = (float) $b['property']['match_score'] <=> (float) $a['property']['match_score'];
    if ($score !== 0) return $score;
    $price = (float) $a['property']['price'] <=> (float) $b['property']['price'];
    if ($price !== 0) return $price;
    return strcmp((string) $a['property']['property_id'], (string) $b['property']['property_id']);
});
$selectedNeighborhoodId = filter_input(INPUT_GET, 'neighborhood_id', FILTER_VALIDATE_INT);
if ($selectedNeighborhoodId === false || $selectedNeighborhoodId === null || $selectedNeighborhoodId <= 0) $selectedNeighborhoodId = null;
$selectedNeighborhoodName = '';
if ($selectedNeighborhoodId !== null && $errorMessage === '') {
    try {
        $place = $pdo->prepare('SELECT neighborhood_id, name_en, name_ar, region FROM neighborhoods WHERE neighborhood_id = ?');
        $place->execute([$selectedNeighborhoodId]);
        $neighborhood = $place->fetch(PDO::FETCH_ASSOC);
        if (!$neighborhood) {
            $errorMessage = 'This neighborhood could not be found.';
        } else {
            $selectedNeighborhoodName = diyara_neighborhood_name($neighborhood);
            $propertyCards = array_values(array_filter($propertyCards, static fn($entry) =>
                (int) $entry['neighborhood']['neighborhood_id'] === $selectedNeighborhoodId));
        }
    } catch (Throwable $e) {
        error_log('DIYARA neighborhood listings: ' . $e->getMessage());
        $errorMessage = 'We could not load homes in this neighborhood right now.';
    }
}
require 'includes/header.php';
?>
<style>
/* Diyara editorial refinement — no change to filter.php or match score calculations */
.pr-wrap{--ink:#173d38!important;--rust:#b66c49!important}.pr-card{border-radius:15px!important}.pr-card-body{padding:17px 19px!important}.pr-photo{height:240px!important}.pr-hero{border-radius:16px!important}.pr-compare-toolbar{background:#fff7f0!important;border-color:#e8d4c5!important}.pr-compare-toolbar button{background:#a54e32!important}.pr-tabs a[aria-current=page]{background:#a54e32!important}.pr-rank{background:#17433de8!important}.pr-details{background:#173d38!important}

.pr-wrap{--ink:#183c36;--mauve:#876d62;--rust:#b97556;--sand:#f8f5ef;max-width:1300px;margin:auto;padding:24px 24px 90px;color:var(--ink);font-family:'DM Sans',Arial,sans-serif}
.pr-tabs{display:flex;gap:6px;max-width:710px;padding:6px;background:#f1f3ed;border:1px solid #d8e0d7;border-radius:16px;margin:0 auto 26px}.pr-tabs a{flex:1;text-align:center;padding:13px 12px;border-radius:11px;color:#54635c;text-decoration:none;font-weight:700;font-size:13px}.pr-tabs a[aria-current=page]{background:#183c36;color:white;box-shadow:0 5px 15px #163c3622}
.pr-hero{border-radius:24px;overflow:hidden;position:relative;isolation:isolate;min-height:320px;display:flex;align-items:center;background:#183c36}.pr-hero:before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#102f2bef 0%,#163c36d6 46%,#173c3660 100%),url('assets/property-hero.jpg') center 52%/cover;z-index:-1}.pr-hero-copy{padding:46px 55px;max-width:710px;color:#fff}.pr-eyebrow{letter-spacing:2px;font-size:11px;color:#e9c6a8;font-weight:800}.pr-hero h1{font:600 clamp(35px,4vw,56px)/1.1 'Playfair Display',Georgia,serif;color:white;margin:14px 0}.pr-hero p{color:#f3ede5;font-size:15px;line-height:1.7;max-width:500px}.pr-hero-actions{display:flex;gap:12px;flex-wrap:wrap;margin-top:24px}.pr-hero-actions a{display:inline-block;padding:12px 18px;border-radius:10px;text-decoration:none;font-weight:700;font-size:13px;background:#f2e4d3;color:#1b3b34}.pr-hero-actions a.pr-secondary{background:#ffffff20;color:#fff;border:1px solid #ffffff70}
.pr-titlebar{display:flex;justify-content:space-between;align-items:end;gap:12px;margin:37px 0 18px}.pr-titlebar h2{font:600 29px 'Playfair Display',Georgia,serif;margin:0 0 6px}.pr-titlebar p{font-size:13px;color:#78847e;margin:0}.pr-pill{background:#eee8e0;border-radius:40px;padding:10px 15px;color:#53665d;font-size:12px;font-weight:700}.pr-toolbar{display:grid;grid-template-columns:minmax(160px,1fr) minmax(150px,230px);gap:12px;margin-bottom:22px}.pr-toolbar input,.pr-toolbar select{width:100%;border:1px solid #ddd9d1;background:white;padding:13px 15px;border-radius:12px;font:inherit;color:#29453d;min-width:0}
.pr-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:23px}.pr-card{background:#fffdfa;border:1px solid #e7e1d7;border-radius:19px;overflow:hidden;box-shadow:0 7px 23px #1c362b0d;transition:transform .2s,box-shadow .2s}.pr-card:hover{transform:translateY(-4px);box-shadow:0 15px 32px #1c362b18}.pr-photo{height:230px;position:relative;background-color:#dcd3c5;background-position:center;background-size:cover}.pr-photo:after{content:'';position:absolute;inset:0;background:linear-gradient(180deg,#0007,transparent 50%)}.pr-rank{position:absolute;z-index:1;top:16px;left:16px;background:#153a34e8;color:#fff;padding:8px 12px;border-radius:30px;font-size:11px;font-weight:800}.pr-match{position:absolute;z-index:1;right:14px;top:15px;background:#f9f2e9f2;color:#1e4c3e;border-radius:30px;padding:8px 12px;font-size:11px;font-weight:800}.pr-card-body{padding:22px}.pr-type{font-size:11px;color:#9b684f;letter-spacing:1.2px;text-transform:uppercase;font-weight:800}.pr-card h3{font:600 24px/1.2 'Playfair Display',Georgia,serif;color:#1d4139;margin:8px 0 6px}.pr-location{font-size:12px;color:#7b847d;margin:0 0 16px}.pr-price{font-size:24px;font-weight:800;color:#1e453b;margin:14px 0}.pr-price small{font-size:12px;font-weight:500;color:#76837a}.pr-facts{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:17px}.pr-facts span{background:#f5f0e9;border:1px solid #eee8df;border-radius:8px;padding:8px 10px;font-size:12px;color:#5d6e63}.pr-meter{height:5px;background:#ece9e3;border-radius:9px;overflow:hidden;margin:12px 0 17px}.pr-meter span{display:block;height:100%;background:#a86c56}.pr-details{display:block;text-align:center;text-decoration:none;background:#183c36;color:#fff;border-radius:11px;padding:13px;font-size:13px;font-weight:700}.pr-details:hover{background:#28594b}.pr-empty{padding:36px;background:white;border:1px solid #e7e1d7;border-radius:17px}.pr-empty a{color:#215e4d}.pr-note{font-size:11px;color:#899188;margin-top:25px;line-height:1.7}.pr-card[hidden]{display:none!important}
@media(max-width:1000px){.pr-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:650px){.pr-wrap{padding:16px 14px 50px}.pr-grid{grid-template-columns:1fr}.pr-hero-copy{padding:34px 25px}.pr-toolbar{grid-template-columns:1fr}.pr-tabs a{font-size:11px;padding:11px 7px}.pr-titlebar{align-items:start;flex-direction:column}.pr-photo{height:225px}}
/* Editorial Riyadh refinement: rich tones, not a flat beige grid */
.pr-wrap{--ink:#153a34;background:linear-gradient(155deg,#f7f7f2 0%,#f4f0ed 48%,#f4f4f1 100%)}
.pr-hero{min-height:375px;border:1px solid #b78d7555;box-shadow:0 20px 45px #173c3225}
.pr-hero:before{background:linear-gradient(90deg,#102d2af5 0%,#123631e6 30%,#173b3555 68%,#173b3508 100%),url('assets/property-hero.jpg') center/cover}
.pr-tabs{position:relative;z-index:2;background:#f8f7f3;box-shadow:0 8px 24px #183c3512}
.pr-card{border:1px solid #d7ddd5;background:#fff;box-shadow:0 9px 28px #173b3318}
.pr-card:nth-child(3n+2){border-color:#d9cad7}.pr-card:nth-child(3n){border-color:#d6c8ae}
.pr-photo{height:265px}.pr-card h3{color:#143c34}.pr-type{color:#8a5b72}
.pr-facts span{background:#edf2ee;border-color:#dce5dc}.pr-match{background:#fff9f1}
.pr-details{background:#143b34}.pr-pill{background:#e7e9e5}
.pr-hero-actions a.pr-secondary{border-color:#f0e1d4}

.pr-compare-toolbar{display:flex;justify-content:space-between;align-items:center;gap:16px;flex-wrap:wrap;margin:0 0 18px;padding:14px 18px;border:1px solid #d9e1d9;border-radius:14px;background:#eef3ef;color:#264c41;font-size:13px}
.pr-compare-toolbar button{border:0;background:#153b34;color:white;border-radius:10px;padding:12px 18px;font:700 13px 'DM Sans',sans-serif;cursor:pointer}
.pr-compare-toolbar button:disabled{opacity:.45;cursor:not-allowed}
.pr-compare-label{position:absolute;bottom:13px;left:13px;z-index:3;display:flex;gap:8px;align-items:center;background:#fffdf3f2;padding:9px 12px;border-radius:10px;color:#173c35;font-size:12px;font-weight:800;cursor:pointer}
.pr-compare-label input{accent-color:#153b34;width:17px;height:17px}
/* Final polish: brighter editorial palette and stronger interaction states */
.pr-wrap{background:linear-gradient(135deg,#f5f8f3 0%,#faf6f1 45%,#f4f1f6 100%)}
.pr-tabs a:hover{background:#e2e9e1;color:#173c34}
.pr-card{box-shadow:0 12px 30px #1a3b3215}
.pr-card:hover{transform:translateY(-5px);box-shadow:0 20px 40px #1a3b3224}
.pr-compare-toolbar{background:linear-gradient(100deg,#edf5ef,#f7edf4);border-color:#d7dfd7}
.pr-compare-toolbar button:focus-visible,.pr-tabs a:focus-visible,.pr-details:focus-visible{outline:3px solid #b17b9b;outline-offset:3px}

/* Final cohesive palette with neighborhood recommendations */
.pr-wrap{--ink:#173e36!important;--rust:#a95737!important;background:#faf8f4!important}
.pr-tabs a[aria-current=page],.pr-compare-toolbar button:not(:disabled){background:#a95737!important}
.pr-card{border:1px solid #e7dcd2!important;background:#fffdfb!important;box-shadow:0 7px 22px #372c2315!important}
.pr-card:hover{box-shadow:0 15px 36px #372c2324!important}
.pr-compare-toolbar{background:#fff9f3!important;border:1px solid #e5d5c8!important}
.pr-compare-label input{accent-color:#a95737!important}
/* Final coordinated palette */
.pr-wrap{background:#f9f6f1!important;--ink:#283d3b!important;--rust:#b16c48!important}
.pr-tabs a[aria-current=page],.pr-compare-toolbar button:not(:disabled){background:#995337!important}
.pr-card{border-color:#e5d8c9!important;box-shadow:0 8px 25px #57412d14!important}
.pr-details{background:#27433f!important}.pr-rank{background:#27433fee!important}
.pr-hero{border:1px solid #d9bea9!important}

/* DIYARA FINAL VISUAL SYSTEM: heritage clay + contemporary charcoal, restrained accents */
.pr-wrap,.nr-wrap{--ink:#292f35!important;--pine:#303b40!important;--terra:#bb6847!important;--rust:#bb6847!important;--mauve:#91766e!important;background:linear-gradient(145deg,#f8f7f4,#f5f0e9 58%,#f8f7f4)!important;color:#292f35!important}
.pr-tabs,.nr-tabs{background:#f2e9df!important;border-color:#e8d7c8!important}
.pr-tabs a[aria-current=page],.nr-tabs a[aria-current=page]{background:#34464a!important;color:#fff!important}
.pr-hero:before{background:linear-gradient(90deg,#27353bed 0%,#354149cc 44%,#35414910 100%),url('assets/property-hero.jpg') center/cover!important}
.nr-hero:after{background:linear-gradient(90deg,#27353bef 0%,#354149d0 42%,#35414910 100%)!important}
.pr-card,.nr-card{background:#fffdfa!important;border:1px solid #e9dfd4!important;box-shadow:0 10px 32px #34302b16!important}
.pr-card:hover,.nr-card:hover{box-shadow:0 18px 40px #34302b22!important}
.pr-details,.nr-properties-link{background:#34464a!important;color:white!important}
.pr-compare-toolbar,.nr-selection-bar{background:#f8eee6!important;border-color:#e6d2c2!important}
.pr-compare-toolbar button:not(:disabled),.nr-compare-open,.nr-selection-bar a{background:#ae6146!important;color:#fff!important}
.pr-compare-label input,.nr-compare-check,.nr-compare-select input{accent-color:#ae6146!important}
.pr-rank,.nr-rank{background:#34464aee!important}
.pr-price,.nr-score,.nr-name,.nr-section-title{color:#303a3d!important}
.pr-hero,.nr-hero{border-radius:19px!important}
.pr-photo{background-position:center!important}
@media(max-width:720px){.pr-wrap,.nr-wrap{padding-left:13px!important;padding-right:13px!important}}


/* FINAL DIYARA VISUAL SYSTEM — heritage x contemporary Riyadh */
.pr-wrap,.nr-wrap{--pine:#183b36;--terra:#b66a4a;--cream:#fff9f3;background:#fff9f3!important;color:#243d3a!important;max-width:1480px!important}
.pr-hero,.nr-hero{border-radius:18px!important;min-height:270px!important;box-shadow:0 14px 32px #392a1f19!important}
.pr-hero:before{background:linear-gradient(90deg,#142d2bf2 0%,#193c38d9 31%,#183d3960 58%,#183d3905 100%),url('assets/property-hero.jpg') center/cover!important}
.nr-hero:after{background:linear-gradient(90deg,#142d2bf0 0%,#193c38d9 32%,#183d3960 60%,transparent 100%)!important}
.pr-tabs,.nr-tabs{margin:0 0 20px!important;max-width:850px!important;background:#f3e7dc!important;border-color:#e5d3c4!important}
.pr-tabs a[aria-current=page],.nr-tabs a[aria-current=page]{background:#1d4a42!important;color:#fff!important}
.pr-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:18px!important}
.pr-card,.nr-card{background:#fffdfb!important;border:1px solid #eadbd0!important;border-radius:17px!important;box-shadow:0 7px 25px #49342613!important}
.pr-photo{height:245px!important;background-size:cover!important}
.nr-grid{display:grid!important;grid-template-columns:1fr!important;gap:14px!important}
.nr-card{display:grid!important;grid-template-columns:minmax(235px,29%) minmax(0,1fr)!important;min-height:240px!important}
.nr-card-art{height:100%!important;min-height:240px!important;background-size:cover!important}
.nr-body{padding:20px 25px!important}
.nr-name,.nr-score,.pr-price{color:#203f39!important}
.pr-details,.nr-properties-link,.pr-compare-toolbar button:not(:disabled),.nr-compare-open,.nr-selection-bar a{background:#1d4a42!important;color:white!important}
.pr-rank,.nr-rank{background:#173d36ee!important}
.pr-compare-toolbar,.nr-selection-bar{background:#f5e8de!important;border-color:#e6cdbb!important}
.pr-compare-label input,.nr-compare-check,.nr-compare-select input{accent-color:#b66a4a!important}
.pr-card:hover,.nr-card:hover{transform:translateY(-3px)!important;box-shadow:0 12px 28px #44312220!important}
@media(max-width:1000px){.pr-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}.nr-card{grid-template-columns:minmax(200px,34%) minmax(0,1fr)!important}}
@media(max-width:700px){.pr-grid{grid-template-columns:1fr!important}.nr-card{display:block!important}.nr-card-art{height:215px!important;min-height:215px!important}.pr-hero,.nr-hero{min-height:290px!important}}


/* Diyara compact editorial layout + functional sidebar */
.pr-wrap{max-width:1400px!important;padding:18px 26px 65px!important}.pr-hero{min-height:195px!important;border-radius:15px!important}.pr-hero-copy{padding:24px 34px!important}.pr-hero h1{font-size:clamp(27px,3vw,37px)!important;margin:7px 0!important}.pr-hero p{font-size:13px!important;line-height:1.5!important}.pr-hero-actions{margin-top:12px!important}.pr-hero-actions a{padding:9px 13px!important}.pr-titlebar{margin:21px 0 14px!important}.pr-titlebar h2{font-size:25px!important}.dy-discovery{display:grid;grid-template-columns:230px minmax(0,1fr);gap:20px;align-items:start}.dy-filters{position:sticky;top:18px;padding:19px;background:#fff;border:1px solid #e2e6e2;border-radius:14px;box-shadow:0 4px 18px #22352f0b}.dy-filter-head{font-size:17px;font-weight:800;color:#233e40;margin-bottom:17px}.dy-filter-head span{display:block;font-size:11px;font-weight:500;color:#7c8987}.dy-filters label{display:block;margin:13px 0 6px;font-size:12px;font-weight:700;color:#465b5b}.dy-filters input,.dy-filters select{width:100%;padding:10px;border:1px solid #d9dfdd;border-radius:8px;background:#fff;color:#293f41;font:inherit;font-size:12px}.dy-filters button{width:100%;margin-top:18px;padding:11px;border:0;border-radius:8px;background:#24464b;color:#fff;cursor:pointer;font-weight:700}.dy-filters p{font-size:10px;line-height:1.6;color:#89918d}.dy-results{min-width:0}.pr-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important;gap:14px!important}.pr-photo{height:170px!important}.pr-card-body{padding:14px!important}.pr-card h3{font-size:19px!important}.pr-price{font-size:20px!important;margin:9px 0!important}.pr-facts span{font-size:10px!important;padding:6px!important}.pr-details{padding:10px!important}.pr-compare-toolbar{padding:10px 14px!important}.pr-hero:before{background:linear-gradient(90deg,#223b40f2 0%,#223b40cf 36%,#223b4010 85%),url('assets/property-hero.jpg') center/cover!important}@media(max-width:1160px){.pr-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:760px){.dy-discovery{grid-template-columns:1fr}.dy-filters{position:static;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:4px 12px}.dy-filter-head,.dy-filters p,.dy-filters button{grid-column:1/-1}.pr-hero{min-height:220px!important}.pr-grid{grid-template-columns:repeat(2,minmax(0,1fr))!important}}@media(max-width:510px){.pr-grid{grid-template-columns:1fr!important}.dy-filters{grid-template-columns:1fr}.pr-wrap{padding:14px!important}}
</style>
<link rel="stylesheet" href="assets/css/property-visual-refresh.css?v=<?= @filemtime(__DIR__ . '/assets/css/property-visual-refresh.css') ?: time() ?>">
<link rel="stylesheet" href="assets/css/discovery.css?v=7">
<link rel="stylesheet" href="assets/css/editorial-surfaces.css?v=8">
<link rel="stylesheet" href="assets/css/recommendation-intro.css?v=3">
<section class="pr-wrap" data-listing-view>
<?php require_once __DIR__ . '/includes/recommendation-intro.php'; diyara_recommendation_intro(true, !empty($propertyCards) && !$errorMessage); ?>
<?php if ($errorMessage !== ''): ?><div class="pr-empty"><p><?= safe_output($errorMessage) ?></p></div>
<?php elseif (!$housing): ?><div class="pr-empty"><h2>Tell us what home you need</h2><p>Save your housing preferences to see matching properties.</p><a href="housing-preferences.php">Set housing preferences</a></div>
<?php else: ?>
<div class="pr-titlebar"><div><h2><?= $selectedNeighborhoodId !== null && $selectedNeighborhoodName !== '' ?  'Homes in ' . safe_output($selectedNeighborhoodName) : 'Homes selected for you' ?></h2></div><span class="pr-pill" id="pr-count" data-listing-count><?= count($propertyCards) ?> properties</span></div>
<?php if ($selectedNeighborhoodId !== null): ?>
<p class="dy-browse-links">
  <a href="recommendations.php" class="dy-return">Back to property recommendations</a>
</p>
<?php endif; ?>
<?php if (!$propertyCards): ?><div class="pr-empty"><h3><?= $selectedNeighborhoodId !== null ? 'No homes match this view in the neighborhood' : 'No homes match your saved budget and type' ?></h3><p><?= $selectedNeighborhoodId !== null ? 'Explore homes in another part of Riyadh.' : 'Try adjusting your budget or property type.' ?></p><a href="<?= $selectedNeighborhoodId !== null ? 'neighborhood-recommendations.php' : 'housing-preferences.php' ?>"><?= $selectedNeighborhoodId !== null ? 'Explore other neighborhoods' : 'Edit housing preferences' ?></a></div>
<?php else: ?>
<div id="pr-compare-tools" class="pr-compare-toolbar"><span>Select two properties to compare their details side by side.</span><button type="button" id="pr-compare-button" disabled>Compare Properties (0/2)</button></div>
<div class="dy-discovery"><aside class="dy-filters" aria-label="Property filters"><div class="dy-filter-head">Refine results</div><?php dy_listing_filters(array_map(static fn($entry) => $entry['neighborhood'] + $entry['property'], $propertyCards), false); ?></aside><div class="dy-results"><div class="pr-toolbar"><input id="pr-search" data-listing-search type="search" placeholder="Search properties or neighborhoods..." aria-label="Search properties"><select id="pr-sort" data-listing-sort aria-label="Sort properties by"><option value="match">Best match first</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option><option value="area-desc">Largest area first</option></select></div>
<div class="pr-grid" id="pr-grid" data-listing-grid>
<?php require_once 'property_images_lib.php'; require_once 'property_fallback_photos.php'; $recommendationPhotoUses = []; $uploadedPhotos=property_images_for($pdo,array_map(fn($e)=>$e['property']['property_id'],$propertyCards)); ?>
<?php foreach ($propertyCards as $entry): $p=$entry['property'];$n=$entry['neighborhood'];$type=(string)($p['property_type']??'Property');$hasRealPhoto=!empty($uploadedPhotos[(string)$p['property_id']][0]['url']);$image=$hasRealPhoto?$uploadedPhotos[(string)$p['property_id']][0]['url']:diyara_property_photo((string)$p['property_id'], $type, 'all', $recommendationPhotoUses);$name=(diyara_neighborhood_name($n) ?: 'Riyadh');$score=isset($p['match_score']) ? (float)$p['match_score'] : null;
$outside = diyara_outside_saved_criteria($p, $housing ?: []);
?>
<article class="pr-card<?= $outside ? ' pr-card-outside' : '' ?>" data-type="<?= safe_output(dy_property_type($type)) ?>" data-region="<?= safe_output(trim((string)($n['region'] ?? ''))) ?>" data-neighborhood="<?= (int) $n['neighborhood_id'] ?>" data-match="<?= $score ?? -1 ?>" data-price="<?= safe_output($p['price']) ?>" data-area="<?= safe_output($p['area_m2']) ?>" data-search="<?= safe_output(mb_strtolower($type.' '.$name.' '.($n['name_ar']??''),'UTF-8')) ?>">
<div class="pr-photo" style="background-image:url('<?= safe_output($image . ($hasRealPhoto ? '' : '?v=20261120e')) ?>')"><?php if ($regionLabel = diyara_region_name($n['region'] ?? '')): ?><small class="listing-region" dir="auto"><?= safe_output($regionLabel) ?></small><?php endif; ?><label class="pr-compare-label"><input type="checkbox" class="pr-compare-check" value="<?= safe_output($p['property_id']) ?>"> Compare</label><span class="pr-match"><?= $score !== null ? number_format($score,1) . '% match' : ($housing ? 'Outside saved criteria' : 'Listed property') ?></span></div>
<div class="pr-card-body"><h3><?= safe_output(dy_property_type($type)) ?></h3><p class="pr-location"><?= safe_output($name) ?></p><div class="pr-price"><?php if (is_numeric($p['price']) && (float) $p['price'] > 0): ?><?= number_format((float) $p['price']) ?> <small>SAR</small><?php else: ?>Price not listed<?php endif; ?></div><div class="pr-facts"><span><?= $p['area_m2']!==null?number_format((float)$p['area_m2']).' m²':'Area not listed' ?></span><span><?= $p['bedrooms']!==null?(int)$p['bedrooms'].' bedrooms':'Bedrooms not listed' ?></span><span><?= $p['bathrooms']!==null?(int)$p['bathrooms'].' bathrooms':'Bathrooms not listed' ?></span></div>
<?php if ($housing): ?>
<details class="dy-fit"><summary><?= $outside ? 'Why it falls outside your criteria' : 'How it fits' ?></summary>
<?= diyara_bilingual_explanation(diyara_housing_summary($p, $housing ?: [])) ?>
</details>
<?php endif; ?>
<a class="pr-details" href="property-details.php?id=<?= urlencode((string)$p['property_id']) ?>">Explore this property &rarr;</a></div></article>
<?php endforeach; ?>
</div></div></div><p id="pr-no-results" data-listing-empty class="pr-empty" hidden>No properties match your search.</p>
<?php endif; endif; ?>
</section>
<script>
(() => {
    const grid = document.getElementById('pr-grid');
    const button = document.getElementById('pr-compare-button');
    if (!grid || !button) return;

    const boxes = [...grid.querySelectorAll('.pr-compare-check')];
    const selected = () => boxes.filter(box => box.checked);
    // Select two listings.
    boxes.forEach(box => box.addEventListener('change', () => {
        if (selected().length > 2) box.checked = false;
        const count = selected().length;
        button.disabled = count !== 2;
        button.textContent = 'Compare Properties (' + count + '/2)';
    }));
    button.addEventListener('click', () => {
        const [first, second] = selected();
        if (first && second) {
            const query = new URLSearchParams({a: first.value, b: second.value});
            window.location.href = 'property-compare.php?' + query;
        }
    });
})();
</script>
<script src="assets/js/listing-filters.js?v=4" defer></script>
<?php require 'includes/footer.php'; ?>
