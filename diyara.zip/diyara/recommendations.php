<?php
// PERSON 3 writes the filtering logic, PERSON 4 shows the results here.
require 'auth_check.php';
require 'db.php';
$page_title = 'Recommendations';
$active = 'recommendations';
require 'includes/header.php';
?>
<section class="page">
  <div class="container">
    <h1>Recommended Neighborhoods</h1>
    <!-- PERSON 4: loop over the candidate neighborhoods and print one .card each
         inside <div class="grid grid-3">. -->
    <div class="empty">No results yet. Fill in your preferences to see matching neighborhoods.</div>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
