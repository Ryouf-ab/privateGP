<?php
// PERSON 4: shows the candidate neighborhoods returned by Person 3's filter.
require 'auth_check.php';
require 'db.php';
require 'filter.php';   // get_candidate_neighborhoods($pdo, $prefs) (Person 3)

// Load this user's saved preferences (Person 2's table). No table or no row yet = no preferences.
$prefs = null;
try {
    $stmt = $pdo->prepare('SELECT * FROM preferences WHERE user_id = ?');
    $stmt->execute([$_SESSION['user_id']]);
    $prefs = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
} catch (PDOException $e) {
    $prefs = null;
}

$results = $prefs ? get_candidate_neighborhoods($pdo, $prefs) : [];

function show_price($value) {
    return $value === null ? 'Not available' : number_format((float)$value) . ' SAR';
}

$page_title = 'Recommendations';
$active = 'recommendations';
require 'includes/header.php';
?>
<section class="page">
  <div class="container">
    <h1>Recommended Neighborhoods</h1>

    <?php if (!$prefs): ?>
      <div class="empty">
        <p>You haven't set your preferences yet. Tell us what you need to see matching neighborhoods.</p>
        <a class="btn" href="profile.php">Set my preferences</a>
      </div>

    <?php elseif (empty($results)): ?>
      <div class="empty">
        <p>No neighborhoods match all your requirements. Try a higher budget or fewer required services.</p>
        <a class="btn btn-secondary" href="profile.php">Edit my preferences</a>
      </div>

    <?php else: ?>
      <p><?php echo count($results); ?> neighborhoods match your preferences.</p>
      <div class="grid grid-3">
        <?php foreach ($results as $n): ?>
          <div class="card">
            <h3><?php echo htmlspecialchars($n['name_ar']); ?></h3>
            <?php if ($n['name_en']): ?>
              <p><?php echo htmlspecialchars($n['name_en']); ?><?php echo $n['region'] ? ' · ' . htmlspecialchars($n['region']) : ''; ?></p>
            <?php endif; ?>
            <ul>
              <li>Average property price: <?php echo show_price($n['median_property_price']); ?></li>
              <li>Price per m²: <?php echo show_price($n['median_price_m2']); ?></li>
              <li>Schools: <?php echo (int)$n['schools_count']; ?></li>
              <li>Hospitals: <?php echo (int)$n['hospitals_count']; ?></li>
              <li>Parks: <?php echo (int)$n['parks_count']; ?></li>
              <li>Supermarkets: <?php echo (int)$n['supermarkets_count']; ?></li>
              <li>Metro stations: <?php echo (int)$n['metro_stations_count']; ?></li>
            </ul>
          </div>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>
  </div>
</section>
<?php require 'includes/footer.php'; ?>
