-- Diyara Sprint 2 (Person 1): link each property listing to the agent who owns it.
-- Import in phpMyAdmin: select diyara_db > Import (or the SQL tab).
-- Safe to run more than once: every step checks first.
-- Run it AFTER data/diyara_data.sql and the users table exist.
SET NAMES utf8mb4;

-- 1) agent_id (the agent who owns the listing; NULL = original dataset listing, nobody can edit it)
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'properties' AND COLUMN_NAME = 'agent_id');
SET @sql := IF(@c = 0, 'ALTER TABLE properties ADD COLUMN agent_id INT NULL AFTER neighborhood_id', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 2) created_at / updated_at
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'properties' AND COLUMN_NAME = 'created_at');
SET @sql := IF(@c = 0, 'ALTER TABLE properties ADD COLUMN created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'properties' AND COLUMN_NAME = 'updated_at');
SET @sql := IF(@c = 0, 'ALTER TABLE properties ADD COLUMN updated_at TIMESTAMP NULL DEFAULT NULL', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- 3) index + foreign key to users (deleting an agent account also deletes that agent's own listings)
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'properties' AND INDEX_NAME = 'idx_properties_agent');
SET @sql := IF(@c = 0, 'ALTER TABLE properties ADD INDEX idx_properties_agent (agent_id)', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'properties' AND CONSTRAINT_NAME = 'fk_properties_agent');
SET @sql := IF(@c = 0, 'ALTER TABLE properties ADD CONSTRAINT fk_properties_agent FOREIGN KEY (agent_id) REFERENCES users(user_id) ON DELETE CASCADE', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- WARNING: data/diyara_data.sql runs "DELETE FROM properties", which also deletes agent listings.
-- Do not re-import it after agents have added properties.
