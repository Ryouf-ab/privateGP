<?php
/**
 * Diyara Sprint 2 - Weighted Sum Model for neighborhood suitability.
 * Independent of the existing Property Match Score.
 * Usage: require_once 'wsm.php'; $results = get_wsm_neighborhoods($pdo, $userId);
 */
function get_wsm_neighborhoods(PDO $pdo, int $userId): array
{
    $stmt = $pdo->prepare('SELECT service_importance FROM lifestyle_preferences WHERE user_id = ? LIMIT 1');
    $stmt->execute([$userId]);
    $saved = $stmt->fetchColumn();
    if ($saved === false || $saved === null || $saved === '') {
        throw new RuntimeException('Please save your Lifestyle Preferences first.');
    }

    $ratings = json_decode((string) $saved, true);
    if (!is_array($ratings)) {
        throw new RuntimeException('Saved service importance ratings are invalid.');
    }

    // The keys match lifestyle-preferences.php exactly.
    $services = [
        'Schools' => 'schools_count',
        'Healthcare' => 'healthcare_count',
        'Parks' => 'parks_count',
        'Supermarkets' => 'supermarkets_count',
        'Banks' => 'banks_count',
        'Gas Stations' => 'fuel_stations_count',
    ];

    $weights = [];
    $ratingTotal = 0;
    foreach ($services as $service => $column) {
        $rating = $ratings[$service] ?? 0;
        if (!is_numeric($rating) || (float) $rating < 0 || (float) $rating > 5 || floor((float) $rating) !== (float) $rating) {
            throw new RuntimeException('Invalid importance rating for ' . $service . '.');
        }
        $weights[$service] = (int) $rating;
        $ratingTotal += (int) $rating;
    }
    if ($ratingTotal === 0) {
        throw new RuntimeException('Please rate at least one service above zero.');
    }
    foreach ($weights as $service => $rating) {
        $weights[$service] = $rating / $ratingTotal;
    }

    $neighborhoods = $pdo->query('
        SELECT neighborhood_id, name_ar, name_en, region,
               schools_count, hospitals_count, clinics_count,
               parks_count, supermarkets_count, banks_count, fuel_stations_count
        FROM neighborhoods
        ORDER BY neighborhood_id
    ')->fetchAll(PDO::FETCH_ASSOC);
    if (!$neighborhoods) {
        return [];
    }

    // Convert hospital + clinic counts to one healthcare feature.
    // All six criteria are benefit criteria: higher service count is better.
    $maximums = array_fill_keys(array_keys($services), 0.0);
    foreach ($neighborhoods as &$n) {
        $n['healthcare_count'] = max(0, (float) ($n['hospitals_count'] ?? 0))
                                 + max(0, (float) ($n['clinics_count'] ?? 0));
        foreach ($services as $service => $column) {
            $maximums[$service] = max($maximums[$service], max(0, (float) ($n[$column] ?? 0)));
        }
    }
    unset($n);

    $results = [];
    foreach ($neighborhoods as $n) {
        $score = 0.0;
        $contributions = [];
        foreach ($services as $service => $column) {
            $count = max(0, (float) ($n[$column] ?? 0));
            $normalized = $maximums[$service] > 0 ? $count / $maximums[$service] : 0.0;
            $points = 100 * $weights[$service] * $normalized;
            $score += $points;
            $contributions[$service] = [
                'count' => $count,
                'weight' => round($weights[$service], 6),
                'normalized' => round($normalized, 6),
                'points' => round($points, 4),
            ];
        }
        $score = round($score, 2);
        // Proposed project thresholds; agree on these with the team/supervisor.
        $level = $score >= 70 ? 'High' : ($score >= 40 ? 'Medium' : 'Low');
        $results[] = [
            'neighborhood_id' => (int) $n['neighborhood_id'],
            'name_ar' => $n['name_ar'],
            'name_en' => $n['name_en'],
            'region' => $n['region'],
            'suitability_score' => $score,
            'suitability_level' => $level,
            'service_contributions' => $contributions,
        ];
    }

    usort($results, static function (array $a, array $b): int {
        return ($b['suitability_score'] <=> $a['suitability_score'])
            ?: ($a['neighborhood_id'] <=> $b['neighborhood_id']);
    });
    foreach ($results as $index => &$result) {
        $result['rank'] = $index + 1;
    }
    unset($result);
    return $results;
}
