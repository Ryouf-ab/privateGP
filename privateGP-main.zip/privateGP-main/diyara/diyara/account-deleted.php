<?php
/* Public page: shown after the account was deleted */
if (session_status() === PHP_SESSION_NONE) { session_start(); }
if (isset($_SESSION['user_id'])) { header('Location: index.php'); exit; }
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Account Deleted | Diyara</title>
<link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="diyara.css?v=72">
<link rel="stylesheet" href="assets/css/auth.css">
</head>
<body class="page-auth">

<header class="site-topbar">
    <div class="topbar-brand">
        <div class="topbar-logo-slot"></div>
        <div class="topbar-brand-text"><strong>Diyara</strong><span>Live where you belong.</span></div>
    </div>
    <nav class="topbar-nav">
        <a href="index.php" class="topbar-link">Home</a>
        <a href="login.html" class="topbar-link">Login</a>
    </nav>
</header>

<main class="page-body auth-main">
    <div class="auth-card" style="text-align:center">
        <h1>Account deleted</h1>
        <p style="margin:10px 0 22px">Your account and all your saved preferences have been permanently deleted.</p>
        <p dir="rtl" style="margin-bottom:22px">شكرًا لاستخدامك ديارا، يسعدنا رجوعك في أي وقت.</p>
        <a href="register.html" class="auth-button" style="display:inline-block;text-decoration:none">Create a new account</a>
    </div>
</main>

<footer class="diyara-footer">
    <div class="footer-brand"><div class="footer-mark"></div><div><strong>Diyara</strong><span>Live where you belong.</span></div></div>
    <div class="footer-center"><strong dir="rtl">ديارٍ تشبهك، وحيٍّ يناسبك.</strong><span>Riyadh · Heritage · Future</span></div>
    <div class="footer-end"><span class="footer-line"></span><p>Riyadh, Saudi Arabia<br>© 2026 Diyara</p></div>
</footer>
</body>
</html>
