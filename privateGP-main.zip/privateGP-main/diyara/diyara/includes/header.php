<?php
// Shared header for index.php and recommendations.php.
// Same top bar as profile.php / edit-profile.php.
//   $page_title = 'Recommendations';
//   $active = 'recommendations';   // home | recommendations | profile
//   require 'includes/header.php';
if (session_status() === PHP_SESSION_NONE) { session_start(); }
$logged_in = isset($_SESSION['user_id']);
$page_title = $page_title ?? 'Diyara';
$active = $active ?? '';
function nav_active($key, $active) { return $key === $active ? ' active' : ''; }
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> | Diyara</title>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=IBM+Plex+Sans+Arabic:wght@400;500;600;700&family=Playfair+Display:wght@500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="diyara.css?v=72">
    <link rel="stylesheet" href="assets/css/shared.css?v=<?= @filemtime(__DIR__ . "/../assets/css/shared.css") ?: time() ?>">
</head>
<body class="page-shared">

<header class="site-topbar">

    <div class="topbar-brand">
        <div class="topbar-logo-slot"></div>

        <div class="topbar-brand-text">
            <strong>Diyara</strong>
            <span>Live where you belong.</span>
        </div>
    </div>

    <nav class="topbar-nav">
        <a href="index.php" class="topbar-link<?php echo nav_active('home', $active); ?>">Home</a>
        <a href="recommendations.php" class="topbar-link<?php echo nav_active('recommendations', $active); ?>">Recommendations</a>
        <a href="profile.php" class="topbar-link<?php echo nav_active('profile', $active); ?>">My Profile</a>
        <?php if ($logged_in): ?>
            <a href="logout.php" class="topbar-link">Logout</a>
        <?php else: ?>
            <a href="login.html" class="topbar-link">Login</a>
        <?php endif; ?>
    </nav>

</header>

<main class="page-body">
